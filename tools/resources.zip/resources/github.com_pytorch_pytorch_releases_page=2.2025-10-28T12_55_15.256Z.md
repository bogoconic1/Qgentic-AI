[Skip to content](https://github.com/pytorch/pytorch/releases?page=2#start-of-content)

## Navigation Menu

Toggle navigation

[Homepage](https://github.com/)

[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fpytorch%2Fpytorch%2Freleases%3Fpage%3D2)

Appearance settings

- Platform









- [GitHub Copilot\\
\\
\\
\\
Write better code with AI](https://github.com/features/copilot)
- [GitHub Spark\\
\\
\\
New\\
\\
\\
Build and deploy intelligent apps](https://github.com/features/spark)
- [GitHub Models\\
\\
\\
New\\
\\
\\
Manage and compare prompts](https://github.com/features/models)
- [GitHub Advanced Security\\
\\
\\
\\
Find and fix vulnerabilities](https://github.com/security/advanced-security)
- [Actions\\
\\
\\
\\
Automate any workflow](https://github.com/features/actions)

- [Codespaces\\
\\
\\
\\
Instant dev environments](https://github.com/features/codespaces)
- [Issues\\
\\
\\
\\
Plan and track work](https://github.com/features/issues)
- [Code Review\\
\\
\\
\\
Manage code changes](https://github.com/features/code-review)
- [Discussions\\
\\
\\
\\
Collaborate outside of code](https://github.com/features/discussions)
- [Code Search\\
\\
\\
\\
Find more, search less](https://github.com/features/code-search)

Explore

- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com/)
- [GitHub Skills](https://skills.github.com/)
- [Blog](https://github.blog/)

Integrations

- [GitHub Marketplace](https://github.com/marketplace)
- [MCP Registry](https://github.com/mcp)

[View all features](https://github.com/features)

- Solutions







By company size

- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)

By use case

- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)

By industry

- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)

[View all solutions](https://github.com/solutions)

- Resources







Topics

- [AI](https://github.com/resources/articles?topic=ai)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [View all](https://github.com/resources/articles)

Explore

- [Learning Pathways](https://resources.github.com/learn/pathways)
- [Events & Webinars](https://github.com/resources/events)
- [Ebooks & Whitepapers](https://github.com/resources/whitepapers)
- [Customer Stories](https://github.com/customer-stories)
- [Partners](https://github.com/partners)
- [Executive Insights](https://github.com/solutions/executive-insights)

- Open Source









- [GitHub Sponsors\\
\\
\\
\\
Fund open source developers](https://github.com/sponsors)

- [The ReadME Project\\
\\
\\
\\
GitHub community articles](https://github.com/readme)

Repositories

- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)

- Enterprise









- [Enterprise platform\\
\\
\\
\\
AI-powered developer platform](https://github.com/enterprise)

Available add-ons

- [GitHub Advanced Security\\
\\
\\
\\
Enterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for business\\
\\
\\
\\
Enterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium Support\\
\\
\\
\\
Enterprise-grade 24/7 support](https://github.com/premium-support)

- [Pricing](https://github.com/pricing)

Search or jump to...

# Search code, repositories, users, issues, pull requests...

Search


Clear

[Search syntax tips](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax)

# Provide feedback

We read every piece of feedback, and take your input very seriously.

Include my email address so I can be contacted

Cancel
Submit feedback

# Saved searches

## Use saved searches to filter your results more quickly

Name

Query

To see all available qualifiers, see our [documentation](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax).


Cancel
Create saved search

[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fpytorch%2Fpytorch%2Freleases%3Fpage%3D2)

[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=header+logged+out&ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E%2Freleases%2Findex&source=header-repo&source_repo=pytorch%2Fpytorch)

Appearance settings

Resetting focus

You signed in with another tab or window. [Reload](https://github.com/pytorch/pytorch/releases?page=2) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/pytorch/pytorch/releases?page=2) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/pytorch/pytorch/releases?page=2) to refresh your session.Dismiss alert

{{ message }}

[pytorch](https://github.com/pytorch)/ **[pytorch](https://github.com/pytorch/pytorch)** Public

- Couldn't load subscription status.
Retry

- [Fork\\
25.7k](https://github.com/login?return_to=%2Fpytorch%2Fpytorch)
- [Star\\
94.3k](https://github.com/login?return_to=%2Fpytorch%2Fpytorch)


- [Code](https://github.com/pytorch/pytorch)
- [Issues5k+](https://github.com/pytorch/pytorch/issues)
- [Pull requests1.5k](https://github.com/pytorch/pytorch/pulls)
- [Actions](https://github.com/pytorch/pytorch/actions)
- [Projects12](https://github.com/pytorch/pytorch/projects)
- [Wiki](https://github.com/pytorch/pytorch/wiki)
- [Security4](https://github.com/pytorch/pytorch/security)






[**Uh oh!**](https://github.com/pytorch/pytorch/security)

[There was an error while loading.](https://github.com/pytorch/pytorch/security) [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

- [Insights](https://github.com/pytorch/pytorch/pulse)

Additional navigation options

- [Code](https://github.com/pytorch/pytorch)
- [Issues](https://github.com/pytorch/pytorch/issues)
- [Pull requests](https://github.com/pytorch/pytorch/pulls)
- [Actions](https://github.com/pytorch/pytorch/actions)
- [Projects](https://github.com/pytorch/pytorch/projects)
- [Wiki](https://github.com/pytorch/pytorch/wiki)
- [Security](https://github.com/pytorch/pytorch/security)
- [Insights](https://github.com/pytorch/pytorch/pulse)

# Releases: pytorch/pytorch

[Releases](https://github.com/pytorch/pytorch/releases) [Tags](https://github.com/pytorch/pytorch/tags)

Releases · pytorch/pytorch

## PyTorch 2.3: User-Defined Triton Kernels in torch.compile, Tensor Parallelism in Distributed

Apr 24, 2024
24 Apr 16:12


![@andrewor14](https://avatars.githubusercontent.com/u/2133137?s=40&v=4)[andrewor14](https://github.com/andrewor14)

[v2.3.0](https://github.com/pytorch/pytorch/tree/v2.3.0)

[`97ff6cf`](https://github.com/pytorch/pytorch/commit/97ff6cfd9c86c5c09d7ce775ab64ec5c99230f5d)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.


GPG key ID: B5690EEEBB952194

Verified
on Nov 6, 2024, 03:25 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

## Sorry, something went wrong.

Filter

Loading

## Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

## No results found

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.3: User-Defined Triton Kernels in torch.compile, Tensor Parallelism in Distributed](https://github.com/pytorch/pytorch/releases/tag/v2.3.0)

# PyTorch 2.3 Release notes

- Highlights
- Backwards Incompatible Changes
- Deprecations
- New Features
- Improvements
- Bug fixes
- Performance
- Documentation

# Highlights

We are excited to announce the release of PyTorch® 2.3! PyTorch 2.3 offers support for user-defined Triton kernels in torch.compile, allowing for users to migrate their own Triton kernels from eager without experiencing performance complications or graph breaks. As well, Tensor Parallelism improves the experience for training Large Language Models using native PyTorch functions, which has been validated on training runs for 100B parameter models.

This release is composed of 3393 commits and 426 contributors since PyTorch 2.2. We want to sincerely thank our dedicated community for your contributions. As always, we encourage you to try these out and report any issues as we improve 2.3. More information about how to get started with the PyTorch 2-series can be found at our [Getting Started](https://pytorch.org/get-started/pytorch-2.0/) page.

|     |     |     |     |
| --- | --- | --- | --- |
| **Stable** | **Beta** | **Prototype** | **Performance Improvements** |
|  | User-defined Triton kernels in torch.compile | torch.export adds new API to specify dynamic\_shapes | Weight-Only-Quantization introduced into Inductor CPU backend |
|  | Tensor parallelism within PyTorch Distributed | Asynchronous checkpoint generation |  |
|  | Support for semi-structured sparsity |  |  |

\*To see a full list of public feature submissions click [here](https://docs.google.com/spreadsheets/d/1TzGkWuUMF1yTe88adz1dt2mzbIsZLd3PBasy588VWgk/edit?usp=sharing).

# Tracked Regressions

### **torch.compile on MacOS is considered unstable for 2.3 as there are known cases where it will hang ( [\#124497](https://github.com/pytorch/pytorch/issues/124497))**

### **torch.compile imports many unrelated packages when it is invoked ( [\#123954](https://github.com/pytorch/pytorch/issues/123954))**

This can cause significant first-time slowdown and instability when these packages are not fully compatible with PyTorch within a single process.

### **torch.compile is not supported on Python 3.12 ( [\#120233](https://github.com/pytorch/pytorch/issues/120233))**

PyTorch support for Python 3.12 in general is considered experimental. Please use Python version between 3.8 and 3.11 instead. This is an existing issue since PyTorch 2.2.

# Backwards Incompatible Changes

### **Change default torch\_function behavior to be disabled when torch\_dispatch is defined ( [\#120632](https://github.com/pytorch/pytorch/pull/120632))**

Defining a subclass with a **torch\_dispatch** entry will now automatically set **torch\_function** to be disabled. This aligns better with all the use cases we’ve observed for subclasses. The main change of behavior is that the result of the torch\_dispatch handler will not go through the default torch\_function handler anymore, wrapping it into the current subclass. This allows in particular for your subclass to return a plain Tensor or another subclass from any op.

The original behavior can be recovered by adding the following to your Tensor subclass:

```
@classmethod
def __torch_function__(cls, func, types, args=(), kwargs=None):
      return super().__torch_function__(func, types, args, kwargs)
```

### **ProcessGroupNCCL removes multi-device-per-thread support from C++ level ( [\#119099](https://github.com/pytorch/pytorch/pull/119099), [\#118674](https://github.com/pytorch/pytorch/pull/118674))**

- Python level support was removed in 2.2.
- To simplify ProcessGroupNCCL’s code, we remove support for multiple cuda devices per thread. To our knowledge, this is not an active use case, but it adds a large burden to our codebase. If you are relying on this, there is no workaround other than rewriting your pytorch program to use one device per process or one device per thread (multi-threads per process is still supported).

### **Removes `no_dist` and `coordinator_rank` from public DCP API's ( [\#121317](https://github.com/pytorch/pytorch/pull/121317))**

As part of an overall effort to simplify our public facing API's for Distributed Checkpointing, we've decided to deprecate usage of the `coordinator_rank` and `no_dist` parameters under `torch.distributed.checkpoint`. In our opinion, these parameters can lead to confusion around the intended effect during API usage, and have limited value to begin with. One concrete example is here, [#118337](https://github.com/pytorch/pytorch/issues/118337), where there is ambiguity in which Process Group is referenced by the coordinator rank (additional context: [#118337](https://github.com/pytorch/pytorch/issues/118337)). In the case of the `no_dist` parameter, we consider this an implementation detail which should be hidden from the user. Starting in this release, `no_dist` is inferred from the initialized state of the process group, assuming the intention is to use collectives if a process group is initialized, and assuming the opposite in the case it is not.

|     |     |
| --- | --- |
| **2.2** | **2.3** |
| ```<br># Version 2.2.2<br>import torch.distributed.checkpoint as dcp<br>dcp.save(<br>	state_dict={"model": model.state_dict()},<br>       checkpoint_id="path_to_model_checkpoint"<br>       no_dist=True,<br>       coordinator_rank=0<br>)<br># ...<br>dcp.load(<br>	state_dict={"model": model.state_dict()},<br>       checkpoint_id="path_to_model_checkpoint"<br>       no_dist=True,<br>       coordinator_rank=0<br>)<br>``` | ```<br># Version 2.2.3<br># no dist is assumed from pg state, and rank 0 is always coordinator.<br>import torch.distributed.checkpoint as dcp<br>dcp.save(<br>	state_dict={"model": model.state_dict()},<br>       checkpoint_id="path_to_model_checkpoint"<br>) <br># ...<br>dcp.load(<br>	state_dict={"model": model.state_dict()},<br>       checkpoint_id="path_to_model_checkpoint"<br>)<br>``` |

### **Remove deprecated tp\_mesh\_dim arg ( [\#121432](https://github.com/pytorch/pytorch/pull/121432))**

Starting from PyTorch 2.3, `parallelize_module` API only accepts a DeviceMesh (the `tp_mesh_dim` argument has been removed). If having a N-D DeviceMesh for multi-dimensional parallelism, you can use `mesh_nd["tp"]` to obtain a 1-D DeviceMesh for tensor parallelism.

## **torch.export**

- Users must pass in an nn.Module to torch.export.export. The reason is that we have several invariants the ExportedProgram that are ambiguous if the top-level object being traced is a function, such as how we guarantee that every call\_function node has an nn\_module\_stack populated, and we offer ways to access the state\_dict/parameters/buffers of the exported program. We'd like torch.export to offer strong invariants—the value proposition of export is that you can trade flexibility for stronger guarantees about your model. ( [#117528](https://github.com/pytorch/pytorch/pull/117528))
- Removed constraints in favor of dynamic\_shapes ( [#117573](https://github.com/pytorch/pytorch/pull/117573), [#117917](https://github.com/pytorch/pytorch/pull/117917), [#117916](https://github.com/pytorch/pytorch/pull/117916), [#120981](https://github.com/pytorch/pytorch/pull/120981), [#120979](https://github.com/pytorch/pytorch/pull/120979))
- ExportedProgram is no longer a callable. Instead users will need to use .module() to call the ExportedProgram. This is to prevent users from treating ExportedPrograms as torch.nn.Modules as we do not plan to support all features that torch.nn.Modules have, like hooks. Instead users can create a proper torch.nn.Module through exported\_program.module() and use that as a callable. ( [#120019](https://github.com/pytorch/pytorch/pull/120019), [#118425](https://github.com/pytorch/pytorch/pull/118425), [#119105](https://github.com/pytorch/pytorch/pull/119105))
- Remove equality\_constraints from ExportedProgram as it is not used or useful anymore. Dimensions with equal constraints will now have the same symbol. ( [#116979](https://github.com/pytorch/pytorch/pull/116979))
- Remove torch.\_export.export in favor of torch.export.export ( [#119095](https://github.com/pytorch/pytorch/pull/119095))
- Remove CallSpec ( [#117671](https://github.com/pytorch/pytorch/pull/117671))

### **Enable fold\_quantize by default in PT2 Export Quantization ( [\#118701](https://github.com/pytorch/pytorch/pull/118701), [\#118605](https://github.com/pytorch/pytorch/pull/118605), [\#119425](https://github.com/pytorch/pytorch/pull/119425), [\#117797](https://github.com/pytorch/pytorch/pull/117797))**

Previously, the PT2 Export Quantization flow did not generate quantized weight by default, but instead used fp32 weight in the quantized model in this pattern: `fp32 weight -> q -> dq -> linear`. Setting `fold_quantize=True` produces a graph with quantized weights in the quantized model in this pattern by default after convert\_pt2e, and users will see a reduction in the model size: `int8 weight -> dq -> linear`.

|     |     |
| --- | --- |
| **2.2** | **2.3** |
| ```<br>folded_model = convert_pt2e(model, fold_quantize=True)<br>non_folded_model = convert_pt2e(model)<br>``` | ```<br>folded_model = convert_pt2e(model)<br>non_folded_model = convert_pt2e(model, fold_quantize=False)<br>``` |

### **Remove deprecated torch.jit.quantized APIs ( [\#118406](https://github.com/pytorch/pytorch/pull/118406))**

All functions and classes under `torch.jit.quantized` will now raise an error if called/instantiated. This API has long been deprecated in favor of `torch.ao.nn.quantized`.

|     |     |
| --- | --- |
| **2.2** | **2.3** |
| ```<br># torch.jit.quantized APIs<br>torch.jit.quantized.quantize_rnn_cell_modules<br>torch.jit.quantized.quantize_rnn_modules<br>torch.jit.quantized.quantize_linear_modules<br>torch.jit.quantized.QuantizedLinear<br>torch.jit.QuantizedLinearFP16<br>torch.jit.quantized.QuantizedGRU<br>torch.jit.quantized.QuantizedGRUCell<br>torch.jit.quantized.QuantizedLSTM<br>torch.jit.quantized.QuantizedLSTMCell<br>``` | ```<br># Corresponding torch.ao.quantization APIs<br>torch.ao.nn.quantized.dynamic.RNNCell<br>torch.ao.quantization.quantize_dynamic APIs<br>torch.ao.nn.quantized.dynamic.Linear<br>torch.ao.nn.quantized.dynamic.GRU<br>torch.ao.nn.quantized.dynamic.GRUCell<br>torch.ao.nn.quantized.dynamic.LSTM<br>``` |

### ...

[Read more](https://github.com/pytorch/pytorch/releases/tag/v2.3.0)

Assets3

Loading

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

etiennelndr, 651961, matth-blt, johnnynunez, shink, Burhan-Q, oraluben, Abellegese, Pedro-e, holdjun, and 29 more reacted with thumbs up emoji651961, matth-blt, Burhan-Q, Abellegese, wanderingeek, vantienpham, akihironitta, bryanlimy, Chubercik, gavin-hyl, and 7 more reacted with hooray emojijulian-8897, atalman, ab-smith, yzhangcs, cauliyang, kanishkanarch, vilsonrodrigues, mcaccin, madpeh, Rohanjames1997, and 40 more reacted with heart emojiatalman, Separius, kanishkanarch, wanchaol, debnath-d, luncliff, Neleka, nick-konovalchuk, fkouteib, zichunhao, and 25 more reacted with rocket emoji

All reactions

- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)39 reactions
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)17 reactions
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)50 reactions
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)35 reactions

100 people reacted

## PyTorch 2.2.2 Release, bug fix release

Mar 27, 2024
27 Mar 22:27


![@atalman](https://avatars.githubusercontent.com/u/7563158?s=40&v=4)[atalman](https://github.com/atalman)

[v2.2.2](https://github.com/pytorch/pytorch/tree/v2.2.2)

[`39901f2`](https://github.com/pytorch/pytorch/commit/39901f229520a5256505ec24782f716ee7ddc843)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.


GPG key ID: B5690EEEBB952194

Verified
on Nov 7, 2024, 10:42 AM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

## Sorry, something went wrong.

Filter

Loading

## Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

## No results found

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.2.2 Release, bug fix release](https://github.com/pytorch/pytorch/releases/tag/v2.2.2)

This release is meant to fix the following issues (regressions / silent correctness):

- Properly raise an error when trying to use inductor backend on non-supported platforms such as Windows ( [#115969](https://github.com/pytorch/pytorch/pull/115969))
- Fix mkldnn performance issue on Windows platform ( [#121618](https://github.com/pytorch/pytorch/pull/121618))
- Fix `RuntimeError: cannot create std::vector larger than max_size()` in `torch.nn.functional.conv1d` on non-contiguous cpu inputs by patching OneDNN ( [pytorch/builder#1742](https://github.com/pytorch/builder/pull/1742)) ( [pytorch/builder#1744](https://github.com/pytorch/builder/pull/1744))
- Add support for `torch.distributed.fsdp.StateDictType.FULL_STATE_DICT` for when using `torch.distributed.fsdp.FullyShardedDataParallel` with the `device_mesh` argument ( [#120837](https://github.com/pytorch/pytorch/pull/120837))
- Fix `make triton` command on release branch for users building the release branch from source ( [#121169](https://github.com/pytorch/pytorch/pull/121169))
- Ensure gcc>=9.0 for build from source and cpp\_extensions ( [#120126](https://github.com/pytorch/pytorch/pull/120126))
- Fix cxx11-abi build in release branch ( [pytorch/builder#1709](https://github.com/pytorch/builder/pull/1709))
- Fix building from source on Windows source MSVC 14.38 - VS 2022 ( [#122120](https://github.com/pytorch/pytorch/pull/122120))

Release tracker [#120999](https://github.com/pytorch/pytorch/issues/120999) contains all relevant pull requests related to this release as well as links to related issues.

Assets3

Loading

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

zhenrong-wang, bailidongjun, huydhn, wanderingeek, lucadiliello, ibrahim324, XJAUJSJZZY, jojuo123, zenmhui, JoshuaEPSamuel, and 6 more reacted with thumbs up emojijwrh, azevedoguigo, zhenrong-wang, bailidongjun, zenmhui, lin72h, csukuangfj, and Youcantstopme2744 reacted with laugh emojihelderc, arvinsingh, unadlib, bayesianbrad, 651961, cdluminate, thr3a, prantoran, ngdlmk, fkouteib, and 28 more reacted with hooray emojizhenrong-wang, bailidongjun, black0017, zenmhui, santhoshkammari, lin72h, csukuangfj, vikram71198, and Youcantstopme2744 reacted with heart emojiN-Friederich, zhenrong-wang, bailidongjun, wanderingeek, lin72h, csukuangfj, and Youcantstopme2744 reacted with rocket emojileo-smi, zhenrong-wang, bailidongjun, and csukuangfj reacted with eyes emoji

All reactions

- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)16 reactions
- ![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)8 reactions
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)38 reactions
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)9 reactions
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)7 reactions
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)4 reactions

55 people reacted

## PyTorch 2.2.1 Release, bug fix release

Feb 22, 2024
22 Feb 21:15


![@atalman](https://avatars.githubusercontent.com/u/7563158?s=40&v=4)[atalman](https://github.com/atalman)

[v2.2.1](https://github.com/pytorch/pytorch/tree/v2.2.1)

[`6c8c5ad`](https://github.com/pytorch/pytorch/commit/6c8c5ad5eaf47a62fafbb4a2747198cbffbf1ff0)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.


GPG key ID: B5690EEEBB952194

Verified
on Nov 7, 2024, 08:35 AM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

## Sorry, something went wrong.

Filter

Loading

## Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

## No results found

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.2.1 Release, bug fix release](https://github.com/pytorch/pytorch/releases/tag/v2.2.1)

This release is meant to fix the following issues (regressions / silent correctness):

- Fix missing OpenMP support on Apple Silicon binaries ( [pytorch/builder#1697](https://github.com/pytorch/builder/pull/1697))
- Fix crash when mixing lazy and non-lazy tensors in one operation ( [#117653](https://github.com/pytorch/pytorch/pull/117653))
- Fix PyTorch performance regression on Linux aarch64 ( [pytorch/builder#1696](https://github.com/pytorch/builder/pull/1696))
- Fix silent correctness in DTensor `_to_copy` operation ( [#116426](https://github.com/pytorch/pytorch/pull/116426))
- Fix properly assigning `param.grad_fn` for next forward ( [#116792](https://github.com/pytorch/pytorch/pull/116792))
- Ensure gradient clear out pending `AsyncCollectiveTensor` in FSDP Extension ( [#116122](https://github.com/pytorch/pytorch/pull/116122))
- Fix processing unflatten tensor on compute stream in FSDP Extension ( [#116559](https://github.com/pytorch/pytorch/pull/116559))
- Fix FSDP `AssertionError` on tensor subclass when setting `sync_module_states=True` ( [#117336](https://github.com/pytorch/pytorch/pull/117336))
- Fix DCP state\_dict cannot correctly find FQN when the leaf module is wrapped by FSDP ( [#115592](https://github.com/pytorch/pytorch/pull/115592))
- Fix OOM when when returning a AsyncCollectiveTensor by forcing `_gather_state_dict()` to be synchronous with respect to the mian stream. ( [#118197](https://github.com/pytorch/pytorch/pull/118197)) ( [#119716](https://github.com/pytorch/pytorch/pull/119716))
- Fix Windows runtime `torch.distributed.DistNetworkError`: \[WinError 32\] The process cannot access the file because it is being used by another process ( [#118860](https://github.com/pytorch/pytorch/pull/118860))
- Update supported python versions in package description ( [#119743](https://github.com/pytorch/pytorch/pull/119743))
- Fix SIGILL crash during `import torch` on CPUs that do not support SSE4.1 ( [#116623](https://github.com/pytorch/pytorch/issues/116623))
- Fix DCP RuntimeError in `get_state_dict` and `set_state_dict` ( [#119573](https://github.com/pytorch/pytorch/pull/119573))
- Fixes for HSDP + TP integration with device\_mesh ( [#112435](https://github.com/pytorch/pytorch/pull/112435)) ( [#118620](https://github.com/pytorch/pytorch/pull/118620)) ( [#119064](https://github.com/pytorch/pytorch/pull/119064)) ( [#118638](https://github.com/pytorch/pytorch/pull/118638)) ( [#119481](https://github.com/pytorch/pytorch/pull/119481))
- Fix numerical error with `mixedmm` on NVIDIA V100 ( [#118591](https://github.com/pytorch/pytorch/pull/118591))
- Fix RuntimeError when using SymInt input invariant when splitting graphs ( [#117406](https://github.com/pytorch/pytorch/pull/117406))
- Fix compile `DTensor.from_local` in trace\_rule\_look up ( [#119659](https://github.com/pytorch/pytorch/pull/119659))
- Improve torch.compile integration with CUDA-11.8 binaries ( [#119750](https://github.com/pytorch/pytorch/pull/119750))

Release tracker [#119295](https://github.com/pytorch/pytorch/issues/119295) contains all relevant pull requests related to this release as well as links to related issues.

Assets3

Loading

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

etiennelndr, vantienpham, xsa-dev, arvinsingh, wanderingeek, 651961, BryansApple11, Arijaa, khlaifiabilel, N-Friederich, and 38 more reacted with thumbs up emojileo-smi, jwrh, Blacksuan19, htinaunglu, Rusteam, Muhtasham, lin72h, and 0-Angela-Boone1984 reacted with laugh emojiwanchaol, wanderingeek, Santhoshlm10, tugui, khlaifiabilel, andre-brainn, Mindstan, brnaguiar, leo-smi, ThomasRetornaz, and 9 more reacted with hooray emoji2kha, andre-brainn, leo-smi, hammaad2002, javierBarandiaran, Muhtasham, lin72h, willianpaixao, and 0-Angela-Boone1984 reacted with heart emojiBryansApple11, araffin, MARD1NO, AntonioBerna, andre-brainn, Neleka, leo-smi, Muhtasham, lin72h, and willianpaixao reacted with rocket emojileo-smi and gooloosk reacted with eyes emoji

All reactions

- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)48 reactions
- ![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)8 reactions
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)19 reactions
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)9 reactions
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)10 reactions
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)2 reactions

72 people reacted

## PyTorch 2.2: FlashAttention-v2, AOTInductor

Jan 30, 2024
30 Jan 17:58


![@jcaip](https://avatars.githubusercontent.com/u/8041643?s=40&v=4)[jcaip](https://github.com/jcaip)

[v2.2.0](https://github.com/pytorch/pytorch/tree/v2.2.0)

[`8ac9b20`](https://github.com/pytorch/pytorch/commit/8ac9b20d4b090c213799e81acf48a55ea8d437d6)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.
The key has expired.


GPG key ID: 4AEE18F83AFDEB23

Expired

Verified
on Jan 16, 2024, 02:59 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

## Sorry, something went wrong.

Filter

Loading

## Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

## No results found

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.2: FlashAttention-v2, AOTInductor](https://github.com/pytorch/pytorch/releases/tag/v2.2.0)

# PyTorch 2.2 Release Notes

- Highlights
- Backwards Incompatible Changes
- Deprecations
- New Features
- Improvements
- Bug fixes
- Performance
- Documentation

# Highlights

We are excited to announce the release of PyTorch® 2.2! PyTorch 2.2 offers ~2x performance improvements to `scaled_dot_product_attention` via FlashAttention-v2 integration, as well as AOTInductor, a new ahead-of-time compilation and deployment tool built for non-python server-side deployments.

This release also includes improved torch.compile support for Optimizers, a number of new inductor optimizations, and a new logging mechanism called TORCH\_LOGS.

**Please note that we are [deprecating macOS x86 support](https://github.com/pytorch/pytorch/issues/114602), and PyTorch 2.2.x will be the last version that supports macOS x64.**

Along with 2.2, we are also releasing a series of updates to the PyTorch domain libraries. More details can be found in the library updates blog.

This release is composed of 3,628 commits and 521 contributors since PyTorch 2.1. We want to sincerely thank our dedicated community for your contributions. As always, we encourage you to try these out and report any issues as we improve 2.2. More information about how to get started with the PyTorch 2-series can be found at our [Getting Started](https://pytorch.org/get-started/pytorch-2.0/) page.

Summary:

- `scaled_dot_product_attention` (SDPA) now supports FlashAttention-2, yielding around 2x speedups compared to previous versions.
- PyTorch 2.2 introduces a new ahead-of-time extension of TorchInductor called AOTInductor, designed to compile and deploy PyTorch programs for non-python server-side.
- `torch.distributed` supports a new abstraction for initializing and representing ProcessGroups called device\_mesh.
- PyTorch 2.2 ships a standardized, configurable logging mechanism called TORCH\_LOGS.
- A number of torch.compile improvements are included in PyTorch 2.2, including improved support for compiling Optimizers and improved TorchInductor fusion and layout optimizations.
- Please note that we are deprecating macOS x86 support, and PyTorch 2.2.x will be the last version that supports macOS x64.
- `torch.ao.quantization` now offers a prototype `torch.export` based flow

|     |     |     |     |
| --- | --- | --- | --- |
| **Stable** | **Beta** | **Prototype** | **Performance Improvements** |
|  | FlashAttentionV2 backend for scaled dot product attention | PT 2 Quantization | Inductor optimizations |
|  | AOTInductor | Scaled dot product attention support for jagged layout NestedTensors | aarch64-linux optimizations (AWS Graviton) |
|  | TORCH\_LOGS |  |  |
|  | torch.distributed.device\_mesh |  |  |
|  | torch.compile + Optimizers |  |  |

\*To see a full list of public 2.2 - 1.12 feature submissions click [here](https://docs.google.com/spreadsheets/d/1TzGkWuUMF1yTe88adz1dt2mzbIsZLd3PBasy588VWgk/edit?usp=sharing).

# Tracked Regressions

### **Performance reduction when using NVLSTree algorithm in NCCL 2.19.3 ( [\#117748](https://github.com/pytorch/pytorch/issues/117748))**

We have noticed a performance regression introduced to all-reduce in NCCL 2.19.3. Please use version 2.19.1 instead.

### **Poor numeric stability of loss when training with FSDP + DTensor ( [\#117471](https://github.com/pytorch/pytorch/issues/117471))**

We observe the loss will flatline randomly while training with FSDP + DTensor in some instances.

# Backwards Incompatible Changes

### **Building PyTorch from source now requires GCC 9.4 or newer ( [\#112858](https://github.com/pytorch/pytorch/pull/112858))**

GCC 9.4 is the oldest version fully compatible with C++17, which the PyTorch codebase has migrated to from C++14.

### **Updated flash attention kernel in `scaled_dot_product_attention` to use Flash Attention v2 ( [\#105602](https://github.com/pytorch/pytorch/pull/105602))**

Previously, the v1 Flash Attention kernel had a Windows implementation. So if a user on Windows had explicitly forced the flash attention kernel to be run by using `sdp_kernel` context manager with only flash attention enabled, it would work. In 2.2, if the `sdp_kernel` context manager must be used, use the memory efficient or math kernel if on Windows.

```
with torch.backends.cuda.sdp_kernel(enable_flash=True, enable_math=False, enable_mem_efficient=False):
  torch.nn.functional.scaled_dot_product_attention(q,k,v)
```

```
# Don't force flash attention to be used if using sdp_kernel on Windows
with torch.backends.cuda.sdp_kernel(enable_flash=False, enable_math=True, enable_mem_efficient=True):
  torch.nn.functional.scaled_dot_product_attention(q,k,v)
```

### **Rewrote DTensor (Tensor Parallel) APIs to improve UX ( [\#114732](https://github.com/pytorch/pytorch/pull/114732))**

In PyTorch 2.1 or before, users can use ParallelStyles like `PairwiseParallel` and specify input/output layout with functions like `make_input_replicate_1d` or `make_output_replicate_1d`. And we have default values for \_prepare\_input and \_prepare\_output. The UX of Tensor Parallel was like:

```
from torch.distributed.tensor.parallel.style import (
    ColwiseParallel,
    make_input_replicate_1d,
    make_input_reshard_replicate,
    make_input_shard_1d,
    make_input_shard_1d_last_dim,
    make_sharded_output_tensor,
    make_output_replicate_1d,
    make_output_reshard_tensor,
    make_output_shard_1d,
    make_output_tensor,
    PairwiseParallel,
    parallelize_module,
)
from torch.distributed.tensor import DeviceMesh

module = DummyModule()
device_mesh = DeviceMesh("cuda", list(range(self.world_size)))
parallelize_module(module, device_mesh, PairwiseParallel(_prepare_input=make_input_replicate_1d))
...
```

Starting from PyTorch 2.2, we simplified parallel styles to only contain `ColwiseParallel` and `RowwiseParallel` because other ParallelStyle can consist of these two. We also deleted the input/output functions, and started using `input_layouts` and `output_layouts` as kwargs instead to specify the sharding layout of both input/output tensors. Finally, added PrepareModuleInput/PrepareModuleOutput style, and no default arguments for layouts in these two styles and users need to specify them to think about the sharding layouts.

```
from torch.distributed.tensor.parallel.style import (
    ColwiseParallel,
    PrepareModuleInput,
    RowwiseParallel,
    parallelize_module,
)
from torch.distributed._tensor import init_device_mesh

module = SimpleMLPModule()
device_mesh = init_device_mesh("cuda", (self.world_size,)))
parallelize_module(
   module,
   device_mesh,
   {
      "fqn": PrepareModuleInput(
                input_layouts=Shard(0),
                desired_input_layouts=Replicate()
             ),
      "fqn.net1": ColwiseParallel(),
      "fqn.net2": RowwiseParallel(output_layouts=Shard(0)),
   }
)
...
```

### **`UntypedStorage.resize_` now uses the original device instead of the current device context ( [\#113386](https://github.com/pytorch/pytorch/pull/113386))**

Before this PR, `UntypedStorage.resize_` would move data to the current CUDA device index (given by `torch.cuda.current_device()`).

Now, `UntypedStorage.resize_()` keeps the data on the same device index that it was on before, regardless of the current device index.

| 2.1 | 2.2 |
| --- | --- |
| ```<br>>>> import torch<br>>>> with torch.cuda.device('cuda:0'):<br>...:     a = torch.zeros(0, device='cuda:1')<br>...:     print(a.device)<br>...:     a = a.untyped_storage().resize_(0)<br>...:     print(a.device)<br>cuda:1<br>cuda:0<br>``` | ```<br>>>> import torch<br>>>> with torch.cuda.device('cuda:0'):<br>...:     a = torch.zeros(0, device='cuda:1')<br>...:     print(a.device)<br>...:     a = a.untyped_storage().resize_(0)<br>...:     print(a.device)<br>cuda:1<br>cuda:1<br>``` |

### **Wrapping a function with set\_grad\_enabled will consume its global mutation ( [\#113359](https://github.com/pytorch/pytorch/pull/113359))**

This bc-breaking change fixes some unexpected behavior when `set_grad_enabled` is used as a decorator.

| 2.1 | 2.2 |
| --- | --- |
| ```<br>>>> import torch<br>>>> @torch.set_grad_enabled(False)  # unexpectedly, this mutates the grad mode!<br>    def inner_func(x):<br>        return x.sin()<br>>>> torch.is_grad_enabled()<br>True<br>``` | ```<br>>>> import torch<br>>>> @torch.set_grad_enabled(False)  # unexpectedly, this mutates the grad mode!<br>    def inner_func(x):<br>        return x.sin()<br>>>> torch.is_grad_enabled()<br>False<br>``` |

### **Deprecated `verbose` parameter in `LRscheduler` constructors ( [\#111302](https://github.com/pytorch/pytorch/pull/111302))**

As part of our decision to move towards a consolidated logging system, we are deprecating the `verbose` flag in `LRScheduler`.

If you would like to print the learning rate during execution, please use `get_last_lr()`

| 2.1 | 2.2 |
| --- | --- |
| ```<br>optimizer = torch.optim.SGD(model.parameters(), lr=0.1, momentum=0.9)<br>scheduler = ReduceLROnPlateau(optimizer, 'min', verbose=True)<br>for epoch in range(10):<br>    train(...)<br>    val_loss = validate(...)<br>    # Note that step should be called after validate()<br>    scheduler.step(val_loss)<br>``` | ```<br>optimizer = torch.optim.SGD(model.parameters(), lr=0.1, momentum=0.9)<br>scheduler = ReduceLROnPlateau(optimizer, 'min')<br>for epoch in range(10):<br>    train(...)<br>    val_loss = validate(...)<br>    # Note that step should be called after validate()<br>    scheduler.step(val_loss)<br>	print(f"Epoch {epoch} has concluded with lr of {scheduler.get_last_lr()}")<br>```<br></td... |

[Read more](https://github.com/pytorch/pytorch/releases/tag/v2.2.0)

Assets3

Loading

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

Fissium, cdluminate, akihironitta, ideaguy3d, wanderingeek, gallegogt, realiti4, cauliyang, K-H-Ismail, rvlobato, and 78 more reacted with thumbs up emojizhiqwang, xavierdmello, jwrh, and color88 reacted with laugh emojirabinadk1, akihironitta, ideaguy3d, wanderingeek, AngryLoki, skandermoalla, johnnv1, Totto16, Jamim, tymokvo, and 17 more reacted with hooray emojiakihironitta, ideaguy3d, samils7, Totto16, devanshkv, Jamim, evdcush, anthonyalayo, ArdeshirV, thomasjo, and 13 more reacted with heart emojiakihironitta, ideaguy3d, atalman, kayzliu, Totto16, gau-nernst, Jamim, evdcush, wanchaol, notnitsuj, and 17 more reacted with rocket emojizhiqwang, xavierdmello, gugarosa, and j316chuck reacted with eyes emoji

All reactions

- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)88 reactions
- ![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)4 reactions
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)27 reactions
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)23 reactions
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)27 reactions
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)4 reactions

129 people reacted

## PyTorch 2.1.2 Release, bug fix release

Dec 14, 2023
15 Dec 01:59


![@atalman](https://avatars.githubusercontent.com/u/7563158?s=40&v=4)[atalman](https://github.com/atalman)

[v2.1.2](https://github.com/pytorch/pytorch/tree/v2.1.2)

[`a8e7c98`](https://github.com/pytorch/pytorch/commit/a8e7c98cb95ff97bb30a728c6b2a1ce6bff946eb)

Compare

# Choose a tag to compare

## Sorry, something went wrong.

Filter

Loading

## Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

## No results found

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.1.2 Release, bug fix release](https://github.com/pytorch/pytorch/releases/tag/v2.1.2)

This release is meant to fix the following issues (regressions / silent correctness):

- Fix crashes for float16 empty tensors ( [#115183](https://github.com/pytorch/pytorch/pull/115183))
- Fix MPS memory corruption when working with tensor slices ( [#114838](https://github.com/pytorch/pytorch/pull/114838))
- Fix crashes during Conv backward pass on MPS devices ( [#113398](https://github.com/pytorch/pytorch/pull/113398))
- Partially fix nn.Linear behavior on AArch64 platform ( [#110150](https://github.com/pytorch/pytorch/pull/110150))
- Fix cosine\_similarity for tensors of different sizes ( [#109363](https://github.com/pytorch/pytorch/pull/109363))
- Package missing headers needed for extension development ( [#113055](https://github.com/pytorch/pytorch/pull/113055))
- Improve error handling of `torch.set_num_threads` ( [#113684](https://github.com/pytorch/pytorch/pull/113684))
- Fix profiling traces generation ( [#113763](https://github.com/pytorch/pytorch/pull/113763))

The Cherry pick tracker [#113962](https://github.com/pytorch/pytorch/issues/113962) contains all relevant pull requests related to this release as well as links to related issues.

Assets3

Loading

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

luncliff, tolgacangoz, rino2000, yhyu13, Abeautifulsnow, sirius777coder, YuCao16, vantienpham, botbw, BEaN001, and 29 more reacted with thumbs up emojijwrh and felipegargal reacted with laugh emojiMARD1NO, zhenrong-wang, anaximeno, gdippolito, 651961, DarkDumpTruck, hammaad2002, lucadiliello, and gadhvirushiraj reacted with hooray emojianurag12-webster, AhmadHakami, teuncm, vilsonrodrigues, Sai-Suraj-27, AntonioBerna, azevedoguigo, mjamroz, and donaldKelly17 reacted with heart emojiwangg12, gau-nernst, and lsrock1 reacted with rocket emoji

All reactions

- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)39 reactions
- ![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)2 reactions
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)9 reactions
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)9 reactions
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)3 reactions

58 people reacted

## PyTorch 2.1.1 Release, bug fix release

Nov 15, 2023
15 Nov 22:59


![@jerryzh168](https://avatars.githubusercontent.com/u/4958441?s=40&v=4)[jerryzh168](https://github.com/jerryzh168)

[v2.1.1](https://github.com/pytorch/pytorch/tree/v2.1.1)

[`4c55dc5`](https://github.com/pytorch/pytorch/commit/4c55dc50355d5e923642c59ad2a23d6ad54711e7)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.
The key has expired.


GPG key ID: 4AEE18F83AFDEB23

Expired

Verified
on Jan 16, 2024, 02:59 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

## Sorry, something went wrong.

Filter

Loading

## Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

## No results found

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.1.1 Release, bug fix release](https://github.com/pytorch/pytorch/releases/tag/v2.1.1)

This release is meant to fix the following issues (regressions / silent correctness):

- Remove spurious warning in comparison ops ( [#112170](https://github.com/pytorch/pytorch/pull/112170))
- Fix segfault in foreach\_\* operations when input list length does not match ( [#112349](https://github.com/pytorch/pytorch/pull/112349))
- Fix cuda driver API to load the appropriate .so file ( [#112996](https://github.com/pytorch/pytorch/pull/112996))
- Fix missing CUDA initialization when calling FFT operations ( [#110326](https://github.com/pytorch/pytorch/pull/110326))
- Ignore beartype==0.16.0 within the onnx package as it is incompatible ( [#111861](https://github.com/pytorch/pytorch/pull/111861))
- Fix the behavior of torch.new\_zeros in onnx due to TorchScript behavior change ( [#111694](https://github.com/pytorch/pytorch/pull/111694))
- Remove unnecessary slow code in `torch.distributed.checkpoint.optimizer.load_sharded_optimizer_state_dict` ( [#111687](https://github.com/pytorch/pytorch/pull/111687))
- Add `planner` argument to `torch.distributed.checkpoint.optimizer.load_sharded_optimizer_state_dict` ( [#111393](https://github.com/pytorch/pytorch/pull/111393))
- Continue if param not exist in sharded load in `torch.distributed.FSDP` ( [#109116](https://github.com/pytorch/pytorch/pull/109116))
- Fix handling of non-contiguous bias\_mask in `torch.nn.functional.scaled_dot_product_attention` ( [#112673](https://github.com/pytorch/pytorch/pull/112673))
- Fix the meta device implementation for `nn.functional.scaled_dot_product_attention` ( [#110893](https://github.com/pytorch/pytorch/pull/110893))
- Fix copy from mps to cpu device when storage\_offset is non-zero ( [#109557](https://github.com/pytorch/pytorch/pull/109557))
- Fix segfault in `torch.sparse.mm` for non-contiguous inputs ( [#111742](https://github.com/pytorch/pytorch/pull/111742))
- Fix circular import between Dynamo and einops ( [#110575](https://github.com/pytorch/pytorch/pull/110575))
- Verify flatbuffer module fields are initialized for mobile deserialization ( [#109794](https://github.com/pytorch/pytorch/pull/109794))

The [#110961](https://github.com/pytorch/pytorch/issues/110961) contains all relevant pull requests related to this release as well as links to related issues.

Assets3

Loading

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)60tayden, wanderingeek, jerryzh168, leslie-fang-intel, gau-nernst, YuanZhaohan, BrenoAV, ppogg, light-abc, luncliff, and 50 more reacted with thumbs up emoji![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)2jwrh and zhenrong-wang reacted with laugh emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)9wanderingeek, atalman, GrantorShadow, zhenrong-wang, ngdlmk, andrewlee302, markf94, SocioPJ, and HemanthSai7 reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)10MadScie254, wilhelmagren, xAlpharax, SocioPJ, M0nteCarl0, DanteDeLordran, HemanthSai7, cesardz1q84, yrmo, and Ramineon reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)11Nesasio, zhenrong-wang, Dxig, nairbv, debnath-d, SocioPJ, ianpark318, HemanthSai7, PasNinii, dangbert, and pavoltravnik reacted with rocket emoji

All reactions

- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)60 reactions
- ![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)2 reactions
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)9 reactions
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)10 reactions
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)11 reactions

78 people reacted

## PyTorch 2.1: automatic dynamic shape compilation, distributed checkpointing

Oct 4, 2023
04 Oct 17:32


![@jerryzh168](https://avatars.githubusercontent.com/u/4958441?s=40&v=4)[jerryzh168](https://github.com/jerryzh168)

[v2.1.0](https://github.com/pytorch/pytorch/tree/v2.1.0)

[`7bcf7da`](https://github.com/pytorch/pytorch/commit/7bcf7da3a268b435777fe87c7794c382f444e86d)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.
The key has expired.


GPG key ID: 4AEE18F83AFDEB23

Expired

Verified
on Jan 16, 2024, 02:59 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

## Sorry, something went wrong.

Filter

Loading

## Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

## No results found

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.1: automatic dynamic shape compilation, distributed checkpointing](https://github.com/pytorch/pytorch/releases/tag/v2.1.0)

# PyTorch 2.1 Release Notes

- Highlights
- Backwards Incompatible Change
- Deprecations
- New Features
- Improvements
- Bug fixes
- Performance
- Documentation
- Developers
- Security

# Highlights

We are excited to announce the release of PyTorch® 2.1! PyTorch 2.1 offers automatic dynamic shape support in torch.compile, torch.distributed.checkpoint for saving/loading distributed training jobs on multiple ranks in parallel, and torch.compile support for the NumPy API.

In addition, this release offers numerous performance improvements (e.g. CPU inductor improvements, AVX512 support, scaled-dot-product-attention support) as well as a prototype release of torch.export, a sound full-graph capture mechanism, and `torch.export`-based quantization.

Along with 2.1, we are also releasing a series of updates to the PyTorch domain libraries. More details can be found in the library updates blog.

This release is composed of 6,682 commits and 784 contributors since 2.0. We want to sincerely thank our dedicated community for your contributions. As always, we encourage you to try these out and report any issues as we improve 2.1. More information about how to get started with the PyTorch 2-series can be found at our [Getting Started](https://pytorch.org/get-started/pytorch-2.0/) page.

Summary:

- `torch.compile` now includes automatic support for detecting and minimizing recompilations due to tensor shape changes using automatic dynamic shapes.
- `torch.distributed.checkpoint` enables saving and loading models from multiple ranks in parallel, as well as resharding due to changes in cluster topology.
- `torch.compile` can now compile NumPy operations via translating them into PyTorch-equivalent operations.
- `torch.compile` now includes improved support for Python 3.11.
- New CPU performance features include inductor improvements (e.g. bfloat16 support and dynamic shapes), AVX512 kernel support, and scaled-dot-product-attention kernels.
- `torch.export`, a sound full-graph capture mechanism is introduced as a prototype feature, as well as torch.export-based quantization.
- `torch.sparse` now includes prototype support for semi-structured (2:4) sparsity on NVIDIA® GPUs.

|     |     |     |     |
| --- | --- | --- | --- |
| **Stable** | **Beta** | **Prototype** | **Performance Improvements** |
|  | Automatic Dynamic Shapes | torch.export() | AVX512 kernel support |
|  | torch.distributed.checkpoint | torch.export-based Quantization | CPU optimizations for scaled-dot-product-attention (SDPA) |
|  | torch.compile + NumPy | semi-structured (2:4) sparsity | CPU optimizations for bfloat16 |
|  | torch.compile + Python 3.11 | cpp\_wrapper for torchinductor |  |
|  | torch.compile + autograd.Function |  |  |
|  | third-party device integration: PrivateUse1 |  |  |

\*To see a full list of public 2.1, 2.0, and 1.13 feature submissions click [here](https://docs.google.com/spreadsheets/d/1TzGkWuUMF1yTe88adz1dt2mzbIsZLd3PBasy588VWgk/edit?usp=sharing).

For more details about these highlighted features, you can look at the release blogpost.

Below are the full release notes for this release.

# Backwards Incompatible Changes

### Building PyTorch from source now requires C++ 17 ( [\#100557](https://github.com/pytorch/pytorch/pull/100557))

The PyTorch codebase has migrated from the C++14 to the C++17 standard, so a C++17 compatible compiler is now required to compile PyTorch, to integrate with libtorch, or to implement a C++ PyTorch extension.

### Disable `torch.autograd.{backward, grad}` for complex scalar output ( [\#92753](https://github.com/pytorch/pytorch/pull/92753))

Gradients are not defined for functions that don't return real outputs; we now raise an error if you try to call backward on complex outputs. Previously, the complex component of the output was implicitly ignored. If you wish to preserve this behavior, you must now explicitly call `.real` on your complex outputs before calling `.grad()` or `.backward()`.

#### Example

```
def fn(x):
    return (x * 0.5j).sum()

x = torch.ones(1, dtype=torch.double, requires_grad=True)
o = fn(x)
```

#### 2.0.1

```
o.backward()
```

#### 2.1

```
o.real.backward()
```

### Update non-reentrant checkpoint to allow nesting and support `autograd.grad` ( [\#90105](https://github.com/pytorch/pytorch/pull/90105))

As a part of a larger refactor to `torch.utils.checkpoint`, we changed the interaction activation checkpoint and `retain_graph=True`. Previously in 2.0.1, recomputed activations are kept alive if `retain_graph=True`, in PyTorch 2.1, non-reentrant impl now clears recomputed tensors on backward immediately upon unpack, even if `retain_graph=True`. This has the following additional implications: (1) Accessing `ctx.saved_tensor` twice in the same backward will now raise an error. (2) Accessing `_saved_tensors` multiple times will silently recompute forward multiple times.

#### 2.1

```
class Func(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x):
        out = x.exp()
        ctx.save_for_backward(out)
        return out

    @staticmethod
    def backward(ctx, x);
        out, = ctx.saved_tensors
        # Calling ctx.saved_tensors again will raise in 2.1
        out, = ctx.saved_tensors
        return out

a = torch.tensor(1., requires_grad=True)

def fn(x):
    return Func.apply(x)

out = torch.utils.checkpoint(fn, (a,), use_reentrant=False)

def fn2(x):
    return x.exp()

out = torch.utils.checkpoint(fn2, (a,), use_reentrant=False)

out.grad_fn._saved_result
# Calling _saved_result will trigger another unpack, and lead to forward being
# recomputed again
out.grad_fn._saved_result
```

### Only sync buffers when `broadcast_buffers` is True ( [\#100729](https://github.com/pytorch/pytorch/pull/100729))

- In PyTorch 2.0.1 and previous releases, when users use DistributedDataParallel (DDP), all buffers were synced automatically even if users set flag `broadcast_buffers` to be `False`:

```
from torch.nn.parallel import DistributedDataParallel as DDP
module = torch.nn.Linear(4, 8)
module = DDP(module) # Buffer is synchronized across all devices.
module = DDP(module, broadcast_buffers=False) # Buffer is synchronized across all devices.
...
```

- Starting with PyTorch 2.1, if users specify the flag `broadcast_buffers` to be `False`, we don’t sync the buffer across devices:

```
from torch.nn.parallel import DistributedDataParallel as DDP
module = torch.nn.Linear(4, 8)
module = DDP(module) # Buffer is synchronized across all devices.
module = DDP(module, broadcast_buffers=False) # Buffer is NOT synchronized across all devices
...
```

### Remove store barrier after PG init ( [\#99937](https://github.com/pytorch/pytorch/pull/99937))

- In PyTorch 2.0.1 and previous releases, after we initialize PG, we always call store based barrier:

```
from torch.distributed.distributed_c10d import init_process_group
init_process_group(...) # Will call _store_based_barrier in the end.
...
```

- Starting with PyTorch 2.1, after we initialize PG, the environment variable `TORCH_DIST_INIT_BARRIER` controls whether we call store based barrier or not:

```
from torch.distributed.distributed_c10d import init_process_group
import os
os.environ["TORCH_DIST_INIT_BARRIER"] = "1" # This is the default behavior
init_process_group(...) # Will call _store_based_barrier in the end.
os.environ["TORCH_DIST_INIT_BARRIER"] = "0"
init_process_group(...) # Will not call _store_based_barrier in the end.
...
```

### Disallow non-bool masks in `torch.masked_{select, scatter, fill}` ( [\#96112](https://github.com/pytorch/pytorch/pull/96112), [\#97999](https://github.com/pytorch/pytorch/pull/97999), [\#96594](https://github.com/pytorch/pytorch/pull/96594))

Finish the deprecation cycle for non-bool masks. Functions now require the `dtype` of the mask to be `torch.bool`.

```
>>> # 2.0.1
>>> inp = torch.rand(3)
>>> mask = torch.tensor([0, 1, 0], dtype=torch.uint8)
>>> torch.masked_select(inp, mask)
UserWarning: masked_select received a mask with dtype torch.uint8, this behavior is now deprecated,please use a mask with dtype torch.bool instead. (Triggered internally at ../aten/src/ATen/native/TensorAdvancedIndexing.cpp:1855.)
  torch.masked_select(inp, mask)

>>> torch.masked_select(inp, mask.to(dtype=torch.bool))
# Works fine

>>> correct_mask = torch.tensor([0, 1, 0], dtype=torch.bool)
>>> torch.masked_select(inp, correct_mask)
# Works fine

>>> # 2.1
>>> inp = torch.rand(3)
>>> mask = torch.tensor([0, 1, 0], dtype=torch.uint8)
>>> torch.masked_select(inp, mask)
RuntimeError: masked_select: expected BoolTensor for mask

>>> correct_mask = torch.tensor([0, 1, 0], dtype=torch.bool)
>>> torch.masked_select(inp, correct_mask)
# Works fine

>>> torch.masked_select(inp, mask.to(dtype=torch.bool))
# Works fine
```

### Fix the result of `torch.unique` to make it consistent with NumPy when `dim` is specified ( [\#101693](https://github.com/pytorch/pytorch/pull/101693))

The `dim` argument was clarified and its behavior aligned to match the one from NumPy to signify which sub-tensor to consider when considering uniqueness. See the documentation for more details, [https://pytorch.org/docs/stable/generated/torch.unique.html](https://pytorch.org/docs/stable/generated/torch.unique.html)

### Make the Index Rounding Mode Consistent Between the 2D and 3D GridSample Nearest Neighbor Interpolations ( [\#97000](https://github.com/pytorch/pytorch/pull/97000))

Prior to this change, for `torch.nn.functional.grid_sample(mode='nearest')` the forward 2D kernel used `std::nearbyint` whereas the forward 3D kernel used `std::round` in order to determine the nearest pixel locations after un-normalization of the grid. Additionally, the backward kernels for both ...

[Read more](https://github.com/pytorch/pytorch/releases/tag/v2.1.0)

Assets3

Loading

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)80kit1980, zhxchen17, qing-shang, egesko, alexeykudinkin, Fissium, QuanyiLi, vfdev-5, iceychris, ferraridamiano, and 70 more reacted with thumbs up emoji![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)59bow, zhiqwang, Abiodun-code, xfo-0, and zhangboSJTU reacted with laugh emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)46khushi-411, nviraj, duanzhiihao, janosh, khiner, atalman, lazyoracle, iceychris, QuanyiLi, dineshpinto, and 36 more reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)29khushi-411, nviraj, simpleParadox, duanzhiihao, khiner, egesko, iceychris, 9bow, prm-james-hill, toastertaster, and 19 more reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)29ilya16, gugarosa, ngdlmk, iceychris, rishub-tamirisa, HennerM, Separius, 9bow, George614, prm-james-hill, and 19 more reacted with rocket emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)9wangg12, zhiqwang, luncliff, csukuangfj, Abiodun-code, risingwen, tolgacangoz, clecust, and zhangboSJTU reacted with eyes emoji

All reactions

- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)80 reactions
- ![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)5 reactions
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)46 reactions
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)29 reactions
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)29 reactions
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)9 reactions

138 people reacted

## PyTorch 2.0.1 Release, bug fix release

May 8, 2023
08 May 19:55


![@drisspg](https://avatars.githubusercontent.com/u/32754868?s=40&v=4)[drisspg](https://github.com/drisspg)

[v2.0.1](https://github.com/pytorch/pytorch/tree/v2.0.1)

[`e9ebda2`](https://github.com/pytorch/pytorch/commit/e9ebda29d87ce0916ab08c06ab26fd3766a870e5)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.
The key has expired.


GPG key ID: 4AEE18F83AFDEB23

Expired

Verified
on Nov 6, 2024, 01:28 AM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

## Sorry, something went wrong.

Filter

Loading

## Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

## No results found

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.0.1 Release, bug fix release](https://github.com/pytorch/pytorch/releases/tag/v2.0.1)

This release is meant to fix the following issues (regressions / silent correctness):

- Fix `_canonical_mask` throws warning when bool masks passed as input to TransformerEncoder/TransformerDecoder ( [#96009](https://github.com/pytorch/pytorch/pull/96009), [#96286](https://github.com/pytorch/pytorch/pull/96286))
- Fix Embedding bag max\_norm=-1 causes leaf Variable that requires grad is being used in an in-place operation [#95980](https://github.com/pytorch/pytorch/pull/95980)
- Fix type hint for torch.Tensor.grad\_fn, which can be a torch.autograd.graph.Node or None. [#96804](https://github.com/pytorch/pytorch/pull/96804)
- Can’t convert float to int when the input is a scalar np.ndarray. [#97696](https://github.com/pytorch/pytorch/pull/97696)
- Revisit torch.\_six.string\_classes removal [#97863](https://github.com/pytorch/pytorch/pull/97863)
- Fix module backward pre-hooks to actually update gradient [#97983](https://github.com/pytorch/pytorch/pull/97983)
- Fix load\_sharded\_optimizer\_state\_dict error on multi node [#98063](https://github.com/pytorch/pytorch/pull/98063)
- Warn once for TypedStorage deprecation [#98777](https://github.com/pytorch/pytorch/pull/98777)
- cuDNN V8 API, Fix incorrect use of emplace in the benchmark cache [#97838](https://github.com/pytorch/pytorch/pull/97838)

### Torch.compile:

- Add support for Modules with custom **getitem** method to torch.compile [#97932](https://github.com/pytorch/pytorch/pull/97932)
- Fix improper guards with on list variables. [#97862](https://github.com/pytorch/pytorch/pull/97862)
- Fix Sequential nn module with duplicated submodule [#98880](https://github.com/pytorch/pytorch/pull/98880)

### Distributed:

- Fix distributed\_c10d's handling of custom backends [#95072](https://github.com/pytorch/pytorch/pull/95072)
- Fix MPI backend not properly initialized [#98545](https://github.com/pytorch/pytorch/pull/98545)

### NN\_frontend:

- Update Multi-Head Attention's doc string [#97046](https://github.com/pytorch/pytorch/pull/97046)
- Fix incorrect behavior of `is_causal` paremeter for torch.nn.TransformerEncoderLayer.forward [#97214](https://github.com/pytorch/pytorch/pull/97214)
- Fix error for SDPA on sm86 and sm89 hardware [#99105](https://github.com/pytorch/pytorch/pull/99105)
- Fix nn.MultiheadAttention mask handling [#98375](https://github.com/pytorch/pytorch/pull/98375)

### DataLoader:

- Fix regression for pin\_memory recursion when operating on bytes [#97737](https://github.com/pytorch/pytorch/pull/97737)
- Fix collation logic [#97789](https://github.com/pytorch/pytorch/pull/97789)
- Fix Ppotentially backwards incompatible change with DataLoader and is\_shardable Datapipes [#97287](https://github.com/pytorch/pytorch/pull/97287)

### MPS:

- Fix LayerNorm crash when input is in float16 [#96208](https://github.com/pytorch/pytorch/pull/96208)
- Add support for cumsum on int64 input [#96733](https://github.com/pytorch/pytorch/pull/96733)
- Fix issue with setting BatchNorm to non-trainable [#98794](https://github.com/pytorch/pytorch/pull/98794)

### Functorch:

- Fix Segmentation Fault for vmaped function accessing BatchedTensor.data [#97237](https://github.com/pytorch/pytorch/pull/97237)
- Fix index\_select support when dim is negative [#97916](https://github.com/pytorch/pytorch/pull/97916)
- Improve docs for autograd.Function support [#98020](https://github.com/pytorch/pytorch/pull/98020)
- Fix Exception thrown when running Migration guide example for jacrev [#97746](https://github.com/pytorch/pytorch/pull/97746)

### Releng:

- Fix Convolutions for CUDA-11.8 wheel builds [#99451](https://github.com/pytorch/pytorch/pull/99451)
- Fix Import torchaudio + torch.compile crashes on exit [#96231](https://github.com/pytorch/pytorch/pull/96231)
- Linux aarch64 wheels are missing the mkldnn+acl backend support - [pytorch/builder@ `54931c2`](https://github.com/pytorch/builder/commit/54931c264ed3e7346899f547a272c4329cc8933b)
- Linux aarch64 torchtext 0.15.1 wheels are missing for aarch64\_linux platform - [pytorch/builder#1375](https://github.com/pytorch/builder/issues/1375)
- Enable ROCm 5.4.2 manywheel and python 3.11 builds [#99552](https://github.com/pytorch/pytorch/pull/99552)
- PyTorch cannot be installed at the same time as numpy in a conda env on osx-64 / Python 3.11 [#97031](https://github.com/pytorch/pytorch/issues/97031)
- Illegal instruction (core dumped) on Raspberry Pi 4.0 8gb - [pytorch/builder#1370](https://github.com/pytorch/builder/pull/1370)

### Torch.optim:

- Fix fused AdamW causes NaN loss [#95847](https://github.com/pytorch/pytorch/pull/95847)
- Fix Fused AdamW has worse loss than Apex and unfused AdamW for fp16/AMP [#98620](https://github.com/pytorch/pytorch/pull/98620)

The [release tracker](https://github.com/pytorch/pytorch/issues/97272) should contain all relevant pull requests related to this release as well as links to related issues

Assets3

Loading

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)87mwanjajoel, snario, vfdev-5, johnnynunez, anaximeno, YuCao16, yoshoku, houseme, mrverdant13, prat96, and 77 more reacted with thumbs up emoji![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)4GreenSlime1024, jwrh, Voyajer, and CaoHaiNam reacted with laugh emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)26atalman, johnnv1, Forbu, YuCao16, mrverdant13, thevasudevgupta, heyaudace, zhiqwang, 9bow, PennyFranklin, and 16 more reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)16zhiqwang, 9bow, valeriocardoso, PennyFranklin, khushi-411, smbl64, GreenSlime1024, ingo-m, yjianzhu, kris-gzy, and 6 more reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)16zhiqwang, 9bow, PennyFranklin, semaphore-egg, lbluque, iamabhaytiwari343, GreenSlime1024, hal-314, superherointj, FNsi, and 6 more reacted with rocket emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)4GreenSlime1024, Voyajer, davidboudinp, and tolgacangoz reacted with eyes emoji

All reactions

- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)87 reactions
- ![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)4 reactions
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)26 reactions
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)16 reactions
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)16 reactions
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)4 reactions

113 people reacted

## PyTorch 2.0: Our next generation release that is faster, more Pythonic and Dynamic as ever

Mar 15, 2023
15 Mar 19:38


![@drisspg](https://avatars.githubusercontent.com/u/32754868?s=40&v=4)[drisspg](https://github.com/drisspg)

[v2.0.0](https://github.com/pytorch/pytorch/tree/v2.0.0)

[`c263bd4`](https://github.com/pytorch/pytorch/commit/c263bd43e8e8502d4726643bc6fd046f0130ac0e)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.
The key has expired.


GPG key ID: 4AEE18F83AFDEB23

Expired

Verified
on Nov 5, 2024, 08:54 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

## Sorry, something went wrong.

Filter

Loading

## Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

## No results found

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.0: Our next generation release that is faster, more Pythonic and Dynamic as ever](https://github.com/pytorch/pytorch/releases/tag/v2.0.0)

# PyTorch 2.0 Release notes

- Highlights
- Backwards Incompatible Changes
- Deprecations
- New Features
- Improvements
- Bug fixes
- Performance
- Documentation

# Highlights

We are excited to announce the release of PyTorch® 2.0 ( [release note](https://github.com/pytorch/pytorch/releases)) which we highlighted during the [PyTorch Conference](https://www.youtube.com/@PyTorch/playlists?view=50&sort=dd&shelf_id=2) on 12/2/22! PyTorch 2.0 offers the same eager-mode development and user experience, while fundamentally changing and supercharging how PyTorch operates at compiler level under the hood with faster performance and support for Dynamic Shapes and Distributed.

This next-generation release includes a Stable version of Accelerated Transformers (formerly called Better Transformers); Beta includes torch.compile as the main API for PyTorch 2.0, the scaled\_dot\_product\_attention function as part of torch.nn.functional, the MPS backend, functorch APIs in the torch.func module; and other Beta/Prototype improvements across various inferences, performance and training optimization features on GPUs and CPUs. For a comprehensive introduction and technical overview of torch.compile, please visit the 2.0 [Get Started page](https://pytorch.org/get-started/pytorch-2.0).

Along with 2.0, we are also releasing a series of beta updates to the PyTorch domain libraries, including those that are in-tree, and separate libraries including TorchAudio, TorchVision, and TorchText. An update for TorchX is also being released as it moves to community supported mode. More details can be found in this [library blog](https://pytorch.org/blog/new-library-updates-in-pytorch-2.0/).

This release is composed of over 4,541 commits and 428 contributors since 1.13.1. We want to sincerely thank our dedicated community for your contributions. As always, we encourage you to try these out and report any issues as we improve 2.0 and the overall 2-series this year.

Summary:

- torch.compile is the main API for PyTorch 2.0, which wraps your model and returns a compiled model. It is a fully additive (and optional) feature and hence 2.0 is 100% backward compatible by definition.
- As an underpinning technology of torch.compile, TorchInductor with Nvidia and AMD GPUs will rely on OpenAI Triton deep learning compiler to generate performant code and hide low level hardware details. OpenAI Triton-generated kernels achieve performance that's on par with hand-written kernels and specialized cuda libraries such as cublas.
- Accelerated Transformers introduce high-performance support for training and inference using a custom kernel architecture for scaled dot product attention (SPDA). The API is integrated with torch.compile() and model developers may also use the [scaled dot product attention](https://pytorch.org/docs/2.0/generated/torch.nn.functional.scaled_dot_product_attention.html) kernels directly by calling the new scaled\_dot\_product\_attention() operator.
- Metal Performance Shaders (MPS) backend provides GPU accelerated PyTorch training on Mac platforms with added support for Top 60 most used ops, bringing coverage to over 300 operators.
- Amazon AWS optimize the PyTorch CPU inference on AWS Graviton3 based [C7g instances](https://aws.amazon.com/blogs/aws/new-amazon-ec2-c7g-instances-powered-by-aws-graviton3-processors/). PyTorch 2.0 improves inference performance on Graviton compared to the previous releases, including improvements for Resnet50 and Bert.
- New prototype features and technologies across TensorParallel, DTensor, 2D parallel, TorchDynamo, AOTAutograd, PrimTorch and TorchInductor.

|     |     |     |     |
| --- | --- | --- | --- |
| **Stable** | **Beta** | **Prototype** | **Platform Changes** |
| Accelerated PT 2 Transformers | torch.compile | DTensor | CUDA support for 11.7 & 11.8 (deprecating CUDA 11.6) |
|  | PyTorch MPS Backend | TensorParallel | Python 3.8 (deprecating Python 3.7) |
|  | Scaled dot product attention | 2D Parallel | AWS Graviton3 |
|  | Functorch | Torch.compile (dynamic=True) |  |
|  | Dispatchable Collectives |  |
|  | torch.set\_default\_device and torch.device as context manager |  |  |
|  | X86 quantization backend |  |  |
|  | GNN inference and training performance |  |  |

\*To see a full list of public 2.0, 1.13 and 1.12 feature submissions click [here](https://docs.google.com/spreadsheets/d/1H3jazwO8BBCwK8JwLNYspLiHfUrzshEtyqjL-X93I9g/edit#gid=790902532)

# Backwards Incompatible Changes

### **Drop support for Python versions <= 3.7 ( [\#93155](https://github.com/pytorch/pytorch/pull/93155))**

Previously the minimum supported version of Python for PyTorch was 3.7. This PR updates the minimum version to require 3.8 in order to install PyTorch. See [Hardware / Software Support](https://github.com/pytorch/pytorch/blob/893aa5df3f2a475c91ea8eadb1353812e52fb227/RELEASE.md#python) for more information.

### **Drop support for CUDA 10 ( [\#89582](https://github.com/pytorch/pytorch/pull/89582))**

This PR updates the minimum CUDA version to 11.0. See the [getting-started](https://pytorch.org/get-started/locally/) for installation or [building from source](https://github.com/pytorch/pytorch#from-source) for more information.

### **Gradients are now set to `None` instead of zeros by default in `torch.optim.*.zero_grad()` and `torch.nn.Module.zero_grad()` ( [\#92731](https://github.com/pytorch/pytorch/pull/92731))**

This changes the default behavior of `zero_grad()` to zero out the grads by setting them to `None` instead of zero tensors. In other words, the `set_to_none` kwarg is now `True` by default instead of `False`. Setting grads to `None` reduces peak memory usage and increases performance. This will break code that directly accesses data or does computation on the grads after calling `zero_grad()` as they will now be `None`. To revert to the old behavior, pass in `zero_grad(set_to_none=False)`.

| 1.13 | 2.0 |
| --- | --- |
| ```<br>>>> import torch<br>>>> from torch import nn<br>>>> module = nn.Linear(2,22)<br>>>> i = torch.randn(2, 2, requires_grad=True)<br>>>> module(i).sum().backward()<br>>>> module.zero_grad()<br>>>> module.weight.grad == None<br>False<br>>>> module.weight.grad.data<br>tensor([[0., 0.],<br>        [0., 0.]])<br>>>> module.weight.grad + 1.0<br>tensor([[1., 1.],<br>        [1., 1.]])<br>``` | ```<br>>>> import torch<br>>>> from torch import nn<br>>>> module = nn.Linear(5, 5)<br>>>> i = torch.randn(2, 5, requires_grad=True)<br>>>> module(i).sum().backward()<br>>>> module.zero_grad()<br>>>> module.weight.grad == None<br>True<br>>>> module.weight.grad.data<br>AttributeError: 'NoneType' object has no attribute 'data'<br>>>> module.weight.grad + 1.0<br>TypeError: unsupported operand type(s) for +:<br>'NoneType' and 'float'<br>``` |

### **Update `torch.tensor` and `nn.Parameter` to serialize all their attributes ( [\#88913](https://github.com/pytorch/pytorch/pull/88913))**

Any attribute stored on `torch.tensor` and `torch.nn.Parameter` will now be serialized. This aligns the serialization behavior of `torch.nn.Parameter`, `torch.Tensor` and other tensor subclasses

| 1.13 | 2.0 |
| --- | --- |
| ```<br># torch.Tensor behavior<br>>>> a = torch.Tensor()<br>>>> a.foo = 'hey'<br>>>> buffer = io.BytesIO()<br>>>> torch.save(a, buffer)<br>>>> buffer.seek(0)<br>>>> b = torch.load(buffer)<br>>>> print(a.foo)<br>hey<br>>>> print(b.foo)<br>AttributeError: 'Tensor' object has no attribute 'foo'<br># torch.nn.Parameter behavior<br>>>> a = nn.Parameter()<br>>>> a.foo = 'hey'<br>>>> buffer = io.BytesIO()<br>>>> torch.save(a, buffer)<br>>>> buffer.seek(0)<br>>>> b = torch.load(buffer)<br>>>> print(a.foo)<br>hey<br>>>> print(b.foo)<br>AttributeError: 'Parameter' object has no attribute 'foo'<br># torch.Tensor subclass behavior<br>>>> class MyTensor(torch.Tensor):<br>...   pass<br>>>> a = MyTensor()<br>>>> a.foo = 'hey'<br>>>> print(a.foo)<br>hey<br>>>> buffer = io.BytesIO()<br>>>> torch.save(a, buffer)<br>>>> buffer.seek(0)<br>>>> b = torch.load(buffer)<br>>>>print(b.foo)<br>hey<br>``` | ```<br># torch.Tensor behavior<br>a = torch.Tensor()<br>a.foo = 'hey'<br>>>> buffer = io.BytesIO()<br>>>> torch.save(a, buffer)<br>>>> buffer.seek(0)<br>>>> b = torch.load(buffer)<br>>>> print(a.foo)<br>hey<br>>>> print(b.foo)<br>hey<br># torch.nn.Parameter behavior<br>>>> a = nn.Parameter()<br>>>> a.foo = 'hey'<br>>>> buffer = io.BytesIO()<br>>>> torch.save(a, buffer)<br>>>> buffer.seek(0)<br>>>> b = torch.load(buffer)<br>>>> print(a.foo)<br>hey<br>>>> print(b.foo)<br>hey<br># torch.Tensor subclass behavior<br>>>> class MyTensor(torch.Tensor):<br>...   pass<br>>>> a = MyTensor()<br>>>> a.foo = 'hey'<br>>>> print(a.foo)<br>hey<br>>>> buffer = io.BytesIO()<br>>>> torch.save(a, buffer)<br>>>> buffer.seek(0)<br>>>> b = torch.load(buffer)<br>>>>print(b.foo)<br>hey<br>``` |

If you have an attribute that you don't want to be serialized you should not store it as an attribute on tensor or Parameter but instead it is recommended to use `torch.utils.weak.WeakTensorKeyDictionary`

```
>>> foo_dict = weak.WeakTensorKeyDictionary()
>>> foo_dict[a] = 'hey'
>>> print(foo_dict[a])
hey
```

### **Algorithms `{Adadelta, Adagrad, Adam, Adamax, AdamW, ASGD, NAdam, RAdam, RMSProp, RProp, SGD}` default to faster `foreach` implementation when on CUDA + differentiable= `False`**

When applicable, this changes the default behavior of `step()` and anything that ca...

[Read more](https://github.com/pytorch/pytorch/releases/tag/v2.0.0)

### Contributors

- [![@pytorch](https://avatars.githubusercontent.com/u/21003710?s=64&v=4)](https://github.com/pytorch)

pytorch


Assets3

Loading

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=2).

![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)56nps1ngh, cyyever, Enigmatisms, fredbjer, lazyoracle, james77777778, Looong01, zhiqwang, abhi-glitchhg, Zerohertz, and 46 more reacted with thumbs up emoji![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)1jwrh reacted with laugh emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)118duanzhiihao, WoosukKwon, kashif, jisaacso, johnnv1, aikow, Syntax3rror404, cossio, baurst, ashvardanian, and 108 more reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)40stephenroller, Djdefrag, kshitij12345, igreat, orionr, morelen17, ffelten, atalman, Ludougan123234, akihironitta, and 30 more reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)50weiji14, johnnv1, Cam-B04, aikow, cossio, chester-tan, stephenroller, igreat, kevalmorabia97, ilya16, and 40 more reacted with rocket emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)13mhasan502, abhi-glitchhg, bckim92, RyanHir, semaphore-egg, kaparoo, aredden, jihaohaaaa, qqwqqw689, Zhiy-Zhang, and 3 more reacted with eyes emoji

All reactions

- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)56 reactions
- ![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)1 reaction
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)118 reactions
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)40 reactions
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)50 reactions
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)13 reactions

185 people reacted

## PyTorch 1.13.1 Release, small bug fix release

Dec 15, 2022
16 Dec 00:17


![@atalman](https://avatars.githubusercontent.com/u/7563158?s=40&v=4)[atalman](https://github.com/atalman)

[v1.13.1](https://github.com/pytorch/pytorch/tree/v1.13.1)

[`49444c3`](https://github.com/pytorch/pytorch/commit/49444c3e546bf240bed24a101e747422d1f8a0ee)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.
The key has expired.


GPG key ID: 4AEE18F83AFDEB23

Expired

Verified
on Jan 16, 2024, 02:59 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 1.13.1 Release, small bug fix release](https://github.com/pytorch/pytorch/releases/tag/v1.13.1)

This release is meant to fix the following issues (regressions / silent correctness):

- RuntimeError by torch.nn.modules.activation.MultiheadAttention with bias=False and batch\_first=True [#88669](https://github.com/pytorch/pytorch/issues/88669)
- Installation via pip on Amazon Linux 2, regression [#88869](https://github.com/pytorch/pytorch/issues/88869)
- Installation using poetry on Mac M1, failure [#88049](https://github.com/pytorch/pytorch/issues/88049)
- Missing masked tensor documentation [#89734](https://github.com/pytorch/pytorch/issues/89734)
- torch.jit.annotations.parse\_type\_line is not safe (command injection) [#88868](https://github.com/pytorch/pytorch/issues/88868)
- Use the Python frame safely in \_pythonCallstack [#88993](https://github.com/pytorch/pytorch/pull/88993)
- Double-backward with full\_backward\_hook causes RuntimeError [#88312](https://github.com/pytorch/pytorch/issues/88312)
- Fix logical error in get\_default\_qat\_qconfig [#88876](https://github.com/pytorch/pytorch/pull/88876)
- Fix cuda/cpu check on NoneType and unit test [#88854](https://github.com/pytorch/pytorch/pull/88854) and [#88970](https://github.com/pytorch/pytorch/pull/88970)
- Onnx ATen Fallback for BUILD\_CAFFE2=0 for ONNX-only ops [#88504](https://github.com/pytorch/pytorch/pull/88504)
- Onnx operator\_export\_type on the new registry [#87735](https://github.com/pytorch/pytorch/pull/87735)
- torchrun AttributeError caused by file\_based\_local\_timer on Windows [#85427](https://github.com/pytorch/pytorch/issues/85427)

The [release tracker](https://github.com/pytorch/pytorch/issues/89855) should contain all relevant pull requests related to this release as well as links to related issues



![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)8creativeautomaton, MinhuiWan, Mitradeep2, Whaleer, lin72h, tolgacangoz, scarecrow-my, and angelseblani reacted with thumbs up emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)31akihironitta, ahmadmustafaanis, speedcell4, niklas-rittmann, TYH71, JulesGM, vict0rsch, tscholak, henrry179, hitenkoku, and 21 more reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)7chrislemke, leecs0503, MinhuiWan, Whaleer, lin72h, tolgacangoz, and FelipeFTN reacted with heart emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)3k9sret, tolgacangoz, and ren-pin reacted with eyes emoji

All reactions

- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)8 reactions
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)31 reactions
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)7 reactions
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)3 reactions

39 people reacted

[Previous](https://github.com/pytorch/pytorch/releases?page=1) [1](https://github.com/pytorch/pytorch/releases?page=1) _2_ [3](https://github.com/pytorch/pytorch/releases?page=3) [4](https://github.com/pytorch/pytorch/releases?page=4) [5](https://github.com/pytorch/pytorch/releases?page=5) [6](https://github.com/pytorch/pytorch/releases?page=6) [7](https://github.com/pytorch/pytorch/releases?page=7) [Next](https://github.com/pytorch/pytorch/releases?page=3)

[Previous](https://github.com/pytorch/pytorch/releases?page=1) [Next](https://github.com/pytorch/pytorch/releases?page=3)

## Footer

[GitHub Homepage](https://github.com/)
© 2025 GitHub, Inc.

