[Skip to content](https://github.com/pytorch/pytorch/releases?page=3#start-of-content)

## Navigation Menu

Toggle navigation

[Homepage](https://github.com/)

[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fpytorch%2Fpytorch%2Freleases%3Fpage%3D3)

Appearance settings

- Platform









- [GitHub Copilot\\
\\
\\
\\
Write better code with AI](https://github.com/features/copilot)
- [GitHub Spark\\
\\
\\
New\\
\\
\\
Build and deploy intelligent apps](https://github.com/features/spark)
- [GitHub Models\\
\\
\\
New\\
\\
\\
Manage and compare prompts](https://github.com/features/models)
- [GitHub Advanced Security\\
\\
\\
\\
Find and fix vulnerabilities](https://github.com/security/advanced-security)
- [Actions\\
\\
\\
\\
Automate any workflow](https://github.com/features/actions)

- [Codespaces\\
\\
\\
\\
Instant dev environments](https://github.com/features/codespaces)
- [Issues\\
\\
\\
\\
Plan and track work](https://github.com/features/issues)
- [Code Review\\
\\
\\
\\
Manage code changes](https://github.com/features/code-review)
- [Discussions\\
\\
\\
\\
Collaborate outside of code](https://github.com/features/discussions)
- [Code Search\\
\\
\\
\\
Find more, search less](https://github.com/features/code-search)

Explore

- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com/)
- [GitHub Skills](https://skills.github.com/)
- [Blog](https://github.blog/)

Integrations

- [GitHub Marketplace](https://github.com/marketplace)
- [MCP Registry](https://github.com/mcp)

[View all features](https://github.com/features)

- Solutions







By company size

- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)

By use case

- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)

By industry

- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)

[View all solutions](https://github.com/solutions)

- Resources







Topics

- [AI](https://github.com/resources/articles?topic=ai)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [View all](https://github.com/resources/articles)

Explore

- [Learning Pathways](https://resources.github.com/learn/pathways)
- [Events & Webinars](https://github.com/resources/events)
- [Ebooks & Whitepapers](https://github.com/resources/whitepapers)
- [Customer Stories](https://github.com/customer-stories)
- [Partners](https://github.com/partners)
- [Executive Insights](https://github.com/solutions/executive-insights)

- Open Source









- [GitHub Sponsors\\
\\
\\
\\
Fund open source developers](https://github.com/sponsors)

- [The ReadME Project\\
\\
\\
\\
GitHub community articles](https://github.com/readme)

Repositories

- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)

- Enterprise









- [Enterprise platform\\
\\
\\
\\
AI-powered developer platform](https://github.com/enterprise)

Available add-ons

- [GitHub Advanced Security\\
\\
\\
\\
Enterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for business\\
\\
\\
\\
Enterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium Support\\
\\
\\
\\
Enterprise-grade 24/7 support](https://github.com/premium-support)

- [Pricing](https://github.com/pricing)

Search or jump to...

# Search code, repositories, users, issues, pull requests...

Search


Clear

[Search syntax tips](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax)

# Provide feedback

We read every piece of feedback, and take your input very seriously.

Include my email address so I can be contacted

Cancel
Submit feedback

# Saved searches

## Use saved searches to filter your results more quickly

Name

Query

To see all available qualifiers, see our [documentation](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax).


Cancel
Create saved search

[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fpytorch%2Fpytorch%2Freleases%3Fpage%3D3)

[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=header+logged+out&ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E%2Freleases%2Findex&source=header-repo&source_repo=pytorch%2Fpytorch)

Appearance settings

Resetting focus

You signed in with another tab or window. [Reload](https://github.com/pytorch/pytorch/releases?page=3) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/pytorch/pytorch/releases?page=3) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/pytorch/pytorch/releases?page=3) to refresh your session.Dismiss alert

{{ message }}

[pytorch](https://github.com/pytorch)/ **[pytorch](https://github.com/pytorch/pytorch)** Public

- Couldn't load subscription status.
Retry

- [Fork\\
25.7k](https://github.com/login?return_to=%2Fpytorch%2Fpytorch)
- [Star\\
94.3k](https://github.com/login?return_to=%2Fpytorch%2Fpytorch)


- [Code](https://github.com/pytorch/pytorch)
- [Issues5k+](https://github.com/pytorch/pytorch/issues)
- [Pull requests1.5k](https://github.com/pytorch/pytorch/pulls)
- [Actions](https://github.com/pytorch/pytorch/actions)
- [Projects12](https://github.com/pytorch/pytorch/projects)
- [Wiki](https://github.com/pytorch/pytorch/wiki)
- [Security4](https://github.com/pytorch/pytorch/security)






[**Uh oh!**](https://github.com/pytorch/pytorch/security)

[There was an error while loading.](https://github.com/pytorch/pytorch/security) [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).

- [Insights](https://github.com/pytorch/pytorch/pulse)

Additional navigation options

- [Code](https://github.com/pytorch/pytorch)
- [Issues](https://github.com/pytorch/pytorch/issues)
- [Pull requests](https://github.com/pytorch/pytorch/pulls)
- [Actions](https://github.com/pytorch/pytorch/actions)
- [Projects](https://github.com/pytorch/pytorch/projects)
- [Wiki](https://github.com/pytorch/pytorch/wiki)
- [Security](https://github.com/pytorch/pytorch/security)
- [Insights](https://github.com/pytorch/pytorch/pulse)

# Releases: pytorch/pytorch

[Releases](https://github.com/pytorch/pytorch/releases) [Tags](https://github.com/pytorch/pytorch/tags)

Releases · pytorch/pytorch

## PyTorch 1.13: beta versions of functorch and improved support for Apple’s new M1 chips are now available

Oct 28, 2022
28 Oct 16:54


![@mikaylagawarecki](https://avatars.githubusercontent.com/u/35276741?s=40&v=4)[mikaylagawarecki](https://github.com/mikaylagawarecki)

[v1.13.0](https://github.com/pytorch/pytorch/tree/v1.13.0)

[`7c98e70`](https://github.com/pytorch/pytorch/commit/7c98e70d44abc7a1aead68b6ea6c8adc8c554db5)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.
The key has expired.


GPG key ID: 4AEE18F83AFDEB23

Expired

Verified
on Jan 16, 2024, 02:59 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

## Sorry, something went wrong.

Filter

Loading

## Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).

## No results found

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 1.13: beta versions of functorch and improved support for Apple’s new M1 chips are now available](https://github.com/pytorch/pytorch/releases/tag/v1.13.0)

# Pytorch 1.13 Release Notes

- Highlights
- Backwards Incompatible Changes
- New Features
- Improvements
- Performance
- Documentation
- Developers

# Highlights

We are excited to announce the release of PyTorch 1.13! This includes stable versions of BetterTransformer. We deprecated CUDA 10.2 and 11.3 and completed migration of CUDA 11.6 and 11.7. Beta includes improved support for Apple M1 chips and functorch, a library that offers composable vmap (vectorization) and autodiff transforms, being included in-tree with the PyTorch release. This release is composed of over 3,749 commits and 467 contributors since 1.12.1. We want to sincerely thank our dedicated community for your contributions.

Summary:

- The BetterTransformer feature set supports fastpath execution for common Transformer models during Inference out-of-the-box, without the need to modify the model. Additional improvements include accelerated add+matmul linear algebra kernels for sizes commonly used in Transformer models and Nested Tensors is now enabled by default.

- Timely deprecating older CUDA versions allows us to proceed with introducing the latest CUDA version as they are introduced by Nvidia®, and hence allows support for C++17 in PyTorch and new NVIDIA Open GPU Kernel Modules.

- Previously, functorch was released out-of-tree in a separate package. After installing PyTorch, a user will be able to `import functorch` and use functorch without needing to install another package.

- PyTorch is offering native builds for Apple® silicon machines that use Apple's new M1 chip as a beta feature, providing improved support across PyTorch's APIs.


| Stable | Beta | Prototype |
| --- | --- | --- |
| - Better Transformer<br>- CUDA 10.2 and 11.3 CI/CD Deprecation | - Enable Intel® VTune™ Profiler's Instrumentation and Tracing Technology APIs<br>- Extend NNC to support channels last and bf16<br>- Functorch now in PyTorch Core Library<br>- Beta Support for M1 devices | - Arm® Compute Library backend support for AWS Graviton<br>- CUDA Sanitizer |

You can check the blogpost that shows the new features [here](https://pytorch.org/blog/PyTorch-1.13-release/).

# Backwards Incompatible changes

## Python API

### **uint8 and all integer dtype masks are no longer allowed in Transformer** **( [\#87106](https://github.com/pytorch/pytorch/pull/87106))**

Prior to 1.13, `key_padding_mask` could be set to uint8 or other integer dtypes in `TransformerEncoder` and `MultiheadAttention`, which might generate unexpected results. In this release, these dtypes are not allowed for the mask anymore. Please convert them to `torch.bool` before using.

1.12.1

```
>>> layer = nn.TransformerEncoderLayer(2, 4, 2)
>>> encoder = nn.TransformerEncoder(layer, 2)
>>> pad_mask = torch.tensor([[1, 1, 0, 0]], dtype=torch.uint8)
>>> inputs = torch.cat([torch.randn(1, 2, 2), torch.zeros(1, 2, 2)], dim=1)
# works before 1.13
>>> outputs = encoder(inputs, src_key_padding_mask=pad_mask)
```

1.13

```
>>> layer = nn.TransformerEncoderLayer(2, 4, 2)
>>> encoder = nn.TransformerEncoder(layer, 2)
>>> pad_mask = torch.tensor([[1, 1, 0, 0]], dtype=torch.bool)
>>> inputs = torch.cat([torch.randn(1, 2, 2), torch.zeros(1, 2, 2)], dim=1)
>>> outputs = encoder(inputs, src_key_padding_mask=pad_mask)
```

### **Updated `torch.floor_divide` to perform floor division** **( [\#78411](https://github.com/pytorch/pytorch/pull/78411))**

Prior to 1.13, `torch.floor_divide` erroneously performed truncation division (i.e. truncated the quotients). In this release, it has been fixed to perform floor division. To replicate the old behavior, use `torch.div` with `rounding_mode='trunc'`.

1.12.1

```
>>> a = torch.tensor([4.0, -3.0])
>>> b = torch.tensor([2.0, 2.0])
>>> torch.floor_divide(a, b)
tensor([ 2., -1.])
```

1.13

```
>>> a = torch.tensor([4.0, -3.0])
>>> b = torch.tensor([2.0, 2.0])
>>> torch.floor_divide(a, b)
tensor([ 2., -2.])
# Old behavior can be replicated using torch.div with rounding_mode='trunc'
>>> torch.div(a, b, rounding_mode='trunc')
tensor([ 2., -1.])
```

### **Fixed `torch.index_select` on CPU to error that index is out of bounds when the `source` tensor is empty ( [\#77881](https://github.com/pytorch/pytorch/pull/77881))**

Prior to 1.13, `torch.index_select` would return an appropriately sized tensor filled with random values on CPU if the source tensor was empty. In this release, we have fixed this bug so that it errors out. A consequence of this is that `torch.nn.Embedding` which utilizes `index_select` will error out rather than returning an empty tensor when `embedding_dim=0` and `input` contains indices which are out of bounds. The old behavior cannot be reproduced with `torch.nn.Embedding`, however since an Embedding layer with `embedding_dim=0` is a corner case this behavior is unlikely to be relied upon.

1.12.1

```
>>> t = torch.tensor([4], dtype=torch.long)
>>> embedding = torch.nn.Embedding(3, 0)
>>> embedding(t)
tensor([], size=(1, 0), grad_fn=<EmbeddingBackward0>)
```

1.13

```
>>> t = torch.tensor([4], dtype=torch.long)
>>> embedding = torch.nn.Embedding(3, 0)
>>> embedding(t)
RuntimeError: INDICES element is out of DATA bounds, id=4 axis_dim=3
```

### Disallow overflows when tensors are constructed from scalars ( [\#82329](https://github.com/pytorch/pytorch/pull/82329))

Prior to this PR, overflows during tensor construction from scalars would not throw an error. In 1.13, such cases will error.

1.12.1

```
>>> torch.tensor(1000, dtype=torch.int8)
tensor(-24, dtype=torch.int8)
```

1.13

```
>>> torch.tensor(1000, dtype=torch.int8)
RuntimeError: value cannnot be converted to type int8 without overflow
```

### **Error on indexing a cpu tensor with non-cpu indices ( [\#69607](https://github.com/pytorch/pytorch/pull/69607))**

Prior to 1.13, `cpu_tensor[cuda_indices]` was a valid program that would return a cpu tensor. The original use case for mixed device indexing was for `non_cpu_tensor[cpu_indices]`, and allowing the opposite was unintentional ( `cpu_tensor[non_cpu_indices]`). This behavior appears to be rarely used, and a refactor of our indexing kernels made it difficult to represent an op that takes in (cpu\_tensor, non\_cpu\_tensor) and returns another cpu\_tensor, so it is now an error.

To replicate the old behavior for `base[indices]`, you can ensure that either `indices` lives on the CPU device, or `base` and `indices` both live on the same device.

1.12.1

```
>>> a = torch.tensor([1.0, 2.0, 3.0])
>>> b = torch.tensor([0, 2], device='cuda')
>>> a[b]
tensor([1., 3.])
```

1.13

```
>>> a = torch.tensor([1.0, 2.0, 3.0])
>>> b = torch.tensor([0, 2], device='cuda')
>>> a[b]
RuntimeError: indices should be either on cpu or on the same device as the indexed tensor (cpu)
# Old behavior can be replicated by moving b to CPU, or a to CUDA
>>> a[b.cpu()]
tensor([1., 3.])
>>> a.cuda()[b]
tensor([1., 3.], device='cuda:0')
```

### Remove deprecated `torch.eig`, ` torch.matrix_rank`, `torch.lstsq` ( [\#70982](https://github.com/pytorch/pytorch/pull/70982), [\#70981](https://github.com/pytorch/pytorch/pull/70981), [\#70980](https://github.com/pytorch/pytorch/pull/70980))

The deprecation cycle for the above functions has been completed and they have been removed in the 1.13 release.

## torch.nn

### Enforce that the `bias` has the same dtype as `input` and `weight` for convolutions on CPU ( [\#83686](https://github.com/pytorch/pytorch/pull/83686))

To align with the implementation on other devices, the CPU implementation for convolutions was updated to enforce that the `dtype` of the `bias` matches the `dtype` of the `input` and `weight`.

1.12.1

```
# input and weight are dtype torch.int64
# bias is torch.float32
>>> out = torch.nn.functional.conv2d(input, weight, bias, ...)
```

1.13

```
# input and weight are dtype torch.int64
# bias is torch.float32
>>> with assertRaisesError():
>>>    out = torch.nn.functional.conv2d(input, weight, bias, ...)

# Updated code to avoid the error
>>> out = torch.nn.functional.conv2d(input, weight, bias.to(input.dtype), ...)
```

## Autograd

### Disallow setting the `.data` of a tensor that `requires_grad=True` with an integer tensor ( [\#78436](https://github.com/pytorch/pytorch/pull/78436))

Setting the `.data` of a tensor that `requires_grad` with an integer tensor now raises an error.

1.12.1

```
>>> x = torch.randn(2, requires_grad=True)
>>> x.data = torch.randint(1, (2,))
>>> x
tensor([0, 0], requires_grad=True)
```

1.13

```
>>> x = torch.randn(2, requires_grad=True)
>>> x.data = torch.randint(1, (2,))
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
RuntimeError: data set to a tensor that requires gradients must be floating point or complex dtype
```

### Added variable\_list support to ExtractVariables struct ( [\#84583](https://github.com/pytorch/pytorch/pull/84583))

Prior to this change, C++ custom autograd Function considers tensors passed in TensorList to not be tensors for the purposes of recording the backward graph. After this change, custom Functions that receive TensorList must modify their backward functions to also compute gradients for these additional tensor inputs. Note that this behavior now differs from that of custom autograd Functions in Python.

1.12.1

```
struct MyFunction : public Function<MyFunction> {
    static Variable forward(AutogradContext* ctx, at::Tensor t, at::TensorList tensors) {
      return 2 * tensors[0] + 3 * t;
    }

    static variable_list backward(
        AutogradContext* ctx,
        variable_list grad_output) {
      return {3 * grad_output[0]};
    }
};
```

1.13

```
struct MyFunction : public Function<MyFunction> {
    static Variable forward(AutogradContext* ctx, at::Tensor t, at::TensorList tensors) {
      return 2 * tensors[0] + 3 * t;
    }

    static variable_list backward(
        AutogradContext* ctx,
        variable_list grad_output) {
      return {3 * grad_output[0], 2 * grad_output[0]};
    }
};
```

### Don't detach when making views; force kernel to detach ( [\#84893](https://github.com/pytorch/pytorch/pull/84893))

View operations registered as CompositeExplicitAutograd kernels are no longer allowed to return input tensors as-is. You must explic...

[Read more](https://github.com/pytorch/pytorch/releases/tag/v1.13.0)

### Contributors

- [![@hfwen0502](https://avatars.githubusercontent.com/u/14792895?s=64&v=4)](https://github.com/hfwen0502)
- [![@lchu6](https://avatars.githubusercontent.com/u/20955448?s=64&v=4)](https://github.com/lchu6)
- [![@beartype](https://avatars.githubusercontent.com/u/63089855?s=64&v=4)](https://github.com/beartype)

hfwen0502, lchu6, and beartype


Assets3

Loading

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).

yzhangcs, AH-dark, akihironitta, thanhpcc96, aymenkhs, khushi-411, lehoangHUST, samwaterbury, MengShen0709, Cardroid, and 25 more reacted with thumbs up emojiyzhangcs, akihironitta, and TheFanatr reacted with laugh emojiyzhangcs, akihironitta, khushi-411, JohT, zachcoleman, ericspod, sunway513, TheFanatr, Icy-Thought, innocentmunai, and 6 more reacted with hooray emojiyzhangcs, akihironitta, aymenkhs, khushi-411, zachcoleman, TheFanatr, dannis999, albanD, erickTornero, LaRiffle, and 2 more reacted with heart emojiyzhangcs, akihironitta, ilya16, rohitgr7, aymenkhs, samwaterbury, zachcoleman, ke1337, bencevans, antoinebrl, and 8 more reacted with rocket emojiyzhangcs, akihironitta, and tolgacangoz reacted with eyes emoji

All reactions

- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)35 reactions
- ![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)3 reactions
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)16 reactions
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)12 reactions
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)18 reactions
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)3 reactions

58 people reacted

## PyTorch 1.12.1 Release, small bug fix release

Aug 5, 2022
05 Aug 19:35


![@atalman](https://avatars.githubusercontent.com/u/7563158?s=40&v=4)[atalman](https://github.com/atalman)

[v1.12.1](https://github.com/pytorch/pytorch/tree/v1.12.1)

[`664058f`](https://github.com/pytorch/pytorch/commit/664058fa83f1d8eede5d66418abff6e20bd76ca8)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.
The key has expired.


GPG key ID: 4AEE18F83AFDEB23

Expired

Verified
on Jan 16, 2024, 02:59 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

## Sorry, something went wrong.

Filter

Loading

## Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).

## No results found

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 1.12.1 Release, small bug fix release](https://github.com/pytorch/pytorch/releases/tag/v1.12.1)

This release is meant to fix the following issues (regressions / silent correctness):

## Optim

- Remove overly restrictive assert in adam [#80222](https://github.com/pytorch/pytorch/pull/80222)

## Autograd

- Convolution forward over reverse internal asserts in specific case [#81111](https://github.com/pytorch/pytorch/issues/81111)
- 25% Performance regression from v0.1.1 to 0.2.0 when calculating hessian [#82504](https://github.com/pytorch/pytorch/pull/82504)

## Distributed

- Fix distributed store to use add for the counter of DL shared seed [#80348](https://github.com/pytorch/pytorch/pull/80348)
- Raise proper timeout when sharing the distributed shared seed [#81666](https://github.com/pytorch/pytorch/pull/81666)

## NN

- Allow register float16 weight\_norm on cpu and speed up test [#80600](https://github.com/pytorch/pytorch/pull/80600)
- Fix weight norm backward bug on CPU when OMP\_NUM\_THREADS <= 2 [#80930](https://github.com/pytorch/pytorch/pull/80930)
- Weight\_norm is not working with float16 [#80599](https://github.com/pytorch/pytorch/issues/80599)
- New release breaks torch.nn.weight\_norm backwards pass and breaks all Wav2Vec2 implementations [#80569](https://github.com/pytorch/pytorch/issues/80569)
- Disable src mask for transformer and multiheadattention fastpath [#81277](https://github.com/pytorch/pytorch/pull/81277)
- Make nn.stateless correctly reset parameters if the forward pass fails [#81262](https://github.com/pytorch/pytorch/pull/81262)
- torchvision.transforms.functional.rgb\_to\_grayscale() + torch.nn.Conv2d() don\`t work on 1080 GPU [#81106](https://github.com/pytorch/pytorch/issues/81106)
- Transformer and CPU path with src\_mask raises error with torch 1.12 [#81129](https://github.com/pytorch/pytorch/issues/81129)

## Data Loader

- \[Locking lower ranks seed recepients https://github.com/ [/pull/81071](https://github.com/pytorch/pytorch/pull/81071)\
\
## CUDA\
\
- os.environ\["CUDA\_VISIBLE\_DEVICES"\] has no effect [#80876](https://github.com/pytorch/pytorch/issues/80876)\
- share\_memory() on CUDA tensors no longer no-ops and instead crashes [#80733](https://github.com/pytorch/pytorch/issues/80733)\
- \[Prims\] Unbreak CUDA lazy init [#80899](https://github.com/pytorch/pytorch/pull/80899)\
- PyTorch 1.12 cu113 wheels cudnn discoverability issue [#80637](https://github.com/pytorch/pytorch/issues/80637)\
- Remove overly restrictive checks for cudagraph [#80881](https://github.com/pytorch/pytorch/pull/80881)\
\
## ONNX\
\
- ONNX cherry picks [#82435](https://github.com/pytorch/pytorch/pull/82435)\
\
## MPS\
\
- MPS cherry picks [#80898](https://github.com/pytorch/pytorch/issues/80898)\
\
## Other\
\
- Don't error if \_warned\_capturable\_if\_run\_uncaptured not set [#80345](https://github.com/pytorch/pytorch/pull/80345)\
- Initializing libiomp5.dylib, but found libomp.dylib already initialized. [#78490](https://github.com/pytorch/pytorch/issues/78490)\
- Assertion error - \_dl\_shared\_seed\_recv\_cnt - pt 1.12 - multi node [#80845](https://github.com/pytorch/pytorch/issues/80845)\
- Add 3.10 stdlib to torch.package [#81261](https://github.com/pytorch/pytorch/pull/81261)\
- CPU-only c++ extension libraries (functorch, torchtext) built against PyTorch wheels are not fully compatible with PyTorch wheels [#80489](https://github.com/pytorch/pytorch/issues/80489)\
\
Assets3\
\
Loading\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
robertocarlosmedina, gallegogt, AhmedAliStats, ecstayalive, TheFanatr, hoangtnm, mbilalai, Rishit-dagli, junjihashimoto, Red-Eyed, and 18 more reacted with thumbs up emojiRed-Eyed, AYUSHMIT, edwardnguyen1705, VladPetruMarius, lucadiliello, leecs0503, and tolgacangoz reacted with hooray emojiRed-Eyed, atalman, VladPetruMarius, pi-null-mezon, aymenkhs, raghukiran1224, nickjeliopoulos, leecs0503, and tolgacangoz reacted with heart emojiRed-Eyed, jsz4n, VladPetruMarius, nickjeliopoulos, and tolgacangoz reacted with eyes emoji\
\
All reactions\
\
- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)28 reactions\
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)7 reactions\
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)9 reactions\
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)5 reactions\
\
36 people reacted\
\
## PyTorch 1.12: TorchArrow, Functional API for Modules and nvFuser, are now available\
\
Jun 28, 2022\
28 Jun 16:48\
\
\
![@soulitzer](https://avatars.githubusercontent.com/u/13428986?s=40&v=4)[soulitzer](https://github.com/soulitzer)\
\
[v1.12.0](https://github.com/pytorch/pytorch/tree/v1.12.0)\
\
[`67ece03`](https://github.com/pytorch/pytorch/commit/67ece03c8cd632cce9523cd96efde6f2d1cc8121)\
\
This commit was created on GitHub.com and signed with GitHub’s **verified signature**.\
The key has expired.\
\
\
GPG key ID: 4AEE18F83AFDEB23\
\
Expired\
\
Verified\
on Jan 16, 2024, 02:59 PM\
\
[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).\
\
\
Compare\
\
# Choose a tag to compare\
\
## Sorry, something went wrong.\
\
Filter\
\
Loading\
\
## Sorry, something went wrong.\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
## No results found\
\
[View all tags](https://github.com/pytorch/pytorch/tags)\
\
[PyTorch 1.12: TorchArrow, Functional API for Modules and nvFuser, are now available](https://github.com/pytorch/pytorch/releases/tag/v1.12.0)\
\
# PyTorch 1.12 Release Notes\
\
- Highlights\
- Backwards Incompatible Change\
- New Features\
- Improvements\
- Performance\
- Documentation\
\
# Highlights\
\
We are excited to announce the release of PyTorch 1.12! This release is composed of over 3124 commits, 433 contributors. Along with 1.12, we are releasing beta versions of AWS S3 Integration, PyTorch Vision Models on Channels Last on CPU, Empowering PyTorch on Intel® Xeon® Scalable processors with Bfloat16 and FSDP API. We want to sincerely thank our dedicated community for your contributions.\
\
Summary:\
\
- Functional Module API to functionally apply module computation with a given set of parameters\
- Complex32 and Complex Convolutions in PyTorch\
- DataPipes from TorchData fully backward compatible with DataLoader\
- Functorch with improved coverage for APIs\
- nvFuser a deep learning compiler for PyTorch\
- Changes to float32 matrix multiplication precision on Ampere and later CUDA hardware\
- TorchArrow, a new beta library for machine learning preprocessing over batch data\
\
# Backwards Incompatible changes\
\
## Python API\
\
**Updated type promotion for `torch.clamp`** ( [#77035](https://github.com/pytorch/pytorch/pull/77035))\
\
In 1.11, the ‘min’ and ‘max’ arguments in `torch.clamp` did not participate in type promotion, which made it inconsistent with `minimum` and `maximum` operations. In 1.12, the ‘min’ and ‘max’ arguments participate in type promotion.\
\
1.11\
\
```\
>>> import torch\
>>> a = torch.tensor([1., 2., 3., 4.], dtype=torch.float32)\
>>> b = torch.tensor([2., 2., 2., 2.], dtype=torch.float64)\
>>> c = torch.tensor([3., 3., 3., 3.], dtype=torch.float64)\
>>> torch.clamp(a, b, c).dtype\
torch.float32\
```\
\
1.12\
\
```\
>>> import torch\
>>> a = torch.tensor([1., 2., 3., 4.], dtype=torch.float32)\
>>> b = torch.tensor([2., 2., 2., 2.], dtype=torch.float64)\
>>> c = torch.tensor([3., 3., 3., 3.], dtype=torch.float64)\
>>> torch.clamp(a, b, c).dtype\
torch.float64\
```\
\
## Complex Numbers\
\
### Fix complex type promotion ( [\#77524](https://github.com/pytorch/pytorch/pull/77524))\
\
Updates the type promotion rule such that given a complex scalar and real tensor, the value type of real tensor is preserved\
\
1.11\
\
```\
>>> a = torch.randn((2, 2), dtype=torch.float)\
>>> b = torch.tensor(1, dtype=torch.cdouble)\
>>> (a + b).dtype\
torch.complex128\
```\
\
1.12\
\
```\
>>> a = torch.randn((2, 2), dtype=torch.float)\
>>> b = torch.tensor(1, dtype=torch.cdouble)\
>>> (a + b).dtype\
torch.complex64\
```\
\
## LinAlg\
\
### Disable TF32 for matmul by default and add high-level control of fp32 matmul precision ( [\#76509](https://github.com/pytorch/pytorch/pull/76509))\
\
PyTorch 1.12 makes the default math mode for fp32 matrix multiplications more precise and consistent across hardware. This may affect users on Ampere or later CUDA devices and TPUs. See the PyTorch [blog](https://dev-discuss.pytorch.org/t/pytorch-and-tensorfloat32/504) for more details.\
\
## Sparse\
\
### Use ScatterGatherKernel for scatter\_reduce (CPU-only) ( [\#74226](https://github.com/pytorch/pytorch/pull/74226), [\#74608](https://github.com/pytorch/pytorch/pull/74608))\
\
In 1.11.0, unlike `scatter` which takes a `reduce` kwarg or `scatter_add`, `scatter_reduce` was not an in-place function. That is, it did not allow the user to pass an output tensor which contains data that is reduced together with the scattered data. Instead, the scatter reduction took place on an output tensor initialized under the hood. Indices of the output that were not scattered to were filled with reduction inits (or 0 for options ‘amin’ and ‘amax’).\
\
In 1.12.0, `scatter_reduce` (which is in beta) is in-place to align with the API of the related existing functions `scatter`/ `scatter_add`. For this reason, the argument `input` in 1.11.0 has been renamed `src` in 1.12.0 and the new `self` argument now takes a destination tensor to be scattered onto. Since the destination tensor is no longer initialized under the hood, the `output_size` kwarg in 1.11.0 that allowed users to specify the size of the output at dimension `dim` has been removed. Further, in 1.12.0 we introduce an `include_self` kwarg which determines whether values in the `self` (destination) tensor are included in the reduction. Setting `include_self=True` could, for example, allow users to provide special reduction inits for the scatter\_reduction operation. Otherwise, if `include_self=False,` indices scattered to are treated as if they were filled with reduction inits.\
\
In the snippet below, we illustrate how the behavior of `scatter_reduce` in 1.11.0 can be achieved with the function released in 1.12.0.\
\
Example:\
\
```\
>>> src = torch.arange(6, dtype=torch.float).reshape(3, 2)\
>>> index = torch.tensor([[0, 2], [1, 1], [0, 0]])\
>>> dim = 1\
>>> output_size = 4\
>>> reduce = "prod"\
```\
\
1.11\
\
```\
>>> torch.scatter_reduce(src, dim, index, reduce, output_size=output_size)\
`tensor([[ 0., 1., 1., 1.],\
        [ 1., 6., 1., 1.],\
        [20., 1., 1., 1.]])`\
```\
\
1.12\
\
```\
>>> output_shape = list(src.shape)\
>>> output_shape[dim] = output_size\
# reduction init for prod is 1\
# filling the output with 1 is only necessary if the user wants to preserve the behavior in 1.11\
# where indices not scattered to are filled with reduction inits\
>>> output = src.new_empty(output_shape).fill_(1)\
>>> output.scatter_reduce_(dim, index, src, reduce)\
`tensor([[ 0., 1., 1., 1.],\
        [ 1., 6., 1., 1.],\
        [20., 1., 1., 1.]])`\
```\
\
## torch.nn\
\
### `nn.GroupNorm`: Report an error if `num_channels` is not divisible by `num_groups` ( [\#74293](https://github.com/pytorch/pytorch/pull/74293))\
\
Previously, `nn.GroupNorm` would error out during the forward pass if `num_channels` is not divisible by `num_groups`. Now, the error is thrown for this case during module construction instead.\
\
1.11\
\
```\
m = torch.nn.GroupNorm(3, 7)\
m(...)  # errors during forward pass\
```\
\
1.12\
\
```\
m = torch.nn.GroupNorm(3, 7)  # errors during construction\
```\
\
### `nn.Dropout2d`: Return to 1.10 behavior: perform 1D channel-wise dropout for 3D inputs\
\
In PyTorch 1.10 and older, passing a 3D input to `nn.Dropout2D` resulted in 1D channel-wise dropout behavior; i.e. such inputs were interpreted as having shape `(N, C, L)` with N = batch size and C = # channels and channel-wise dropout was performed along the second dimension.\
\
1.10\
\
```\
x = torch.randn(2, 3, 4)\
m = nn.Dropout2d(p=0.5)\
out = m(x)  # input is assumed to be shape (N, C, L); dropout along the second dim.\
```\
\
With the introduction of no-batch-dim input support in 1.11, 3D inputs were reinterpreted as having shape `(C, H, W)`; i.e. an input without a batch dimension, and dropout behavior was changed to drop along the first dimension. This was a silent breaking change.\
\
1.11\
\
```\
x = torch.randn(2, 3, 4)\
m = nn.Dropout2d(p=0.5)\
out = m(x)  # input is assumed to be shape (C, H, W); dropout along the first dim.\
```\
\
The breaking change in 1.11 resulted in a lack of support for 1D channel-wise dropout behavior, so `Dropout2d` in PyTorch 1.12 returns to 1.10 behavior with a warning to give some time to adapt before the no-batch-dim interpretation goes back into effect.\
\
1.12\
\
```\
x = torch.randn(2, 3, 4)\
m = nn.Dropout2d(p=0.5)\
out = m(x)  # input is assumed to be shape (N, C, L); dropout along the second dim.\
            # throws a warning suggesting nn.Dropout1d for 1D channel-wise dropout.\
```\
\
If you want 1D channel-wise dropout behavior, please switch to use of the newly-added `nn.Dropout1d` module instead of `nn.Dropout2d`. If you want no-batch-dim input behavior, please note that while this is not supported in 1.12, a future release will reinstate the interpretation of 3D inputs to `nn.Dropout2d` as those without a batch dimension.\
\
### **`F.cosine_similarity`: Improve numerical stability ( [\#31378](https://github.com/pytorch/pytorch/pull/31378))**\
\
Previously, we first compute the inner product, then normalize. After this change, we first normalize, then compute inner product. This should be more numerically stable because it avoids losing precision in inner product for inputs with large norms. Because of this change, outputs may be different in some cases.\
\
## Composability\
\
**Functions in torch.ops.aten.{foo} no longer accept `self` as a kwarg**\
\
`torch.ops.aten.{foo}` objects are now instances of `OpOverloadPacket` (instead of a function) that have their `__call__` method in Python, which means that you cannot pass `self` as a kwarg. You can pass it normally as a positional argument instead.\
\
1.11\
\
```\
>>> torch.ops.aten.sin(self=torch.ones(2))\
    tensor([0.8415, 0.8415])\
```\
\
1.12\
\
```\
# this now fails\
>>> torch.ops.aten.sin(self=torch.ones(2))\
Traceback (most recent call last):\
  File "<stdin>", line 1, in <module>\
TypeError: __call__() got multiple values for argument 'self'\
# this works\
>>> torch.ops.aten.sin(torch.ones(2))\
tensor([0.8415, 0.8415])\
```\
\
**torch\_dispatch now traces individual op overloads instead of op overload packets (** [**#72673**](https://github.com/pytorch/pytorch/pull/72673) **)**\
\
`torch.ops.aten.add` actually corresponds to a bundle of functions from C++, corresponding to all over the overloads of add operator (specifically, `add.Tensor`, `add.Scalar` and `add.out`). Now, `__torch_dispatch__` will directly take in an overload corresponding to a single aten function.\
\
1.11\
\
```\
class MyTensor(torch.Tensor):\
    ....\
    def __torch_dispatch__(cls, func, types, args=(), kwargs=None):\
        # Before, func refers to a "packet" of all overloads\
        # for a given operator, e.g. "add"\
        assert func == torch.ops.aten.add\
```\
\
1.12\
\
```\
class MyTensor(torch.Tensor):\
    ....\
    def __torch_dispatch__(cls, func, types, args=(), kwargs=No...\
```\
\
[Read more](https://github.com/pytorch/pytorch/releases/tag/v1.12.0)\
\
Assets3\
\
Loading\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
frgfm, oke-aditya, iceychris, akihironitta, tchaton, forgi86, sanchitintel, jameswong3388, JackCaoG, Yura52, and 45 more reacted with thumbs up emojiWYGNG, ekolodin, J3698, zhiqwang, zhuyyx, and gmendozah reacted with laugh emojikhushi-411, Miezhiko, oke-aditya, iceychris, akihironitta, tchaton, samuelrince, sanchitintel, aidyai, jaggbow, and 20 more reacted with hooray emojikhushi-411, oke-aditya, iceychris, akihironitta, tchaton, sanchitintel, SigureMo, zhang0557kui, neonsecret, Guillem96, and 13 more reacted with heart emojikhushi-411, oke-aditya, iceychris, akihironitta, tchaton, ellisbrown, sanchitintel, lirundong, SigureMo, zhang0557kui, and 13 more reacted with rocket emojibjmeo8, WYGNG, zhiqwang, LiweiPeng, and tolgacangoz reacted with eyes emoji\
\
All reactions\
\
- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)55 reactions\
- ![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)6 reactions\
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)30 reactions\
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)23 reactions\
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)23 reactions\
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)5 reactions\
\
85 people reacted\
\
## PyTorch 1.11, TorchData, and functorch are now available\
\
Mar 10, 2022\
10 Mar 16:59\
\
\
![@bdhirsh](https://avatars.githubusercontent.com/u/16311747?s=40&v=4)[bdhirsh](https://github.com/bdhirsh)\
\
[v1.11.0](https://github.com/pytorch/pytorch/tree/v1.11.0)\
\
[`bc2c6ed`](https://github.com/pytorch/pytorch/commit/bc2c6edaf163b1a1330e37a6e34caf8c553e4755)\
\
This commit was created on GitHub.com and signed with GitHub’s **verified signature**.\
The key has expired.\
\
\
GPG key ID: 4AEE18F83AFDEB23\
\
Expired\
\
Verified\
on Nov 7, 2024, 10:56 AM\
\
[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).\
\
\
Compare\
\
# Choose a tag to compare\
\
## Sorry, something went wrong.\
\
Filter\
\
Loading\
\
## Sorry, something went wrong.\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
## No results found\
\
[View all tags](https://github.com/pytorch/pytorch/tags)\
\
[PyTorch 1.11, TorchData, and functorch are now available](https://github.com/pytorch/pytorch/releases/tag/v1.11.0)\
\
# PyTorch 1.11 Release Notes\
\
- Highlights\
- Backwards Incompatible Change\
- New Features\
- Improvements\
- Performance\
- Documentation\
\
# Highlights\
\
We are excited to announce the release of PyTorch 1.11. This release is composed of over 3,300 commits since 1.10, made by 434 contributors. Along with 1.11, we are releasing beta versions of TorchData and functorch. We want to sincerely thank our community for continuously improving PyTorch.\
\
- TorchData is a new library for common modular data loading primitives for easily constructing flexible and performant data pipelines. [_View it on GitHub_](https://github.com/pytorch/data).\
- functorch, a library that adds composable function transforms to PyTorch, is now available in beta. [_View it on GitHub_](https://github.com/pytorch/functorch).\
- Distributed Data Parallel (DDP) static graph optimizations available in stable.\
\
You can check the blogpost that shows the new features [here](https://pytorch.org/blog/pytorch-1.11-released/).\
\
# Backwards Incompatible changes\
\
## Python API\
\
### Fixed python `deepcopy` to correctly copy all attributes on `Tensor` objects ( [\#65584](https://github.com/pytorch/pytorch/pull/65584))\
\
This change ensures that the `deepcopy` operation on Tensor properly copies all the attributes (and not just the plain Tensor properties).\
\
| 1.10.2 | 1.11.0 |\
| --- | --- |\
| ```<br>a = torch.rand(2)<br>a.foo = 3<br>torch.save(a, "bar")<br>b = torch.load("bar")<br>print(b.foo)<br># Raise AttributeError: "Tensor" object has no attribute "foo"<br>      <br>``` | ```<br>a = torch.rand(2)<br>a.foo = 3<br>torch.save(a, "bar")<br>b = torch.load("bar")<br>print(b.foo)<br># 3<br>      <br>``` |\
\
### **`steps` argument is no longer optional in `torch.linspace` and `torch.logspace`**\
\
This argument used to default to 100 in PyTorch 1.10.2, but was deprecated (previously you would see a deprecation warning if you didn’t explicitly pass in `steps`). In PyTorch 1.11, it is not longer optional.\
\
| 1.10.2 | 1.11.0 |\
| --- | --- |\
| ```<br># Works, but raises a deprecation warning<br># Steps defaults to 100<br>a = torch.linspace(1, 10)<br># UserWarning: Not providing a value for linspace's steps is deprecated<br># and will throw a runtime error in a future release.<br># This warning will appear only once per process.<br># (Triggered internally at  ../aten/src/ATen/native/RangeFactories.cpp:19<br>      <br>``` | ```<br># In 1.11, you must specify steps<br>a = torch.linspace(1, 10, steps=100)<br>      <br>``` |\
\
### Remove `torch.hub.import_module` function that was mistakenly public ( [\#67990](https://github.com/pytorch/pytorch/pull/67990))\
\
This function is not intended for public use.\
\
If you have existing code that relies on it, you can find an equivalent function at `torch.hub._import_module`.\
\
## C++ API\
\
### **We’ve cleaned up many of the headers in the C++ frontend to only include the subset of `aten` operators that they actually used ( [\#68247](https://github.com/pytorch/pytorch/pull/68247), [\#68687](https://github.com/pytorch/pytorch/pull/68687), [\#68688](https://github.com/pytorch/pytorch/pull/68688), [\#68714](https://github.com/pytorch/pytorch/pull/68714), [\#68689](https://github.com/pytorch/pytorch/pull/68689), [\#68690](https://github.com/pytorch/pytorch/pull/68690), [\#68697](https://github.com/pytorch/pytorch/pull/68697), [\#68691](https://github.com/pytorch/pytorch/pull/68691), [\#68692](https://github.com/pytorch/pytorch/pull/68692), [\#68693](https://github.com/pytorch/pytorch/pull/68693), [\#69840](https://github.com/pytorch/pytorch/pull/69840))**\
\
When you `#include` a header from the C++ frontend, you can no longer assume that every `aten` operators are transitively included. You can work around this by directly adding `#include <ATen/ATen.h>` in your file, which will maintain the old behavior of including every `aten` operators.\
\
### **Custom implementation for `c10::List` and `c10::Dict` move constructors have been removed (** [**\#69370**](https://github.com/pytorch/pytorch/pull/69370) **)**\
\
The semantics have changed from "make the moved-from List/Dict empty" to "keep the moved-from List/Dict unchanged"\
\
| 1.10.2 | 1.11.0 |\
| --- | --- |\
| ```<br>c10::List list1({"3", "4"});<br>c10::List list2(std::move(list1));<br>std::cout << list1.size() // 0<br>      <br>``` | ```<br>c10::List list1({"3", "4"});<br>c10::List list2(std::move(list1)); // calls copy ctr<br>std::cout << list1.size() // 2<br>      <br>``` |\
\
## CUDA\
\
### **Removed `THCeilDiv` function and corresponding `THC/THCDeviceUtils.cuh` header ( [\#65472](https://github.com/pytorch/pytorch/pull/65472))**\
\
As part of cleaning up `TH` from the codebase, the `THCeilDiv` function has been removed. Instead, please use `at::ceil_div`, and include the corresponding `ATen/ceil_div.h` header\
\
### **Removed `THCudaCheck` (** [**\#66391**](https://github.com/pytorch/pytorch/pull/66391) **)**\
\
You can replace it with `C10_CUDA_CHECK`, which has been available since at least PyTorch 1.4, so just replacing is enough even if you support older versions\
\
### **Removed `THCudaMalloc()`, `THCudaFree()`, `THCThrustAllocator.cuh` (** [**\#65492**](https://github.com/pytorch/pytorch/pull/65492) **)**\
\
If your extension is using `THCThrustAllocator.cuh`, please replace it with `ATen/cuda/ThrustAllocator.h` and corresponding APIs (see examples in this PR).\
\
This PR also removes `THCudaMalloc/THCudaFree` calls. Please use `c10::cuda::CUDACachingAllocator::raw_alloc(size)/raw_delete(ptr)`, or, preferably, switch to `c10:cuda::CUDaCachingAllocator::allocate` which manages deallocation. Caching allocator APIs are available since PyTorch 1.2, so just replacing it is enough even if you support older versions of PyTorch.\
\
## Build\
\
### Stopped building shared library for AOT Compiler, `libaot_compiler.so` ( [\#66227](https://github.com/pytorch/pytorch/pull/66227))\
\
Building `aot_compiler.cpp` as a separate library is not necessary, as it’s already included in `libtorch.so`.\
\
You can update your build system to only dynamically link `libtorch.so`.\
\
## Mobile\
\
### Make `typing.Union` type unsupported for mobile builds ( [\#65556](https://github.com/pytorch/pytorch/pull/65556))\
\
`typing.Union` support was added for TorchScript in 1.10. It was removed specifically for mobile due to its lack of use and increase in binary size of PyTorch for Mobile builds.\
\
## Distributed\
\
### `torch.distributed.rpc`: Final Removal of ProcessGroup RPC backend ( [\#67363](https://github.com/pytorch/pytorch/pull/67363))\
\
ProcessGroup RPC backend is deprecated. In 1.10, it threw an error to help users update their code, and, in 1.11, it is removed completely.\
\
The backend type “PROCESS\_GROUP” is now deprecated, e.g.\
\
`torch.distributed.rpc.init_rpc("worker0", backend="PROCESS_GROUP", rank=0, world_size=1)`\
\
and should be replaced with:\
\
`torch.distributed.rpc.init_rpc("worker0", backend="TENSORPIPE", rank=0, world_size=1)`\
\
## Quantization\
\
### Disabled the support for `getitem` in FX Graph Mode Quantization ( [\#66647](https://github.com/pytorch/pytorch/pull/66647))\
\
`getitem` used to be quantized in `FX Graph Mode Quantization`, and it is no longer quantized. This won’t break any models but could result in a slight difference in numerics.\
\
| 1.10.2 | 1.11.0 |\
| --- | --- |\
| ```<br>from torch.ao.quantization.quantize_fx import convert_fx, prepare_fx<br>class M(torch.nn.Module):<br>    def __init__(self):<br>        super().__init__()<br>        self.linear = torch.nn.Linear(5, 5)<br>    def forward(self, x):<br>        x = self.linear(x)<br>        y = torch.stack([x], 0)<br>        return y[0]<br>m = M().eval()<br>m = prepare_fx(m, {"": torch.ao.quantization.default_qconfig})<br>m = convert_fx(m)<br>print(m)<br># prints<br># GraphModule(<br>#   (linear): QuantizedLinear(in_features=5, out_features=5,<br>#      scale=1.0, zero_point=0, qscheme=torch.per_tensor_affine)<br># )<br># def forward(self, x):<br>#     linear_input_scale_0 = self.linear_input_scale_0<br>#     linear_input_zero_point_0 = self.linear_input_zero_point_0<br>#     quantize_per_tensor = torch.quantize_per_tensor(x,<br>#         linear_input_scale_0, linear_input_zero_point_0, torch.quint8)<br>#     x = linear_input_scale_0 = linear_input_zero_point_0 = None<br>#     linear = self.linear(quantize_per_tensor)<br>#     quantize_per_tensor = None<br>#     stack = torch.stack([linear], 0);  linear = None<br>#     getitem = stack[0]; stack = None<br>#     dequantize_2 = getitem.dequantize();  getitem = None<br>#     return getitem<br>      <br>``` | ```<br>from torch.ao.quantization.quantize_fx import convert_fx, prepare_fx<br>class M(torch.nn.Module):<br>    def __init__(self):<br>        super().__init__()<br>        self.linear = torch.nn.Linear(5, 5)<br>    def forward(self, x):<br>        x = self.linear(x)<br>        y = torch.stack([x], 0)<br>        return y[0]<br>m = M().eval()<br>m = prepare_fx(m, {"": torch.ao.quantization.default_qconfig})<br>m = convert_fx(m)<br>print(m)<br># prints<br># GraphModule(<br>#   (linear): QuantizedLinear(in_features=5, out_features=5, scale=1.0,<br>                    zero_point=0, qscheme=torch.per_tensor_affine)<br># )<br># def forward(self, x):<br>#     linear_input_scale_0 = self.linear_input_scale_0<br>#     linear_input_zero_point_0 = self.linear_input_zero_point_0<br>#     quantize_per_tensor = tor...<br>``` |\
\
[Read more](https://github.com/pytorch/pytorch/releases/tag/v1.11.0)\
\
Assets3\
\
Loading\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
dhruvbird, Dengda98, zhiqwang, voldemortX, strint, pzelasko, steib, ashim-mahara, wuwenjie1992, sadra-barikbin, and 22 more reacted with thumbs up emojizhiqwang reacted with laugh emojivfdev-5, akihironitta, semaphore-egg, mberr, zhiqwang, amorehead, ronghanghu, toshiks, cchadj, xin-hao-2025, and tolgacangoz reacted with hooray emojizhiqwang and tolgacangoz reacted with heart emojikrshrimali, akihironitta, cthoyt, sanchitintel, zhiqwang, m3at, Mathux, willsq, aheuillet, cchadj, and 3 more reacted with rocket emojigugarosa, odellus, cchadj, xin-hao-2025, zhiqwang, and tolgacangoz reacted with eyes emoji\
\
All reactions\
\
- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)32 reactions\
- ![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)1 reaction\
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)11 reactions\
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)2 reactions\
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)13 reactions\
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)6 reactions\
\
48 people reacted\
\
## PyTorch 1.10.2 Release, small bug fix release\
\
Jan 27, 2022\
27 Jan 21:51\
\
\
![@atalman](https://avatars.githubusercontent.com/u/7563158?s=40&v=4)[atalman](https://github.com/atalman)\
\
[v1.10.2](https://github.com/pytorch/pytorch/tree/v1.10.2)\
\
[`71f889c`](https://github.com/pytorch/pytorch/commit/71f889c7d265b9636b93ede9d651c0a9c4bee191)\
\
This commit was created on GitHub.com and signed with GitHub’s **verified signature**.\
The key has expired.\
\
\
GPG key ID: 4AEE18F83AFDEB23\
\
Expired\
\
Verified\
on Jan 16, 2024, 02:59 PM\
\
[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).\
\
\
Compare\
\
# Choose a tag to compare\
\
## Sorry, something went wrong.\
\
Filter\
\
Loading\
\
## Sorry, something went wrong.\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
## No results found\
\
[View all tags](https://github.com/pytorch/pytorch/tags)\
\
[PyTorch 1.10.2 Release, small bug fix release](https://github.com/pytorch/pytorch/releases/tag/v1.10.2)\
\
This release is meant to deploy additional fixes not included in 1.10.1 release:\
\
- fix pybind issue for get\_autocast\_cpu\_dtype and get\_autocast\_gpu\_dtype [#66396](https://github.com/pytorch/pytorch/pull/66396)\
- Remove fgrad\_input from slow\_conv2d [#64280](https://github.com/pytorch/pytorch/pull/64280)\
- fix formatting CIRCLE\_TAG when building docs [#67026](https://github.com/pytorch/pytorch/pull/67026)\
\
Assets3\
\
Loading\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
seemethere, atalman, mzr1996, Chachay, Miezhiko, shagunsodhani, lucadiliello, durandtibo, eeezio, 0T34, and 6 more reacted with thumbs up emojiseemethere, atalman, shagunsodhani, durandtibo, 0T34, AB-MT, GuoZhiBin2014, edrozenberg, and tolgacangoz reacted with rocket emoji\
\
All reactions\
\
- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)16 reactions\
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)9 reactions\
\
16 people reacted\
\
## PyTorch 1.10.1 Release, small bug fix release\
\
Dec 15, 2021\
15 Dec 22:27\
\
\
![@seemethere](https://avatars.githubusercontent.com/u/1700823?s=40&v=4)[seemethere](https://github.com/seemethere)\
\
[v1.10.1](https://github.com/pytorch/pytorch/tree/v1.10.1)\
\
[`302ee7b`](https://github.com/pytorch/pytorch/commit/302ee7bfb604ebef384602c56e3853efed262030)\
\
This commit was created on GitHub.com and signed with GitHub’s **verified signature**.\
The key has expired.\
\
\
GPG key ID: 4AEE18F83AFDEB23\
\
Expired\
\
Verified\
on Jan 16, 2024, 02:59 PM\
\
[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).\
\
\
Compare\
\
# Choose a tag to compare\
\
## Sorry, something went wrong.\
\
Filter\
\
Loading\
\
## Sorry, something went wrong.\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
## No results found\
\
[View all tags](https://github.com/pytorch/pytorch/tags)\
\
[PyTorch 1.10.1 Release, small bug fix release](https://github.com/pytorch/pytorch/releases/tag/v1.10.1)\
\
This release is meant to fix the following issues (regressions / silent correctness):\
\
- torch.nn.cross\_entropy silently incorrect in PyTorch 1.10 on CUDA on non-contiguous inputs [#67167](https://github.com/pytorch/pytorch/issues/67167)\
- channels\_last significantly degrades accuracy [#67239](https://github.com/pytorch/pytorch/issues/67239)\
- Potential strict aliasing rule violation in bitwise\_binary\_op (on ARM/NEON) [#66119](https://github.com/pytorch/pytorch/issues/66119)\
- torch.get\_autocast\_cpu\_dtype() returns a new dtype [#65786](https://github.com/pytorch/pytorch/issues/65786)\
- Conv2d grad bias gets wrong value for bfloat16 case [#68048](https://github.com/pytorch/pytorch/issues/68048)\
\
The [release tracker](https://github.com/pytorch/pytorch/issues/69100) should contain all relevant pull requests related to this release as well as links to related issues\
\
Assets3\
\
Loading\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
rishikksh20, kikirizki, hoangtnm, weiweiWYW, enverfakhan, tolgacangoz, jxaflxb, and trip036 reacted with thumbs up emoji\
\
All reactions\
\
- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)8 reactions\
\
8 people reacted\
\
## PyTorch 1.10 Release, including CUDA Graphs APIs, Frontend and compiler improvements\
\
Oct 21, 2021\
21 Oct 15:49\
\
\
![@albanD](https://avatars.githubusercontent.com/u/6359743?s=40&v=4)[albanD](https://github.com/albanD)\
\
[v1.10.0](https://github.com/pytorch/pytorch/tree/v1.10.0)\
\
[`36449ea`](https://github.com/pytorch/pytorch/commit/36449ea93134574c2a22b87baad3de0bf8d64d42)\
\
This commit was created on GitHub.com and signed with GitHub’s **verified signature**.\
The key has expired.\
\
\
GPG key ID: 4AEE18F83AFDEB23\
\
Expired\
\
Verified\
on Jan 16, 2024, 02:59 PM\
\
[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).\
\
\
Compare\
\
# Choose a tag to compare\
\
## Sorry, something went wrong.\
\
Filter\
\
Loading\
\
## Sorry, something went wrong.\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
## No results found\
\
[View all tags](https://github.com/pytorch/pytorch/tags)\
\
[PyTorch 1.10 Release, including CUDA Graphs APIs, Frontend and compiler improvements](https://github.com/pytorch/pytorch/releases/tag/v1.10.0)\
\
# 1.10.0 Release Notes\
\
- Highlights\
- Backwards Incompatible Change\
- New Features\
- Improvements\
- Performance\
- Documentation\
\
# Highlights\
\
We are excited to announce the release of PyTorch 1.10. This release is composed of over 3,400 commits since 1.9, made by 426 contributors. We want to sincerely thank our community for continuously improving PyTorch.\
\
PyTorch 1.10 updates are focused on improving training and performance of PyTorch, and developer usability. Highlights include:\
\
- CUDA Graphs APIs are integrated to reduce CPU overheads for CUDA workloads.\
- Several frontend APIs such as FX, `torch.special`, and `nn.Module` Parametrization, have moved from beta to stable.\
- Support for automatic fusion in JIT Compiler expands to CPUs in addition to GPUs.\
- Android NNAPI support is now available in beta.\
\
You can check the blogpost that shows the new features [here](https://pytorch.org/blog/pytorch-1.10-released/).\
\
# Backwards Incompatible changes\
\
## Python API\
\
### `torch.any`/ `torch.all` behavior changed slightly to be more consistent for zero-dimension, `uint8` tensors. ( [\#64642](https://github.com/pytorch/pytorch/pull/64642))\
\
These two functions match the behavior of NumPy, returning an output dtype of bool for all support dtypes, except for `uint8` (in which case they return a 1 or a 0, but with `uint8` dtype). In some cases with 0-dim tensor inputs, the returned `uint8` value could mistakenly take on a value > 1. This has now been fixed.\
\
| 1.9.1 | 1.10.0 |\
| --- | --- |\
| ```<br>>>> torch.all(torch.tensor(42, dtype=torch.uint8))<br>tensor(1, dtype=torch.uint8)<br>>>> torch.all(torch.tensor(42, dtype=torch.uint8), dim=0)<br>tensor(42, dtype=torch.uint8) # wrong, old behavior<br>      <br>``` | ```<br>>>> torch.all(torch.tensor(42, dtype=torch.uint8))<br>tensor(1, dtype=torch.uint8)<br>>>> torch.all(torch.tensor(42, dtype=torch.uint8), dim=0)<br>tensor(1, dtype=torch.uint8) # new, corrected and consistent behavior<br>      <br>``` |\
\
### Remove deprecated `torch.{is,set}_deterministic` ( [\#62158](https://github.com/pytorch/pytorch/pull/62158))\
\
This is the end of the deprecation cycle for both of these functions. You should be using `torch.use_deterministic_algorithms` and `torch.are_deterministic_algorithms_enabled` instead.\
\
## Complex Numbers\
\
### **Conjugate View: [`tensor.conj()`](https://pytorch.org/docs/1.10./generated/torch.conj.html) now returns a view tensor that aliases the same memory and has conjugate bit set ( [\#54987](https://github.com/pytorch/pytorch/pull/54987), [\#60522](https://github.com/pytorch/pytorch/pull/60522), [\#66082](https://github.com/pytorch/pytorch/pull/66082), [\#63602](https://github.com/pytorch/pytorch/pull/63602)).**\
\
This means that `.conj()` is now an O(1) operation and returns a tensor that views the same memory as `tensor` and has conjugate bit set. This notion of conjugate bit enables fusion of operations with conjugation which gives a lot of performance benefit for operations like matrix multiplication. All out-of-place operations will have the same behavior as before, but an in-place operation on a conjugated tensor will additionally modify the input tensor.\
\
| 1.9.1 | 1.10.0 |\
| --- | --- |\
| ```<br>>>> import torch<br>>>> x = torch.tensor([1+2j])<br>>>> y = x.conj()<br>>>> y.add_(2)<br>>>> print(x)<br>tensor([1.+2.j])<br>      <br>``` | ```<br>>>> import torch<br>>>> x = torch.tensor([1+2j])<br>>>> y = x.conj()<br>>>> y.add_(2)<br>>>> print(x)<br>tensor([3.+2.j])<br>      <br>``` |\
\
Note: You can verify if the conj bit is set by calling `tensor.is_conj()`. The conjugation can be resolved, i.e., you can obtain a new tensor that doesn’t share storage with the input tensor at any time by calling `conjugated_tensor.clone()` or `conjugated_tensor.resolve_conj()` .\
\
Note that these conjugated tensors behave differently from the corresponding numpy arrays obtained from `np.conj()` when an in-place operation is performed on them (similar to the example shown above).\
\
### **Negative View: `tensor.conj().neg()` returns a view tensor that aliases the same memory as both tensor and `tensor.conj()` and has a negative bit set ( [\#56058](https://github.com/pytorch/pytorch/pull/56058)).**\
\
`conjugated_tensor.neg()` continues to be an O(1) operation, but the returned tensor shares memory with both `tensor` and `conjugated_tensor`.\
\
| 1.9.1 | 1.10.0 |\
| --- | --- |\
| ```<br>>>> x = torch.tensor([1+2j])<br>>>> y = x.conj()<br>>>> z = y.imag<br>>>> z.add_(2)<br>>>> print(x)<br>tensor([1.+2.j])<br>      <br>``` | ```<br>>>> x = torch.tensor([1+2j])<br>>>> y = x.conj()<br>>>> z = y.imag<br>>>> print(z.is_neg())<br>True<br>>>> z.add_(2)<br>>>> print(x)<br>tensor([1.-0.j])<br>      <br>``` |\
\
### `tensor.numpy()` now throws `RuntimeError` when called on a tensor with conjugate or negative bit set ( [\#61925](https://github.com/pytorch/pytorch/pull/61925)).\
\
Because the notion of conjugate bit and negative bit doesn’t exist outside of PyTorch, calling operations that return a Python object viewing the same memory as input like `.numpy()` would no longer work for tensors with conjugate or negative bit set.\
\
| 1.9.1 | 1.10.0 |\
| --- | --- |\
| ```<br>>>> x = torch.tensor([1+2j])<br>>>> y = x.conj().imag<br>>>> print(y.numpy())<br>[2.]<br>      <br>``` | ```<br>>>> x = torch.tensor([1+2j])<br>>>> y = x.conj().imag<br>>>> print(y.numpy())<br>RuntimeError: Can't call numpy() on Tensor that has negative<br>bit set. Use tensor.resolve_neg().numpy() instead.<br>      <br>``` |\
\
## Autograd\
\
### Raise `TypeError` instead of `RuntimeError` when assigning to a Tensor’s grad field with wrong type ( [\#64876](https://github.com/pytorch/pytorch/pull/64876))\
\
Setting the `.grad` field with a non-None and non-Tensor object used to return a `RuntimeError` but it now properly returns a `TypeError`. If your code was catching this error, you should simply update it to catch a `TypeError` instead of a `RuntimeError`.\
\
| 1.9.1 | 1.10.0 |\
| --- | --- |\
| ```<br>try:<br>    # Assigning an int to a Tensor's grad field<br>    a.grad = 0<br>except RuntimeError as e:<br>    pass<br>      <br>``` | ```<br>try:<br>   a.grad = 0<br>except TypeError as e:<br>    pass<br>      <br>``` |\
\
### Raise error when inputs to `autograd.grad` are empty ( [\#52016](https://github.com/pytorch/pytorch/pull/52016))\
\
Calling `autograd.grad` with an empty list of inputs used to do the same as backward. To reduce confusion, it now raises the expected error. If you were relying on this, you can simply update your code as follows:\
\
| 1.9.1 | 1.10.0 |\
| --- | --- |\
| ```<br>grad = autograd.grad(out, tuple())<br>assert grad == tuple()<br>      <br>``` | ```<br>out.backward()<br>      <br>``` |\
\
### Optional arguments to `autograd.gradcheck` and `autograd.gradgradcheck` are now kwarg-only ( [\#65290](https://github.com/pytorch/pytorch/pull/65290))\
\
These two functions now have a significant number of optional arguments controlling what they do (i.e., `eps`, `atol`, `rtol`, `raise_exception`, etc.). To improve readability, we made these arguments kwarg-only. If you are passing these arguments to `autograd.gradcheck` or `autograd.gradgradcheck` as positional arguments, you can update your code as follows:\
\
| 1.9.1 | 1.10.0 |\
| --- | --- |\
| ```<br>torch.autograd.gradcheck(fn, x, 1e-6)<br>      <br>``` | ```<br>torch.autograd.gradcheck(fn, x, eps=1e-6)<br>      <br>``` |\
\
### In-place detach ( `detach_`) now errors for views that return multiple outputs ( [\#58285](https://github.com/pytorch/pytorch/pull/58285))\
\
This change is finishing the deprecation cycle for the inplace-over-view logic. In particular, a few things that were warning are updated:\
\
```\
* `detach_` will now raise an error when invoked on any view created by `split`, `split_with_sizes`, or `chunk`. You should use the non-inplace `detach` instead.\
* The error message for when an in-place operation (that is not detach) is performed on a view created by `split`, `split_with_size`, and `chunk` has been changed from "This view is an output of a function..." to "This view is the output of a function...".\
\
```\
\
| 1.9.1 | 1.10.0 |\
| --- | --- |\
| ```<br>b = a.split(1)[0]<br>b.detach_()<br>      <br>``` | ```<br>b = a.split(1)[0]<br>c = b.detach()<br>      <br>``` |\
\
### Fix saved variable unpacking version counter ( [\#60195](https://github.com/pytorch/pytorch/pull/60195))\
\
In-place on the unpacked SavedVariables used to be ignored. They are now properly detected which can lead to errors saying that a variable needed for backward was modified in-place.\
\
This is a valid error and the ...\
\
[Read more](https://github.com/pytorch/pytorch/releases/tag/v1.10.0)\
\
Assets3\
\
Loading\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
yzhangcs, zasdfgbnm, oke-aditya, wolegechu, zhiqwang, edgarriba, Kyeongpil, seemethere, krshrimali, EdisonLeeeee, and 40 more reacted with thumbs up emojiyzhangcs, zasdfgbnm, oke-aditya, zhiqwang, edgarriba, Kyeongpil, arcesoftware, Varal7, iomrla, mfaccin, and 3 more reacted with laugh emojiyzhangcs, zhiqwang, edgarriba, PingchuanMa, dfalbel, Kyeongpil, tmke8, Nikronic, alexeygolyshev, WangDeyao, and 8 more reacted with hooray emojiyzhangcs, zasdfgbnm, oke-aditya, gorodnitskiy, zhiqwang, edgarriba, AdilZouitine, Kyeongpil, FranklinAurelio, alexander-soare, and 17 more reacted with heart emojiaraffin, yzhangcs, zasdfgbnm, zhiqwang, edgarriba, dfalbel, Kyeongpil, anjali411, Nikronic, alexeygolyshev, and 9 more reacted with rocket emojiyzhangcs, zasdfgbnm, zhiqwang, edgarriba, krshrimali, SomeoneSerge, arcesoftware, Varal7, iomrla, mfaccin, and tolgacangoz reacted with eyes emoji\
\
All reactions\
\
- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)50 reactions\
- ![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)13 reactions\
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)18 reactions\
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)27 reactions\
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)19 reactions\
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)11 reactions\
\
73 people reacted\
\
## Small bug fix release\
\
Sep 22, 2021\
22 Sep 12:58\
\
\
![@malfet](https://avatars.githubusercontent.com/u/2453524?s=40&v=4)[malfet](https://github.com/malfet)\
\
[v1.9.1](https://github.com/pytorch/pytorch/tree/v1.9.1)\
\
[`dfbd030`](https://github.com/pytorch/pytorch/commit/dfbd030854359207cb3040b864614affeace11ce)\
\
This commit was created on GitHub.com and signed with GitHub’s **verified signature**.\
The key has expired.\
\
\
GPG key ID: 4AEE18F83AFDEB23\
\
Expired\
\
Verified\
on Nov 7, 2024, 11:05 AM\
\
[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).\
\
\
Compare\
\
# Choose a tag to compare\
\
## Sorry, something went wrong.\
\
Filter\
\
Loading\
\
## Sorry, something went wrong.\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
## No results found\
\
[View all tags](https://github.com/pytorch/pytorch/tags)\
\
[Small bug fix release](https://github.com/pytorch/pytorch/releases/tag/v1.9.1)\
\
# PyTorch 1.9.1 Release Notes\
\
- Improvements\
- Bug Fixes\
- Documentation\
\
# Improvements\
\
- Stop warning on `.names()` access in `max_pool2d` [#60059](https://github.com/pytorch/pytorch/pull/60059)\
- Remove Caffe2 thread-pool leak warning [#60318](https://github.com/pytorch/pytorch/pull/60318)\
- Add option to skip GitHub tag validation for `torch.hub.load` [#62139](https://github.com/pytorch/pytorch/pull/62139)\
- Use `log.warning` in `torch.distributed.run` to print OMP\_NUM\_THREADS warning [#63953](https://github.com/pytorch/pytorch/pull/63953)\
- TorchElastic: Pretty print the failure message captured by [@record](https://github.com/record) [#64036](https://github.com/pytorch/pytorch/pull/64036)\
- `torch.distribtued.run` to set `nproc_per_node` to 1 by default [#61552](https://github.com/pytorch/pytorch/pull/61552)\
- Remove experimental API warning from `torch.distributed.elastic.utils.store` [#60807](https://github.com/pytorch/pytorch/pull/60807)\
- Deprecate `use_env` in `torch.distributed.run` [#59409](https://github.com/pytorch/pytorch/pull/59409)\
- Better engineering changes for torch.distributed launcher [#59152](https://github.com/pytorch/pytorch/pull/59152)\
\
# Bug fixes\
\
## Distributed / TorchElastic\
\
- Make init\_method=tcp:// compatible with `torch.distributed.run` [#63910](https://github.com/pytorch/pytorch/pull/63910)\
- Fix default parameters (number of restarts, log level, number of processes per node) that regressed with the transition from `torch.distributed.launch` and `torch.distributed.run` and clarify the documentation accordingly [#61294](https://github.com/pytorch/pytorch/pull/61294)\
\
## Hub\
\
- Fix HTTP/403 error when calling `torch.hub.load` for TorchVision models [#62072](https://github.com/pytorch/pytorch/pull/62072)\
\
## Misc\
\
- `torch.mm` to check input matrix sizes shapes [#61394](https://github.com/pytorch/pytorch/pull/61394)\
\
# Documentation\
\
- Fix broken link in elastic launch doc [#62378](https://github.com/pytorch/pytorch/pull/62378)\
- Fix typo in `torch.distribtued.run` warning message [#61127](https://github.com/pytorch/pytorch/pull/61127)\
\
### Contributors\
\
- [![@record](https://avatars.githubusercontent.com/u/468913?s=64&v=4)](https://github.com/record)\
\
record\
\
\
Assets2\
\
Loading\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)17pit-ray, semaphore-egg, moskomule, Supermaxman, snakers4, alexeygolyshev, jasperzhong, sudoflex, voldemortX, Rishit-dagli, and 7 more reacted with thumbs up emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)3www516717402, tolgacangoz, and ryumh99 reacted with eyes emoji\
\
All reactions\
\
- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)17 reactions\
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)3 reactions\
\
19 people reacted\
\
## LTS 1.8.2, Wrap cub in its own namespace\
\
Aug 17, 2021\
17 Aug 18:33\
\
\
![@seemethere](https://avatars.githubusercontent.com/u/1700823?s=40&v=4)[seemethere](https://github.com/seemethere)\
\
[v1.8.2](https://github.com/pytorch/pytorch/tree/v1.8.2)\
\
[`e0495a7`](https://github.com/pytorch/pytorch/commit/e0495a7aa104471d95dc85a1b8f6473fbcc427a8)\
\
This commit was created on GitHub.com and signed with GitHub’s **verified signature**.\
The key has expired.\
\
\
GPG key ID: 4AEE18F83AFDEB23\
\
Expired\
\
Verified\
on Nov 6, 2024, 05:34 PM\
\
[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).\
\
\
Compare\
\
# Choose a tag to compare\
\
## Sorry, something went wrong.\
\
Filter\
\
Loading\
\
## Sorry, something went wrong.\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
## No results found\
\
[View all tags](https://github.com/pytorch/pytorch/tags)\
\
[LTS 1.8.2, Wrap cub in its own namespace](https://github.com/pytorch/pytorch/releases/tag/v1.8.2)\
\
# **PyTorch 1.8.2 Release Notes**\
\
- Highlights\
- Bug Fixes\
\
# Highlights\
\
We are excited to announce the release of PyTorch 1.8.2. This is the first release we are making as part of the [Pytorch Enterprise Support Program](https://pytorch.org/enterprise-support-program). This release includes a bug fix requested by a customer in an LTS branch.\
\
We'd like to thank Microsoft for their support and work on this release.\
\
# Bug Fixes\
\
- Wrap cub in its own namespace ( [#55292](https://github.com/pytorch/pytorch/pull/55292)) ( [#61605](https://github.com/pytorch/pytorch/pull/61605))\
\
Assets2\
\
Loading\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)7hoangtnm, Dangzheng, zhouzhuojie, toandaominh1997, xiaoyu-work, victorgabr, and tolgacangoz reacted with thumbs up emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)4hoangtnm, kami93, chrisdahms-embark, and tolgacangoz reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)2hoangtnm and tolgacangoz reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)3hoangtnm, victorgabr, and tolgacangoz reacted with rocket emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)3RuleNHao, chrisdahms-embark, and tolgacangoz reacted with eyes emoji\
\
All reactions\
\
- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)7 reactions\
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)4 reactions\
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)2 reactions\
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)3 reactions\
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)3 reactions\
\
10 people reacted\
\
## PyTorch 1.9 Release, including Torch.Linalg and Mobile Interpreter\
\
Jun 15, 2021\
15 Jun 16:06\
\
\
![@anjali411](https://avatars.githubusercontent.com/u/20081078?s=40&v=4)[anjali411](https://github.com/anjali411)\
\
[v1.9.0](https://github.com/pytorch/pytorch/tree/v1.9.0)\
\
[`d69c22d`](https://github.com/pytorch/pytorch/commit/d69c22dd61a2f006dcfe1e3ea8468a3ecaf931aa)\
\
This commit was created on GitHub.com and signed with GitHub’s **verified signature**.\
The key has expired.\
\
\
GPG key ID: 4AEE18F83AFDEB23\
\
Expired\
\
Verified\
on Nov 5, 2024, 09:28 AM\
\
[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).\
\
\
Compare\
\
# Choose a tag to compare\
\
## Sorry, something went wrong.\
\
Filter\
\
Loading\
\
## Sorry, something went wrong.\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
## No results found\
\
[View all tags](https://github.com/pytorch/pytorch/tags)\
\
[PyTorch 1.9 Release, including Torch.Linalg and Mobile Interpreter](https://github.com/pytorch/pytorch/releases/tag/v1.9.0)\
\
# **PyTorch 1.9 Release Notes**\
\
- Highlights\
- Backwards Incompatible Change\
- Deprecations\
- New Features\
- Improvements\
- Bug Fixes\
- Performance\
- Documentation\
\
# Highlights\
\
We are excited to announce the release of PyTorch 1.9. The release is composed of more than 3,400 commits since 1.8, made by 398 contributors. Highlights include:\
\
- Major improvements to support scientific computing, including torch.linalg, torch.special, and Complex Autograd\
- Major improvements in on-device binary size with Mobile Interpreter\
- Native support for elastic-fault tolerance training through the upstreaming of TorchElastic into PyTorch Core\
- Major updates to the PyTorch RPC framework to support large scale distributed training with GPU support\
- New APIs to optimize performance and packaging for model inference deployment\
- Support for Distributed training, GPU utilization and SM efficiency in the PyTorch Profiler\
\
We’d like to thank the community for their support and work on this latest release. We’d especially like to thank Quansight and Microsoft for their contributions.\
\
You can find more details on all the highlighted features in the [_PyTorch 1.9 Release blogpost_](https://pytorch.org/blog/pytorch-1.9-released/).\
\
# Backwards Incompatible changes\
\
## Python API\
\
- **`torch.divide` with `rounding_mode='floor'` now returns infinity when a non-zero number is divided by zero (** [**#56893**](https://github.com/pytorch/pytorch/pull/56893) **).**\
\
\
This fixes the `rounding_mode='floor'` behavior to return the same non-finite values as other rounding modes when there is a division by zero. Previously it would always result in a NaN value, but a non-zero number divided by zero should return +/- infinity in IEEE floating point arithmetic. Note this does not effect `torch.floor_divide` or the floor division operator, which currently use `rounding_mode='trunc'` (and are also deprecated for that reason).\
\
| 1.8.1 | 1.9.0 |\
| --- | --- |\
| ```<br>>>> a = torch.tensor([-1.0, 0.0, 1.0])<br>>>> b = torch.tensor([0.0])<br>>>> torch.divide(a, b, rounding_mode='floor')<br>tensor([nan, nan, nan])<br>      <br>``` | ```<br>>>> a = torch.tensor([-1.0, 0.0, 1.0])<br>>>> b = torch.tensor([0.0])<br>>>> torch.divide(a, b, rounding_mode='floor')<br>tensor([-inf, nan, inf])<br>      <br>``` |\
\
- **Legacy tensor constructors and `Tensor.new` no longer support passing both `Tensor` and `device` as inputs ( [#58108](https://github.com/pytorch/pytorch/pull/58108)).**\
\
\
This fixes a bug in which 1-element integer tensors were misinterpreted as specifying tensor size, yielding an uninitialized tensor. As noted in the error message, use the new-style `torch.tensor(...)` or `torch.as_tensor(...)` to copy or alias an existing tensor. If you want to create an uninitialized tensor, use `torch.empty(...)`.\
\
| 1.8.1 | 1.9.0 |\
| --- | --- |\
| ```<br>>>> a = torch.tensor([1])<br>>>> torch.LongTensor(a, device='cpu') # uninitialized<br>tensor([7022349217739848992])<br>>>> a.new(a, device='cpu')<br>tensor([4294967295]) # uninitialized<br>      <br>``` | ```<br>>>> a = torch.tensor([1])<br>>>> torch.LongTensor(a, device='cpu')<br>RuntimeError: Legacy tensor constructor of the form torch.Tensor(tensor, device=device) is<br>not supported. Use torch.tensor(...) or torch.as_tensor(...) instead.<br>>>> a.new(a, device='cpu')<br>RuntimeError: Legacy tensor new of the form tensor.new(tensor, device=device) is not<br>supported. Use torch.as_tensor(...) instead.<br>      <br>``` |\
\
- **`torch.divide` with `rounding_mode='true'` is replaced with `rounding_mode=None` ( [#51988](https://github.com/pytorch/pytorch/pull/51988)).**\
\
`torch.divide`'s undocumented `rounding_mode='true'` option has been removed, and instead `rounding_mode=None` should be passed to indicate no rounding should take place. This is equivalent to omitting the argument entirely.\
\
| 1.8.1 | 1.9.0 |\
| --- | --- |\
| ```<br>>>> a, b = torch.full((2,), 4.2), torch.full((2,), 2)<br>>>> torch.divide(a, b, rounding_mode='true')<br>tensor([2.1000, 2.1000])<br>      <br>``` | ```<br>>>> a, b = torch.full((2,), 4.2), torch.full((2,), 2)<br>>>> torch.divide(a, b, rounding_mode=None) # equivalent to  torch.divide(a, b, rounding_mode='true') from the prior release<br>tensor([2.1000, 2.1000])<br>      <br>``` |\
\
- **`import torch.tensor as tensor` is no longer supported ( [#53424](https://github.com/pytorch/pytorch/pull/53424)).**\
\
\
Instead, use `from torch import tensor`\
\
| 1.8.1 | 1.9.0 |\
| --- | --- |\
| ```<br>>>> import torch.tensor as tensor<br>>>> torch.tensor(1.)<br>tensor(1.)<br>      <br>``` | ```<br>>>> import torch.tensor as tensor<br>ModuleNotFoundError: No module named 'torch.tensor'<br>>>> from torch import tensor<br>>>> tensor(1.)<br>tensor(1.)<br>      <br>``` |\
\
- **binary release: `numpy` is no longer a required dependency**\
\
\
If you require `numpy` (and don't already have it installed) you will need to install it separately.\
\
## Autograd\
\
- **`torch.autograd.gradcheck.get_numerical_jacobian` and `torch.autograd.gradcheck.get_analytical_jacobian` no longer support functions that return complex valued output as well as any other values of `grad_out` not equal to 1** ( [#55692](https://github.com/pytorch/pytorch/pull/55692)).\
\
\
This change is a part of a refactor of `gradcheck`’s internals. Note that `gradcheck` itself still supports functions with complex output. This new restriction only applies to calls to the two internal helper functions. As a workaround, you can wrap your functions to return either the real or imaginary component of its output before calling these functions. Additionally these internal helpers no longer accept any other value except 1 for `grad_out` for any input function. Note that these helper functions are also being deprecated in this release.\
\
1.8.1:\
\
```\
get_numerical_jacobian(torch.complex, (a, b), grad_out=2.0)\
```\
\
1.9.0:\
\
```\
      def wrapped(fn):\
            def wrapper(*input):\
                return torch.real(fn(*input))\
            return wrapper\
\
        get_numerical_jacobian(wrapped(torch.complex), (a, b), grad_out=1.0)\
```\
\
- **`torch.autograd.gradcheck` now throws `GradcheckError`** ( [#55656](https://github.com/pytorch/pytorch/pull/55656)).\
\
\
This change is a part of a refactor of `gradcheck`’s internals. All errors that are able to be silenced by `raise_exception=False` now raise `GradcheckError` (which inherits from `RuntimeError`). If you explicitly check that the type of the error is `RuntimeError` you'll need to update your code to check for `GradcheckError` instead. Otherwise if you use something like `except` or `isinstance`, no changes are necessary.\
\
1.8.1:\
\
```\
# An example of a situation that will now return GradcheckError instead of\
# RuntimeError is when there is a jacobian mismatch, which can happen\
# for example when you forget to specify float64 for your inputs.\
try:\
    torch.autograd.gradcheck(torch.sin, (torch.ones(1, requires_grad=True),))\
except RuntimeError as e:\
    assert type(e) is RuntimeError # explicitly check type -> NEEDS UPDATE\
```\
\
1.9.0:\
\
```\
try:\
    torch.autograd.gradcheck(torch.sin, (torch.ones(1, requires_grad=True),)\
except RuntimeError as e:\
   # GradcheckError inherits from RuntimeError so you can still catch this\
   # with RuntimeError (No change necessary!)\
\
   # BUT, if you explicitly check type...\
   assert type(e) is torch.autograd.GradcheckError\
```\
\
- **Finished deprecation cycle for in-place view error checks** ( [#56093](https://github.com/pytorch/pytorch/pull/56093)).\
\
\
In-place modification of views will now raise an error if that view was created by a custom function or a function that returns multiple views, or if the view was created in no-grad mode. Modifying in-place a view created in the situations above are error-prone and have been deprecated since v1.5.0. Doing these in-place modifications are now forbidden. For more information on how to work around this, see the related sections the release notes linked below:\
\
  - [v1.5.0](https://github.com/pytorch/pytorch/releases?after=v1.5.1) (view created in custom autograd function, view created in no-grad block)\
  - [v1.7.0](https://github.com/pytorch/pytorch/releases?after=v1.8.0-rc3) (section on `split` and `chunk`, i.e., functions that return multiple views).\
\
## torch.nn\
\
- **Fixed regression for `nn.MultiheadAttention` to now apply bias flag to both in and out projection layers** ( [#52537](https://github.com/pytorch/pytorch/pull/52537)).\
\
\
In PyTorch 1.6, a regression was introduced that caused the `bias` flag of `nn.MultiheadAttention` only to apply to the input projection layer. This caused the output projection layer to always include a `bias` parameter, even with `bias=False` specified. The regression is now fixed in PyTorch 1.9, making the `bias` flag correctly apply to both the input and output projection layers. This fix is BC-breaking for the `bias=False` case as it will now result in no `bias` parameter for the output projection layer.\
\
| v1.6 - v1.8.1: | pre 1.6 & 1.9.0 |\
| --- | --- |\
| ```<br>>>> mha = torch.nn.MultiheadAttenti...<br>``` |\
\
[Read more](https://github.com/pytorch/pytorch/releases/tag/v1.9.0)\
\
Assets2\
\
Loading\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=3).\
\
![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)31titaneric, imaginary-person, aavbsouza, scaomath, szmigacz, erogol, krshrimali, isgursoy, toandaominh1997, lamhoangtung, and 21 more reacted with thumbs up emoji![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)3jordan-carson, tolgacangoz, and lastthyme reacted with laugh emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)18erogol, krshrimali, lamhoangtung, gemfield, ashim-mahara, Adnios, voldemortX, alexeygolyshev, Xreki, hoangtnm, and 8 more reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)7Issam28, hoangtnm, Nikronic, satishjasthi, jordan-carson, tolgacangoz, and lastthyme reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)20imaginary-person, aavbsouza, tirthasheshpatel, erogol, krshrimali, imirzadeh, lamhoangtung, gemfield, ashim-mahara, Adnios, and 10 more reacted with rocket emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)4zemu-unile, jordan-carson, tolgacangoz, and lastthyme reacted with eyes emoji\
\
All reactions\
\
- ![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)31 reactions\
- ![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)3 reactions\
- ![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)18 reactions\
- ![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)7 reactions\
- ![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)20 reactions\
- ![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)4 reactions\
\
43 people reacted\
\
[Previous](https://github.com/pytorch/pytorch/releases?page=2) [1](https://github.com/pytorch/pytorch/releases?page=1) [2](https://github.com/pytorch/pytorch/releases?page=2) _3_ [4](https://github.com/pytorch/pytorch/releases?page=4) [5](https://github.com/pytorch/pytorch/releases?page=5) [6](https://github.com/pytorch/pytorch/releases?page=6) [7](https://github.com/pytorch/pytorch/releases?page=7) [Next](https://github.com/pytorch/pytorch/releases?page=4)\
\
[Previous](https://github.com/pytorch/pytorch/releases?page=2) [Next](https://github.com/pytorch/pytorch/releases?page=4)\
\

