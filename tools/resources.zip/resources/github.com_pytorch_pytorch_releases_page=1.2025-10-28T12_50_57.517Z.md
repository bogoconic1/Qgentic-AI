[Skip to content](https://github.com/pytorch/pytorch/releases?page=1#start-of-content)

## Navigation Menu

Toggle navigation

[Homepage](https://github.com/)

[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fpytorch%2Fpytorch%2Freleases%3Fpage%3D1)

Appearance settings

- Platform









- [GitHub Copilot\\
\\
\\
\\
Write better code with AI](https://github.com/features/copilot)
- [GitHub Spark\\
\\
\\
New\\
\\
\\
Build and deploy intelligent apps](https://github.com/features/spark)
- [GitHub Models\\
\\
\\
New\\
\\
\\
Manage and compare prompts](https://github.com/features/models)
- [GitHub Advanced Security\\
\\
\\
\\
Find and fix vulnerabilities](https://github.com/security/advanced-security)
- [Actions\\
\\
\\
\\
Automate any workflow](https://github.com/features/actions)

- [Codespaces\\
\\
\\
\\
Instant dev environments](https://github.com/features/codespaces)
- [Issues\\
\\
\\
\\
Plan and track work](https://github.com/features/issues)
- [Code Review\\
\\
\\
\\
Manage code changes](https://github.com/features/code-review)
- [Discussions\\
\\
\\
\\
Collaborate outside of code](https://github.com/features/discussions)
- [Code Search\\
\\
\\
\\
Find more, search less](https://github.com/features/code-search)

Explore

- [Why GitHub](https://github.com/why-github)
- [Documentation](https://docs.github.com/)
- [GitHub Skills](https://skills.github.com/)
- [Blog](https://github.blog/)

Integrations

- [GitHub Marketplace](https://github.com/marketplace)
- [MCP Registry](https://github.com/mcp)

[View all features](https://github.com/features)

- Solutions







By company size

- [Enterprises](https://github.com/enterprise)
- [Small and medium teams](https://github.com/team)
- [Startups](https://github.com/enterprise/startups)
- [Nonprofits](https://github.com/solutions/industry/nonprofits)

By use case

- [App Modernization](https://github.com/solutions/use-case/app-modernization)
- [DevSecOps](https://github.com/solutions/use-case/devsecops)
- [DevOps](https://github.com/solutions/use-case/devops)
- [CI/CD](https://github.com/solutions/use-case/ci-cd)
- [View all use cases](https://github.com/solutions/use-case)

By industry

- [Healthcare](https://github.com/solutions/industry/healthcare)
- [Financial services](https://github.com/solutions/industry/financial-services)
- [Manufacturing](https://github.com/solutions/industry/manufacturing)
- [Government](https://github.com/solutions/industry/government)
- [View all industries](https://github.com/solutions/industry)

[View all solutions](https://github.com/solutions)

- Resources







Topics

- [AI](https://github.com/resources/articles?topic=ai)
- [DevOps](https://github.com/resources/articles?topic=devops)
- [Security](https://github.com/resources/articles?topic=security)
- [Software Development](https://github.com/resources/articles?topic=software-development)
- [View all](https://github.com/resources/articles)

Explore

- [Learning Pathways](https://resources.github.com/learn/pathways)
- [Events & Webinars](https://github.com/resources/events)
- [Ebooks & Whitepapers](https://github.com/resources/whitepapers)
- [Customer Stories](https://github.com/customer-stories)
- [Partners](https://github.com/partners)
- [Executive Insights](https://github.com/solutions/executive-insights)

- Open Source









- [GitHub Sponsors\\
\\
\\
\\
Fund open source developers](https://github.com/sponsors)

- [The ReadME Project\\
\\
\\
\\
GitHub community articles](https://github.com/readme)

Repositories

- [Topics](https://github.com/topics)
- [Trending](https://github.com/trending)
- [Collections](https://github.com/collections)

- Enterprise









- [Enterprise platform\\
\\
\\
\\
AI-powered developer platform](https://github.com/enterprise)

Available add-ons

- [GitHub Advanced Security\\
\\
\\
\\
Enterprise-grade security features](https://github.com/security/advanced-security)
- [Copilot for business\\
\\
\\
\\
Enterprise-grade AI features](https://github.com/features/copilot/copilot-business)
- [Premium Support\\
\\
\\
\\
Enterprise-grade 24/7 support](https://github.com/premium-support)

- [Pricing](https://github.com/pricing)

Search or jump to...

# Search code, repositories, users, issues, pull requests...

Search


Clear

[Search syntax tips](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax)

# Provide feedback

We read every piece of feedback, and take your input very seriously.

Include my email address so I can be contacted

Cancel
Submit feedback

# Saved searches

## Use saved searches to filter your results more quickly

Name

Query

To see all available qualifiers, see our [documentation](https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax).


Cancel
Create saved search

[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fpytorch%2Fpytorch%2Freleases%3Fpage%3D1)

[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=header+logged+out&ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E%2Freleases%2Findex&source=header-repo&source_repo=pytorch%2Fpytorch)

Appearance settings

Resetting focus

You signed in with another tab or window. [Reload](https://github.com/pytorch/pytorch/releases?page=1) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/pytorch/pytorch/releases?page=1) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/pytorch/pytorch/releases?page=1) to refresh your session.Dismiss alert

{{ message }}

[pytorch](https://github.com/pytorch)/ **[pytorch](https://github.com/pytorch/pytorch)** Public

- Couldn't load subscription status.
Retry











### Uh oh!







There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=1).

- [Fork\\
25.7k](https://github.com/login?return_to=%2Fpytorch%2Fpytorch)
- [Star\\
94.3k](https://github.com/login?return_to=%2Fpytorch%2Fpytorch)


- [Code](https://github.com/pytorch/pytorch)
- [Issues5k+](https://github.com/pytorch/pytorch/issues)
- [Pull requests1.5k](https://github.com/pytorch/pytorch/pulls)
- [Actions](https://github.com/pytorch/pytorch/actions)
- [Projects12](https://github.com/pytorch/pytorch/projects)
- [Wiki](https://github.com/pytorch/pytorch/wiki)
- [Security4](https://github.com/pytorch/pytorch/security)






[**Uh oh!**](https://github.com/pytorch/pytorch/security)

[There was an error while loading.](https://github.com/pytorch/pytorch/security) [Please reload this page](https://github.com/pytorch/pytorch/releases?page=1).

- [Insights](https://github.com/pytorch/pytorch/pulse)

Additional navigation options

- [Code](https://github.com/pytorch/pytorch)
- [Issues](https://github.com/pytorch/pytorch/issues)
- [Pull requests](https://github.com/pytorch/pytorch/pulls)
- [Actions](https://github.com/pytorch/pytorch/actions)
- [Projects](https://github.com/pytorch/pytorch/projects)
- [Wiki](https://github.com/pytorch/pytorch/wiki)
- [Security](https://github.com/pytorch/pytorch/security)
- [Insights](https://github.com/pytorch/pytorch/pulse)

# Releases: pytorch/pytorch

[Releases](https://github.com/pytorch/pytorch/releases) [Tags](https://github.com/pytorch/pytorch/tags)

Releases · pytorch/pytorch

## 2.9 Release Notes

2 weeks ago
15 Oct 17:12


![@seemethere](https://avatars.githubusercontent.com/u/1700823?s=40&v=4)[seemethere](https://github.com/seemethere)

[v2.9.0](https://github.com/pytorch/pytorch/tree/v2.9.0)

[`0fabc3b`](https://github.com/pytorch/pytorch/commit/0fabc3ba44823f257e70ce397d989c8de5e362c1)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.


GPG key ID: B5690EEEBB952194

Verified
on Oct 8, 2025, 09:09 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

## Sorry, something went wrong.

Filter

Loading

## Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/pytorch/pytorch/releases?page=1).

## No results found

[View all tags](https://github.com/pytorch/pytorch/tags)

[2.9 Release Notes](https://github.com/pytorch/pytorch/releases/tag/v2.9.0)[Latest](https://github.com/pytorch/pytorch/releases/latest)

[Latest](https://github.com/pytorch/pytorch/releases/latest)

# PyTorch 2.9.0 Release Notes

- [Highlights](https://github.com/pytorch/pytorch/releases?page=1#highlights)
- [Backwards Incompatible Changes](https://github.com/pytorch/pytorch/releases?page=1#backwards-incompatible-changes)
- [Deprecations](https://github.com/pytorch/pytorch/releases?page=1#deprecations)
- [New Features](https://github.com/pytorch/pytorch/releases?page=1#new-features)
- [Improvements](https://github.com/pytorch/pytorch/releases?page=1#improvements)
- [Bug fixes](https://github.com/pytorch/pytorch/releases?page=1#bug-fixes)
- [Performance](https://github.com/pytorch/pytorch/releases?page=1#performance)
- [Documentation](https://github.com/pytorch/pytorch/releases?page=1#documentation)
- [Developers](https://github.com/pytorch/pytorch/releases?page=1#developers)
- [Security](https://github.com/pytorch/pytorch/releases?page=1#security)

# Highlights

|     |
| --- |
| **Unstable (API-Unstable)** |
| Updates to the stable libtorch ABI for third-party C++/CUDA extensions |
| Symmetric memory that enables easy programming of multi-GPU kernels |
| The ability to arbitrarily toggle error or resume on graph breaks in torch.compile |
| Expanded wheel variant support to include ROCm, XPU and CUDA 13 |
| FlexAttention enablement on Intel GPUs |
| Flash decoding optimization based on FlexAttention on X86 CPU |
| ARM Platform improvements and optimizations |
| Enablement of Linux aarch64 binary wheel builds across all supported CUDA versions |

For more details about these highlighted features, you can look at the [release blogpost](https://pytorch.org/blog/pytorch-2-9/). Below are the full release notes for this release.

# Backwards Incompatible Changes

## Min supported Python version is now 3.10 ( [\#162310](https://github.com/pytorch/pytorch/pull/162310))

The minimum version of Python required for PyTorch 2.9.0 is 3.10. We also have 3.14 and 3.14t available as preview with this release.

## Undefined behavior when an output of a custom operator shares storage with an input

This is a reminder that outputs of PyTorch custom operators (that are registered using the `torch.library` or `TORCH_LIBRARY` APIs) are not allowed to return Tensors that share storage with input tensors. The violation of this condition leads to undefined behavior: sometimes the result will be correct, sometimes it will be garbage.

After [#163227](https://github.com/pytorch/pytorch/pull/163227), custom operators that violated this condition that previously returned correct results under `torch.compile` may now return silently incorrect results under `torch.compile`. Because this is changing the behavior of undefined behavior, we do not consider this to be a bug, but we are still documenting it in this section as a "potentially unexpected behavior change".

This is one of the conditions checked for by [`torch.library.opcheck`](https://docs.pytorch.org/docs/stable/library.html#testing-custom-ops) and is mentioned in [The Custom Operators Manual](https://docs.google.com/document/d/1_W62p8WJOQQUzPsJYa7s701JXt0qf2OfLub2sbkHOaU/edit?tab=t.0#bookmark=id.4c0um7xkba6e)

### More details

Outputs of PyTorch custom operators are not allowed to return Tensors that share storage with input tensors

For example, the following two custom operators are not valid custom operators:

```
@torch.library.custom_op("mylib::foo", mutates_args=())
def foo(x: torch.Tensor) -> torch.Tensor:
    # the result of `foo` must not directly be an input to foo.
    return x

@torch.library.custom_op("mylib::bar", mutates_args=())
def bar(x: torch.Tensor) -> torch.Tensor:
    # the result of bar must not be a view of an input of bar
    return x.view(-1)
```

The easiest workaround is to add an extra `.clone()` to the outputs:

```
@torch.library.custom_op("mylib::foo", mutates_args=())
def foo(x: torch.Tensor) -> torch.Tensor:
    return x.clone()

@torch.library.custom_op("mylib::bar", mutates_args=())
def bar(x: torch.Tensor) -> torch.Tensor:
    return x.view(-1).clone()
```

A common way to get into this situation is for a user to want to create a custom operator that sometimes mutates the input in-place and sometimes returns a new Tensor, like in the following example.

```
@torch.library.custom_op("mylib::baz", mutates_args=["x"])
def baz(x: torch.Tensor) -> torch.Tensor:
    if inplace:
        x.sin_()
        return x
    else:
        return x.sin()
```

This dynamism is not supported and leads to undefined behavior. The workaround is to split the custom operator into two custom operators, one that always mutates the input in-place, and another that always returns a new Tensor.

```
@torch.library.custom_op("mylib::baz_outplace", mutates_args=())
def baz_outplace(x: torch.Tensor) -> torch.Tensor:
    return x.sin()

@torch.library.custom_op("mylib::baz_inplace", mutates_args=["x"])
def baz_inplace(x: torch.Tensor) -> torch.Tensor:
    x.sin_()

def baz(x):
    if inplace:
        baz_inplace(x)
        return x
    else:
        return baz_outplace(x)
```

## Build metal kernels of MacOS-14+ and remove all pre-MacOS-14 specific logic, requires MacOS-14+ going forward ( [\#159733](https://github.com/pytorch/pytorch/pull/159733), [\#159912](https://github.com/pytorch/pytorch/pull/159912))

PyTorch MPS is only supported on MacOS-14 or later. If you need to use MPS on MacOS Ventura, please avoid updating to Python-3.9 or above

## Upgrade to DLPack 1.0 ( [\#145000](https://github.com/pytorch/pytorch/pull/145000))

This upgrade is doing the same BC-breaking changes as the DLPack release. Objects in `torch.utils.dlpack` have been updated to reflect these changes, such as `DLDeviceType`.

See the PR for details on the exact changes and how to update your code.

## Raise appropriate errors in `torch.cat` ( [\#158249](https://github.com/pytorch/pytorch/pull/158249))

`torch.cat` now raises `ValueError`, `IndexError` or `TypeError` where appropriate instead of the generic `RuntimeError`. If you code was catching these errors, you can update to catch the new error type.

## Default to `dynamo=True` for ONNX exporter ( [\#159646](https://github.com/pytorch/pytorch/pull/159646), [\#162726](https://github.com/pytorch/pytorch/pull/162726))

Previously `torch.onnx.export(...)` used the legacy TorchScript exporter if no arguments were provied. The ONNX exporter now uses the newer `torch.export.export` pipeline by default ( `dynamo=True`). This change improves graph fidelity and future-proofs exports, but may surface graph capture errors that were previously masked or handled differently.

Previously in torch 2.8.0:

```
# API calls the legacy exporter with dynamo=False
torch.onnx.export(...)
```

Now in torch 2.9.0:

```
# To preserve the original behavior
torch.onnx.export(..., dynamo=False)

# Export onnx model through torch.export.export
torch.onnx.export(...)
```

Recommendation: first try the new default; only fall back if you hit blocking issues and report them upstream.

Long term solution: fix the root cause instead of relying on fallback or TorchScript exporter.

## Switch off runtime asserts by default in Export in favor of a shape guards function ( [\#160111](https://github.com/pytorch/pytorch/pull/160111), [\#161178](https://github.com/pytorch/pytorch/pull/161178), [\#161794](https://github.com/pytorch/pytorch/pull/161794))

To enable runtime asserts, use `export(..., prefer_deferred_runtime_asserts_over_guards=True)`. Also kills the `allow_complex_guards_as_runtime_asserts` flag, merging it into the former option.

Additionally, `exported_program.module()` will generate a call to a `_guards_fn` submodule that will run additional checks on inputs. Users who do not want this behavior can either remove this call in the graph, or do `exported_program.module(check_guards=False)` to avoid the generation.

## Set default opset to 20 in ONNX ( [\#158802](https://github.com/pytorch/pytorch/pull/158802))

Opset 20 enables newer operator definitions. If your tooling or downstream runtime only supports opset 18, pin it explicitly. For the latest ONNX operators, you can experiment with opset 23.

Previously in torch 2.8.0:

```
# opset_version=18
torch.onnx.export(...)
```

Now in torch 2.9.0:

```
# To preserve the original behavior
torch.onnx.export(..., opset_version=18)

# New: opset_version=20
torch.onnx.export(...)

# Use the latest supported opset: opset_version=23
torch.onnx.export(..., opset_version=23)
```

## Drop `draft_export` in exporter API ( [\#161454](https://github.com/pytorch/pytorch/pull/161454), [\#162225](https://github.com/pytorch/pytorch/pull/162225))

Remove implicit draft tracing from the default exporter path, achieving clearer behaviour and faster failures.

The expensive `torch.export.draft_export` diagnostic path is no longer auto-invoked (which could take hours on large models). You can still opt in for deep diagnostics:

Previously in torch 2.8.0:

```
# If both torch.export.export(..., strict=False) and
# torch.export.export(..., strict=True) fail to capture
# the model graph, torch.export.draft_export(...) will be triggered,
# and uses real tensor to trace/export the model.
#
# Inside export_to_onnx.py:
#  ... torch.onnx.export(..., dynamo=True)
python export_to_onnx.py
```

Now in torch 2.9.0:

```
# To trigger torch.export.draft_export once
# torch.export.export strict=False/True both
# fail:

TORCH_ONNX_ENABLE_DRAFT_EXPORT=True python export_to_onnx.py
```

## Remove `torch.onnx.dynamo_export` and the `onnxrt` torch compile backend ( [\#158130](https://github.com/pytorch/pytorch/pull/158130), [\#158258](https://github.com/pytorch/pytorch/pull/158258))

`torch.onnx.dynamo_export` is removed. Please use `torch.onnx.export` instead.

The experimental ONNX Runtime compile backend ( `torch.compile(backend="onnxrt")`) is no longer supported.

## Remove `torch.onnx.enable_fake_mode` ( [\#161222](https://github.com/pytorch/pytorch/pull/161222))

The `dynamo=True` mode uses `FakeTensor` s by default which is memory efficient.

## Some public facing ONNX utility APIs for the TorchScript based exporter are now private ( [\#161323](https://github.com/pytorch/pytorch/pull/161323))

Deprecated members in `torch.onnx.verification` are removed. Previously private `torch.onnx.symbolic_opsets*` functions will no longer be accessible. Consider making a copy of the source code if you need to access any private functions for compatibility with the TorchScript based exporter.

## Remove `torch.onnx.symbolic_caffe2` ( [\#157102](https://github.com/pytorch/pytorch/pull/157102))

Support for `caffe2` in the ONNX exporter has ended and is removed.

## Remove `/d2implyavx512upperregs` flag that slows build ( [\#159431](https://github.com/pytorch/pytorch/pull/159431))

Re-introduced AVX512 optimizations for Windows VS2022 builds, may cause issues with specific versions of VS2022, see [#145702](https://github.com/pytorch/pytorch/issues/145702)

## Add `ScalarType` to shim conversion and `stable::Tensor.scalar_type` ( [\#160557](https://github.com/pytorch/pytorch/pull/160557))

Before, user extensions could only in abstract...

[Read more](https://github.com/pytorch/pytorch/releases/tag/v2.9.0)

Assets3

- [pytorch-v2.9.0.tar.gz](https://github.com/pytorch/pytorch/releases/download/v2.9.0/pytorch-v2.9.0.tar.gz)



sha256:c6980af3c0ea311f49f90987982be715e4d702539fea41e52f55ad7f0b105dc3



333 MB2 weeks ago2025-10-15T17:15:48Z

- [Source code(zip)](https://github.com/pytorch/pytorch/archive/refs/tags/v2.9.0.zip)

3 weeks ago2025-10-09T01:09:57Z

- [Source code(tar.gz)](https://github.com/pytorch/pytorch/archive/refs/tags/v2.9.0.tar.gz)

3 weeks ago2025-10-09T01:09:57Z


![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)18github-actions\[bot\], cyyever, nadzhou, little-sparkleeesss, obitodaitu, DefTruth, LuisMiSanVe, michaelnny, FomalhautWeisszwerg, ancestor-mithril, and 8 more reacted with thumbs up emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)39atalman, cxzhong, RaulPL, zhewenl, healy-hub, Finn-Hecker, khushi-411, akihironitta, CHC383, lckr, and 29 more reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)4shinGangan, nadzhou, uwu-420, and shokry110 reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)6github-actions\[bot\], nadzhou, Puiching-Memory, uwu-420, NoeFontana, and shokry110 reacted with rocket emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)3shinGangan, HailToThee, and shokry110 reacted with eyes emoji

55 people reacted

## PyTorch 2.8.0 Release

Aug 6
06 Aug 17:06


![@jbschlosser](https://avatars.githubusercontent.com/u/75754324?s=40&v=4)[jbschlosser](https://github.com/jbschlosser)

[v2.8.0](https://github.com/pytorch/pytorch/tree/v2.8.0)

[`ba56102`](https://github.com/pytorch/pytorch/commit/ba56102387ef21a3b04b357e5b183d48f0afefc7)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.


GPG key ID: B5690EEEBB952194

Verified
on Aug 4, 2025, 12:51 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

Filter

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.8.0 Release](https://github.com/pytorch/pytorch/releases/tag/v2.8.0)

# PyTorch 2.8.0 Release Notes

- [Highlights](https://github.com/pytorch/pytorch/releases?page=1#highlights)
- [Backwards Incompatible Changes](https://github.com/pytorch/pytorch/releases?page=1#backwards-incompatible-changes)
- [Deprecations](https://github.com/pytorch/pytorch/releases?page=1#deprecations)
- [New Features](https://github.com/pytorch/pytorch/releases?page=1#new-features)
- [Improvements](https://github.com/pytorch/pytorch/releases?page=1#improvements)
- [Bug fixes](https://github.com/pytorch/pytorch/releases?page=1#bug-fixes)
- [Performance](https://github.com/pytorch/pytorch/releases?page=1#performance)
- [Documentation](https://github.com/pytorch/pytorch/releases?page=1#documentation)
- [Developers](https://github.com/pytorch/pytorch/releases?page=1#developers)

# Highlights

|     |
| --- |
| **Unstable** |
| torch::stable::Tensor |
| High-performance quantized LLM inference on Intel CPUs with native PyTorch |
| Experimental Wheel Variant Support |
| Inductor CUTLASS backend support |
| Inductor Graph Partition for CUDAGraph |
| Control Flow Operator Library |
| HuggingFace SafeTensors support in PyTorch Distributed Checkpointing |
| SYCL support in PyTorch CPP Extension API |
| A16W4 on XPU Device |
| Hierarchical compilation with torch.compile |
| Intel GPU distributed backend (XCCL) support |

For more details about these highlighted features, you can look at the [release blogpost](https://pytorch.org/blog/pytorch-2-8/).

Below are the full release notes for this release.

# Tracked Regressions

### Windows wheel builds with CUDA 12.9.1 stack overflow during build ( [\#156181](https://github.com/pytorch/pytorch/issues/156181))

Due to a bug introduced in CUDA 12.9.1, we are unable to complete full Windows wheel builds with this

version, as compilation of `torch.segment_reduce()` crashes the build. Thus, we provide a wheel

without `torch.segment_reduce()` included in order to sidestep the issue. If you need support

for `torch.segment_reduce()`, please utilize a different version.

# Backwards Incompatible Changes

## CUDA Support

### Removed support for Maxwell and Pascal architectures with CUDA 12.8 and 12.9 builds ( [\#157517](https://github.com/pytorch/pytorch/issues/157517), [\#158478](https://github.com/pytorch/pytorch/pull/158478), [\#158744](https://github.com/pytorch/pytorch/pull/158744))

Due to binary size limitations, support for sm50 - sm60 architectures with CUDA 12.8 and 12.9 has

been dropped for the 2.8.0 release. If you need support for these architectures, please utilize

CUDA 12.6 instead.

## Python Frontend

### Calling an op with an input dtype that is unsupported now raises `NotImplementedError` instead of `RuntimeError` ( [\#155470](https://github.com/pytorch/pytorch/pull/155470))

Please update exception handling logic to reflect this.

In 2.7.0

```
try:
    torch.nn.Hardshrink()(torch.randint(0, 5, (10,)))
except RuntimeError:
    ...

```

In 2.8.0

```
try:
    torch.nn.Hardshrink()(torch.randint(0, 5, (10,)))
except NotImplementedError:
    ...

```

### Added missing in-place on view check to custom `autograd.Function` ( [\#153094](https://github.com/pytorch/pytorch/pull/153094))

In 2.8.0, if a custom `autograd.Function` mutates a view of a leaf requiring grad,

it now properly raises an error. Previously, it would silently leak memory.

```
   class Func(torch.autograd.Function):
        @staticmethod
        def forward(ctx, inp):
            inp.add_(1)
            ctx.mark_dirty(inp)
            return inp

        @staticmethod
        def backward(ctx, gO):
            pass

    a = torch.tensor([1.0, 2.0], requires_grad=True)
    b = a.view_as(a)
    Func.apply(b)

```

Output:

Version 2.7.0

```
Runs without error, but leaks memory

```

Version 2.8.0

```
RuntimeError: a view of a leaf Variable that requires grad is being used in an in-place operation

```

### An error is now properly thrown for the out variant of `tensordot` when called with a `requires_grad=True` tensor ( [\#150270](https://github.com/pytorch/pytorch/pull/150270))

Please avoid passing an out tensor with `requires_grad=True` as gradients cannot be

computed for this tensor.

In 2.7.0

```
a = torch.empty((4, 2), requires_grad=True)
b = torch.empty((2, 4), requires_grad=True)
c = torch.empty((2, 2), requires_grad=True)
# does not error, but gradients for c cannot be computed
torch.tensordot(a, b, dims=([1], [0]), out=c)

```

In 2.8.0

```
a = torch.empty((4, 2), requires_grad=True)
b = torch.empty((2, 4), requires_grad=True)
c = torch.empty((2, 2), requires_grad=True)
torch.tensordot(a, b, dims=([1], [0]), out=c)
# RuntimeError: tensordot(): the 'out' tensor was specified and requires gradients, and
# its shape does not match the expected result. Either remove the 'out' argument, ensure
# it does not require gradients, or make sure its shape matches the expected output.

```

## torch.compile

### Specialization of a tensor shape with `mark_dynamic` applied now correctly errors ( [\#152661](https://github.com/pytorch/pytorch/pull/152661))

Prior to 2.8, it was possible for a guard on a symbolic shape to be incorrectly

omitted if the symbolic shape evaluation was previously tested with guards

suppressed (this often happens within the compiler itself). This has been fixed

in 2.8 and usually will just silently "do the right thing" and add the correct

guard. However, if the new guard causes a tensor marked with `mark_dynamic` to become

specialized, this can result in an error. One workaround is to use

`maybe_mark_dynamic` instead of `mark_dynamic`.

See the discussion in issue [#157921](https://github.com/pytorch/pytorch/issues/157921) for more

context.

Version 2.7.0

```
import torch

embed = torch.randn(2, 8192)
x = torch.zeros(8192)

torch._dynamo.mark_dynamic(x, 0)

@torch.compile
def f(embedding_indices, x):
    added_tokens_mask = torch.where(x > 10000, 1, 0)
    ei = torch.narrow(embedding_indices, 1, 0, x.size(0))
    return ei.clone()

f(embed, x)
```

Version 2.8.0

```
import torch

embed = torch.randn(2, 8192)
x = torch.zeros(8192)

torch._dynamo.maybe_mark_dynamic(x, 0)

@torch.compile
def f(embedding_indices, x):
    added_tokens_mask = torch.where(x > 10000, 1, 0)
    ei = torch.narrow(embedding_indices, 1, 0, x.size(0))
    return ei.clone()

f(embed, x)
```

### Several config variables related to `torch.compile` have been renamed or removed

- Dynamo config variable `enable_cpp_framelocals_guard_eval` has changed to no longer have any effect ( [#151008](https://github.com/pytorch/pytorch/pull/151008)).
- Inductor config variable `rocm.n_max_profiling_configs` is deprecated ( [#152341](https://github.com/pytorch/pytorch/pull/152341)).


Instead, use ck-tile based configs `rocm.ck_max_profiling_configs` and

`rocm.ck_tile_max_profiling_configs`.
- Inductor config variable `autotune_fallback_to_aten` is deprecated ( [#154331](https://github.com/pytorch/pytorch/pull/154331)).


Inductor will no longer silently fall back to `ATen`. Please add `"ATEN"` to

`max_autotune_gemm_backends` for the old behavior.
- Inductor config variables `use_mixed_mm` and `mixed_mm_choice` are deprecated ( [#152071](https://github.com/pytorch/pytorch/pull/152071)). Inductor now supports prologue fusion, so there is no need for


special cases now.
- Inductor config setting `descriptive_names = False` is deprecated ( [#151481](https://github.com/pytorch/pytorch/pull/151481)). Please use one of the other available


options: `"torch"`, `"original_aten"`, or `"inductor_node"`.
- `custom_op_default_layout_constraint` has moved from inductor config to functorch config ( [#148104](https://github.com/pytorch/pytorch/pull/148104)). Please reference it via

`torch._functorch.config.custom_op_default_layout_constraint` instead of

`torch._inductor.config.custom_op_default_layout_constraint`.
- AOTI config variable `emit_current_arch_binary` is deprecated ( [#155768](https://github.com/pytorch/pytorch/pull/155768)).
- AOTI config variable `aot_inductor.embed_cubin` has been renamed to `aot_inductor.embed_kernel_binary` ( [#154412](https://github.com/pytorch/pytorch/pull/154412)).
- AOTI config variable `aot_inductor.compile_wrapper_with_O0` has been renamed to `compile_wrapper_opt_level` ( [#148714](https://github.com/pytorch/pytorch/pull/148714)).

### Added a stricter aliasing/mutation check for `HigherOrderOperator` s (e.g. `cond`), which will explicitly error out if alias/mutation among inputs and outputs is unsupported ( [\#148953](https://github.com/pytorch/pytorch/pull/148953), [\#146658](https://github.com/pytorch/pytorch/pull/146658)).

For affected `HigherOrderOperator` s, add `.clone()` to aliased outputs to address this.

Version 2.7.0

```
import torch

@torch.compile(backend="eager")
def fn(x):
    return torch.cond(x.sum() > 0, lambda x: x, lambda x: x + 1, [x])

fn(torch.ones(3))
```

Version 2.8.0

```
import torch

@torch.compile(backend="eager")
def fn(x):
    return torch.cond(x.sum() > 0, lambda x: x.clone(), lambda x: x + 1, [x])

fn(torch.ones(3))
```

### `guard_or_x` and `definitely_x` have been consolidated ( [\#152463](https://github.com/pytorch/pytorch/pull/152463))

We removed `definitely_true` / `definitely_false` and associated APIs, replacing them with

`guard_or_true` / `guard_or_false`, which offer similar functionality and can be used to

achieve the same effect. Please migrate to the latter.

Version 2.7.0

```
from torch.fx.experimental.symbolic_shapes import definitely_false, definitely_true

...
if definitely_true(x):
  ...

if definitely_false(y):
  ...
```

Version 2.8.0

```
from torch.fx.experimental.symbolic_shapes import guard_or_false, guard_or_true

...
if guard_or_false(x):
  ...

# alternatively: if guard_or_false(torch.sym_not(y))
if not guard_or_true(y):
  ...
```

## torch.export

### `torch.export.export_for_inference` has been removed in favor of `torch.export.export_for_training().run_decompositions()` ( [\#149078](https://github.com/pytorch/pytorch/pull/149078))

Version 2.7.0

```
import torch

...
exported_program = torch.export.export_for_inference(mod, args, kwargs)
```

Version 2.8.0

```
import torch

...
exported_program = torch.export.export_for_training(
    mod, args, kwargs
).run_decompositions(decomp_table=decomp_table)
```

### Switched default to `strict=False` in `torch.export.export` and `export_for_training` ( [\#148790](https://github.com/pytorch/pytorch/pull/148790), [\#150941](https://github.com/pytorch/pytorch/pull/150941))

This differs from the previous release default of `strict=True`. To revert to the old default

behavior, please explicitly pass `strict=True`.

Version 2.7.0

```
import torch

# default behavior is strict=True
torch.export.export(...)
torch.export.export_for_training(...)
```

Version 2.8.0

```
import torch

# strict=True must be explicitly passed to get the old behavior
torch.export.export(..., strict=True)
torch.export.export_for_training(..., strict=True)
```

## ONNX

### Default opset in `torch.onnx.export` is now 18 ( [\#156023](https://github.com/pytorch/pytorch/pull/156023))

When `dynamo=False`, th...

[Read more](https://github.com/pytorch/pytorch/releases/tag/v2.8.0)

Assets3

Loading

![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)40akihironitta, klemens-floege, nguyenphuminh, araffin, R0n12, Japyh, IlyasMoutawwakil, Kitsunp, benettia, tsukumijima, and 30 more reacted with thumbs up emoji![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)4knotgrass, wolegca, DingZhaohai, and NevermindNilas reacted with laugh emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)23akihironitta, TyronMott, IlyasMoutawwakil, uygarpolat, Rohanjames1997, benettia, mihaimoga, yoshoku, trsvchn, github-actions\[bot\], and 13 more reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)15minpeter, akihironitta, thomasjo, IlyasMoutawwakil, mpecha, trsvchn, sanodmendis, DefTruth, Brensom, wolegca, and 5 more reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)21healy-hub, akihironitta, klemens-floege, nguyenphuminh, cm4ker, dmholtz, Hydran00, ScottTodd, trsvchn, github-actions\[bot\], and 11 more reacted with rocket emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)6gugarosa, DefTruth, wolegca, DingZhaohai, shinGangan, and sonukaloshiya reacted with eyes emoji

70 people reacted

## PyTorch 2.7.1 Release, bug fix release

Jun 4
04 Jun 18:13


![@atalman](https://avatars.githubusercontent.com/u/7563158?s=40&v=4)[atalman](https://github.com/atalman)

[v2.7.1](https://github.com/pytorch/pytorch/tree/v2.7.1)

[`e2d141d`](https://github.com/pytorch/pytorch/commit/e2d141dbde55c2a4370fac5165b0561b6af4798b)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.


GPG key ID: B5690EEEBB952194

Verified
on May 28, 2025, 09:23 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

Filter

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.7.1 Release, bug fix release](https://github.com/pytorch/pytorch/releases/tag/v2.7.1)

This release is meant to fix the following issues (regressions / silent correctness):

### Torch.compile

Fix Excessive cudagraph re-recording for HF LLM models ( [#152287](https://github.com/pytorch/pytorch/pull/152287))

Fix torch.compile on some HuggingFace models ( [#151154](https://github.com/pytorch/pytorch/pull/151154))

Fix crash due to Exception raised inside torch.autocast ( [#152503](https://github.com/pytorch/pytorch/pull/152503))

Improve Error logging in torch.compile ( [#149831](https://github.com/pytorch/pytorch/pull/149831))

Mark mutable custom operators as cacheable in torch.compile ( [#151194](https://github.com/pytorch/pytorch/pull/151194))

Implement workaround for a graph break with older version einops ( [#153925](https://github.com/pytorch/pytorch/pull/153925))

Fix an issue with tensor.view(dtype).copy\_(...) ( [#151598](https://github.com/pytorch/pytorch/pull/151598))

### Flex Attention

Fix assertion error due to inductor permuting inputs to flex attention ( [#151959](https://github.com/pytorch/pytorch/pull/151959))

Fix performance regression on nanogpt speedrun ( [#152641](https://github.com/pytorch/pytorch/pull/152641))

### Distributed

Fix extra CUDA context created by barrier ( [#149144](https://github.com/pytorch/pytorch/pull/149144))

Fix an issue related to Distributed Fused Adam in Rocm/APEX when using nccl\_ub feature ( [#150010](https://github.com/pytorch/pytorch/pull/150010))

Add a workaround random hang in non-blocking API mode in NCCL 2.26 ( [#154055](https://github.com/pytorch/pytorch/pull/154055))

### MacOS

Fix MacOS compilation error with Clang 17 ( [#151316](https://github.com/pytorch/pytorch/pull/151344))

Fix binary kernels produce incorrect results when one of the tensor arguments is from a wrapped scalar on MPS devices ( [#152997](https://github.com/pytorch/pytorch/pull/152997))

### Other

Improve PyTorch Wheel size due to introduction of addition of 128 bit vectorization ( [#148320](https://github.com/pytorch/pytorch/pull/148320)) ( [#152396](https://github.com/pytorch/pytorch/pull/152396))

Fix fmsub function definition ( [#152075](https://github.com/pytorch/pytorch/pull/152075))

Fix Floating point exception in torch.mkldnn\_max\_pool2d ( [#151848](https://github.com/pytorch/pytorch/pull/151848))

Fix abnormal inference output with XPU:1 device ( [#153067](https://github.com/pytorch/pytorch/pull/153067))

Fix Illegal Instruction Caused by grid\_sample on Windows ( [#152613](https://github.com/pytorch/pytorch/pull/152613))

Fix ONNX decomposition does not preserve custom CompositeImplicitAutograd ops ( [#151826](https://github.com/pytorch/pytorch/pull/151826))

Fix error with dynamic linking of libgomp library ( [#150084](https://github.com/pytorch/pytorch/pull/150084))

Fix segfault in profiler with Python 3.13 ( [#153848](https://github.com/pytorch/pytorch/pull/153848))

Assets3

Loading

![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)30akihironitta, D0n-A, NeilTohno, Anuvadak, alexchenfeng, github-actions\[bot\], Dengda98, Dinesh-Mareedu, HuayuChen2004, 3294734448, and 20 more reacted with thumbs up emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)8akihironitta, mihaimoga, github-actions\[bot\], hassonofer, wanderingeek, okoge-kaz, zangyook, and farazkh80 reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)4akihironitta, 1taroh, Brensom, and VitthalGupta reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)7AjayKMehta, akihironitta, uygarpolat, github-actions\[bot\], hossein-ahmadzadeh, farazkh80, and ParamDeshpande reacted with rocket emoji

40 people reacted

## PyTorch 2.7.0 Release

Apr 23
23 Apr 16:16


![@janeyx99](https://avatars.githubusercontent.com/u/31798555?s=40&v=4)[janeyx99](https://github.com/janeyx99)

[v2.7.0](https://github.com/pytorch/pytorch/tree/v2.7.0)

[`1341794`](https://github.com/pytorch/pytorch/commit/134179474539648ba7dee1317959529fbd0e7f89)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.


GPG key ID: B5690EEEBB952194

Verified
on Apr 15, 2025, 07:01 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

Filter

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.7.0 Release](https://github.com/pytorch/pytorch/releases/tag/v2.7.0)

# PyTorch 2.7.0 Release Notes

- [Highlights](https://github.com/pytorch/pytorch/releases?page=1#highlights)
- [Tracked Regressions](https://github.com/pytorch/pytorch/releases?page=1#tracked-regressions)
- [Backwards Incompatible Changes](https://github.com/pytorch/pytorch/releases?page=1#backwards-incompatible-changes)
- [Deprecations](https://github.com/pytorch/pytorch/releases?page=1#deprecations)
- [New Features](https://github.com/pytorch/pytorch/releases?page=1#new-features)
- [Improvements](https://github.com/pytorch/pytorch/releases?page=1#improvements)
- [Bug fixes](https://github.com/pytorch/pytorch/releases?page=1#bug-fixes)
- [Performance](https://github.com/pytorch/pytorch/releases?page=1#performance)
- [Documentation](https://github.com/pytorch/pytorch/releases?page=1#documentation)
- [Developers](https://github.com/pytorch/pytorch/releases?page=1#developers)

# Highlights

|     |     |
| --- | --- |
| **Beta** | **Prototype** |
| Torch.Compile support for Torch Function Modes | NVIDIA Blackwell Architecture Support |
| Mega Cache | PyTorch Native Context Parallel |
|  | Enhancing Intel GPU Acceleration |
|  | FlexAttention LLM first token processing on X86 CPUs |
|  | FlexAttention LLM throughput mode optimization on X86 CPUs |
|  | Foreach Map |
|  | Flex Attention for Inference |
|  | Prologue Fusion Support in Inductor |

For more details about these highlighted features, you can look at the [release blogpost](https://pytorch.org/blog/pytorch2-7/).

Below are the full release notes for this release.

# Tracked Regressions

### NCCL init hits CUDA failure 'invalid argument' on 12.2 driver

Some users with 12.2 CUDA driver (535 version) report seeing "CUDA driver error: invalid argument" during NCCL or Symmetric Memory initialization. This issue is currently under investigation, see [#150852](https://github.com/pytorch/pytorch/issues/150852). If you use PyTorch from source, a known workaround is to rebuild PyTorch with CUDA 12.2 toolkit. Otherwise, you can try upgrading the CUDA driver on your system.

# Backwards Incompatible Changes

### Dropped support for Triton < 2.2.0. Removed Support for CUDA 12.4, Anaconda in CI/CD.

- Removed CUDA 12.4 support in CI/CD in favor of 12.8 ( [#148895](https://github.com/pytorch/pytorch/pull/148895), [#142856](https://github.com/pytorch/pytorch/pull/142856), [#144118](https://github.com/pytorch/pytorch/pull/144118), [#145566](https://github.com/pytorch/pytorch/pull/145566), [#145844](https://github.com/pytorch/pytorch/pull/145844), [#148602](https://github.com/pytorch/pytorch/pull/148602), [#143076](https://github.com/pytorch/pytorch/pull/143076), [#148717](https://github.com/pytorch/pytorch/pull/148717))
- Removed Anaconda support in CI/CD ( [#144870](https://github.com/pytorch/pytorch/pull/144870), [#145015](https://github.com/pytorch/pytorch/pull/145015), [#147792](https://github.com/pytorch/pytorch/pull/147792))
- Dropped support for Triton < 2.2.0 (versions without ASTSource) ( [#143817](https://github.com/pytorch/pytorch/pull/143817))

### C++ Extensions `py_limited_api=True` is now built with `-DPy_LIMITED_API` ( [\#145764](https://github.com/pytorch/pytorch/pull/145764))

We formally began respecting the `py_limited_api=True` kwarg in 2.6 and stopped linking `libtorch_python.so` when the flag was specified, as libtorch\_python.so does not guarantee using APIs from from the stable Python limited API. In 2.7, we go further by specifying the `-DPy_LIMITED_API` flag which will enforce that the extension is buildable with the limited API. As a result of this enforcement, **custom extensions that set `py_limited_api=True` but do not abide by the limited API may fail to build**. For an example, see [#152243](https://github.com/pytorch/pytorch/issues/152243).

This is strictly better behavior as it is sketchy to claim CPython agnosticism without enforcing with the flag. If you run into this issue, please ensure that the extension you are building does not use any APIs which are outside of the Python limited API, e.g., `pybind`.

### Change `torch.Tensor.new_tensor()` to be on the given Tensor's device by default ( [\#144958](https://github.com/pytorch/pytorch/pull/144958))

This function was always creating the new Tensor on the "cpu" device and will now use the same device as the current Tensor object. This behavior is now consistent with other `.new_*` methods.

### Use Manylinux 2.28 and CXX11\_ABI=1 for future released Linux wheel builds.

With Migration to manylinux\_2\_28 (AlmaLinux 8 based), we can no longer support OS distros with glibc2\_26. These include popular Amazon Linux 2 and CentOS 7. ( [#143423](https://github.com/pytorch/pytorch/pull/143423), [#146200](https://github.com/pytorch/pytorch/pull/146200), [#148028](https://github.com/pytorch/pytorch/pull/148028), [#148135](https://github.com/pytorch/pytorch/pull/148135), [#148195](https://github.com/pytorch/pytorch/pull/148195), [#148129](https://github.com/pytorch/pytorch/pull/148129))

### `torch.onnx.dynamo_export` now uses the ExportedProgram logic path ( [\#137296](https://github.com/pytorch/pytorch/pull/137296))

Users using the `torch.onnx.dynamo_export` API may see some `ExportOptions` become

unsupported due to an internal switch to use `torch.onnx.export(..., dynamo=True)`: `diagnostic_options`, `fake_context` and `onnx_registry` are removed/ignored by `ExportOptions`. Only `dynamic_shapes` is retained.

Users should move to use the `dynamo=True` option on `torch.onnx.export` as

`torch.onnx.dynamo_export` is now deprecated. Leverage the [`dynamic_shapes`](https://pytorch.org/docs/stable/export.html#torch.export.export) argument in `torch.onnx.export` for specifying dynamic shapes on the model.

Version 2.6.0

```
torch.onnx.dynamo_export(model, *args, **kwargs)
```

Version 2.7.0

```
torch.onnx.export(model, args, kwargs=kwargs, dynamo=True)
```

### Finish deprecation of `LRScheduler.print_lr()` along with the `verbose` kwarg to the LRScheduler constructor. ( [\#147301](https://github.com/pytorch/pytorch/pull/147301))

Both APIs have been deprecated since 2.2. Please use `LRScheduler.get_last_lr()` to access the learning rate instead. `print_lr` and `verbose` were confusing, not properly documented and were little used, as described in [#99270](https://github.com/pytorch/pytorch/issues/99270), so we deprecated them in 2.2. Now, we complete the deprecation by removing them completely. To access and print the learning rate of a LRScheduler:

Version 2.6.0

```
optim = ...
lrsched = torch.optim.lr_scheduler.ReduceLROnPlateau(optim, verbose=True)
// lrsched will internally call print_lr() and print the learning rate
```

Version 2.7.0

```
optim = ...
lrsched = torch.optim.lr_scheduler.ReduceLROnPlateau(optim)
print(lrsched.get_last_lr())
```

### libtorch\_python.so symbols are now invisible by default on all platforms except Apple ( [\#142214](https://github.com/pytorch/pytorch/pull/142214))

Previously, the symbols in libtorch\_python.so were exposed with default visibility. We have transitioned to being more intentional about what we expose as public symbols for our python API in C++. After [#142214](https://github.com/pytorch/pytorch/pull/142214), public symbols will be marked explicitly while everything else will be hidden. Some extensions using private symbols will see linker failures with this change.

### Please use `torch.export.export` instead of `capture_pre_autograd_graph` to export the model for pytorch 2 export quantization ( [\#139505](https://github.com/pytorch/pytorch/pull/139505))

`capture_pre_autograd_graph` was a temporary API in `torch.export`. Since now we have a better longer term API: `export` available, we can deprecate it.

Version 2.6.0

```
from torch._export import capture_pre_autograd_graph
from torch.ao.quantization.quantize_pt2e import prepare_pt2e
from torch.ao.quantization.quantizer.xnnpack_quantizer import (
    XNNPACKQuantizer,
    get_symmetric_quantization_config,
)
quantizer = XNNPACKQuantizer().set_global(
    get_symmetric_quantization_config()
)
m = capture_pre_autograd_graph(m, *example_inputs)
m = prepare_pt2e(m, quantizer)
```

Version 2.7.0

```
from torch.export import export
from torch.ao.quantization.quantize_pt2e import prepare_pt2e
# please get xnnpack quantizer from executorch (https://github.com/pytorch/executorch/)
from executorch.backends.xnnpack.quantizer.xnnpack_quantizer import (
    XNNPACKQuantizer,
    get_symmetric_quantization_config,
)
quantizer = XNNPACKQuantizer().set_global(
    get_symmetric_quantization_config()
)
m = export(m, *example_inputs)
m = prepare_pt2e(m, quantizer)
```

### New interface for `torch.fx.passes.graph_transform_observer.GraphTransformObserver` to enable Node Level provenance tracking ( [\#144277](https://github.com/pytorch/pytorch/pull/144277))

We now track a mapping between the nodes in the pre-grad and post-grad graph. See the issue for an example frontend to visualize the transformations. To update your `GraphTransformObserver` subclasses, instead of overriding `on_node_creation` and `on_node_erase`, there are new functions `get_node_creation_hook`, `get_node_erase_hook`, `get_node_replace_hook` and `get_deepcopy_hook`. These are registered on the `GraphModule` member of the `GraphTransformObserver` upon entry and exit of a `with` block

Version 2.6.0

```
class MyPrintObserver(GraphTransformObserver):
    def on_node_creation(self, node: torch.fx.Node):
        print(node)
```

Version 2.7.0

```
class MyPrintObserver(GraphTransformObserver):
    def get_node_creation_hook(self):
        def hook(node: torch.fx.Node):
            print(node)
        return hook
```

### `torch.ao.quantization.pt2e.graph_utils.get_control_flow_submodules` is no longer public ( [\#141612](https://github.com/pytorch/pytorch/pull/141612))

We are planning to make all functions under `torch.ao.quantization.pt2e.graph_utils` private. This update marks `get_control_flow_submodules` as a private API. If you have to or want to continue using `get_control_flow_submodules`, please make a private call by using `_get_control_flow_submodules`.

**Example:**

Version 2.6:

```
>>> from torch.ao.quantization.pt2e.graph_utils import get_control_flow_submodules
```

Version 2.7:

```
>>> from torch.ao.quantization.pt2e.graph_utils import get_control_flow_submodules
ImportError: cannot import name 'get_control_flow_submodules' from 'torch.ao.quantization.pt2e.graph_utils'
>>> from torch.ao.quantization.pt2e.graph_utils import _get_control_flow_submodules  # Note: Use _get_control_flow_submodules for private access
```

# Deprecations

### `torch.onnx.dynamo_export` is deprecated ( [\#146425](https://github.com/pytorch/pytorch/pull/146425), [\#146639](https://github.com/pytorch/pytorch/pull/146639), [\#146923](https://github.com/pytorch/pytorch/pull/146923))

Users should use the `dynamo=True` option on `torch.onnx.export`.

Version 2.6.0

```
torch.onnx.dynamo_export(model, *args, **kwargs)
```

Version 2.7.0

```
torch.onnx.export(model, args, kwargs=kwargs, dynamo=True)
```

### `XNNPACKQuantizer` is deprecated in PyTorch and moved to ExecuTorch, please use it from `executorch.backends.xnnpack.quantizer.xnnpack_quantizer` instead of `torch.ao.quantization.quantizer.xnnpack_quantizer`. ( [\#144940](https://github.com/pytorch/pytorch/pull/144940))

`XNNPACKQuantizer` is a quantizer for xnnpack that was added into pytorch/pytorch for initial development. Ho...

[Read more](https://github.com/pytorch/pytorch/releases/tag/v2.7.0)

Assets3

Loading

![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)73akshaytrikha, wanderingeek, logicwong, holycowdude, yuygfgg, glevv, andrey-khropov, healy-hub, Jumaron, Aunali321, and 63 more reacted with thumbs up emoji![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)10651961, heindrickdumdum0217, Achilles718611, healy-hub, wolegca, GoodCoder666, cataluna84, obitodaitu, AlirezaSR, and PyroKing39 reacted with laugh emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)31kmaehashi, healy-hub, Jumaron, Aunali321, akihironitta, Silv3S, IndigoW0lf, Red-Eyed, ghchris2021, hotchpotch, and 21 more reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)18akihironitta, gui-miotto, Red-Eyed, ghchris2021, 651961, heindrickdumdum0217, Achilles718611, healy-hub, andre-brainn, wolegca, and 8 more reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)17tmshv, ghchris2021, brian316, 651961, ErcinDedeoglu, heindrickdumdum0217, Achilles718611, LiPingYen, healy-hub, Anuvadak, and 7 more reacted with rocket emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)8651961, gugarosa, wolegca, GoodCoder666, cataluna84, obitodaitu, PyroKing39, and Fitanium reacted with eyes emoji

99 people reacted

## PyTorch 2.6.0 Release

Jan 29
29 Jan 17:18


![@HDCharles](https://avatars.githubusercontent.com/u/39544797?s=40&v=4)[HDCharles](https://github.com/HDCharles)

[v2.6.0](https://github.com/pytorch/pytorch/tree/v2.6.0)

[`1eba9b3`](https://github.com/pytorch/pytorch/commit/1eba9b3aa3c43f86f4a2c807ac8e12c4a7767340)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.


GPG key ID: B5690EEEBB952194

Verified
on Jan 28, 2025, 07:09 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

Filter

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.6.0 Release](https://github.com/pytorch/pytorch/releases/tag/v2.6.0)

- Highlights
- Tracked Regressions
- Backwards Incompatible Change
- Deprecations
- New Features
- Improvements
- Bug fixes
- Performance
- Documentation
- Developers

## **Highlights**

We are excited to announce the release of PyTorch® 2.6 ( [release notes](https://github.com/pytorch/pytorch/releases/tag/v2.6.0))! This release features multiple improvements for PT2: `torch.compile` can now be used with Python 3.13; new performance-related knob `torch.compiler.set_stance`; several AOTInductor enhancements. Besides the PT2 improvements, another highlight is FP16 support on X86 CPUs.

NOTE: Starting with this release we are not going to publish on Conda, please see [\[Announcement\] Deprecating PyTorch’s official Anaconda channel](https://github.com/pytorch/pytorch/issues/138506) for the details.

For this release the experimental Linux binaries shipped with CUDA 12.6.3 (as well as Linux Aarch64, Linux ROCm 6.2.4, and Linux XPU binaries) are built with CXX11\_ABI=1 and are [using the Manylinux 2.28 build platform](https://dev-discuss.pytorch.org/t/pytorch-linux-wheels-switching-to-new-wheel-build-platform-manylinux-2-28-on-november-12-2024/2581). If you build PyTorch extensions with custom C++ or CUDA extensions, please update these builds to use CXX\_ABI=1 as well and report any issues you are seeing. For the next PyTorch 2.7 release we plan to switch all Linux builds to Manylinux 2.28 and CXX11\_ABI=1, please see [\[RFC\] PyTorch next wheel build platform: manylinux-2.28](https://github.com/pytorch/pytorch/issues/123649) for the details and discussion.

Also in this release as an important security improvement measure we have changed the default value for `weights_only` parameter of `torch.load`. This is a backward compatibility-breaking change, please see [this forum post](https://dev-discuss.pytorch.org/t/bc-breaking-change-torch-load-is-being-flipped-to-use-weights-only-true-by-default-in-the-nightlies-after-137602/2573) for more details.

This release is composed of 3892 commits from 520 contributors since PyTorch 2.5. We want to sincerely thank our dedicated community for your contributions. As always, we encourage you to try these out and report any issues as we improve PyTorch. More information about how to get started with the PyTorch 2-series can be found at our [Getting Started](https://pytorch.org/get-started/pytorch-2.0/) page.

|     |     |
| --- | --- |
| Beta | Prototype |
| torch.compiler.set\_stance | Improved PyTorch user experience on Intel GPUs |
| torch.library.triton\_op | FlexAttention support on X86 CPU for LLMs |
| torch.compile support for Python 3.13 | Dim.AUTO |
| New packaging APIs for AOTInductor | CUTLASS and CK GEMM/CONV Backends for AOTInductor |
| AOTInductor: minifier |  |
| AOTInductor: ABI-compatible mode code generation |  |
| FP16 support for X86 CPUs |  |

\*To see a full list of public feature submissions click [here](https://docs.google.com/spreadsheets/d/1TzGkWuUMF1yTe88adz1dt2mzbIsZLd3PBasy588VWgk/edit?usp=sharing).

### BETA FEATURES

#### **\[Beta\] torch.compiler.set\_stance**

This feature enables the user to specify different behaviors (“stances”) that `torch.compile` can take between different invocations of compiled functions. One of the stances, for example, is

“eager\_on\_recompile”, that instructs PyTorch to code eagerly when a recompile is necessary, reusing cached compiled code when possible.

For more information please refer to the [set\_stance documentation](https://pytorch.org/docs/2.6/generated/torch.compiler.set_stance.html#torch.compiler.set_stance) and the [Dynamic Compilation Control with torch.compiler.set\_stance](https://pytorch.org/tutorials/recipes/torch_compiler_set_stance_tutorial.html) tutorial.

**\[Beta\] torch.library.triton\_op**

`torch.library.triton_op` offers a standard way of creating custom operators that are backed by user-defined triton kernels.

When users turn user-defined triton kernels into custom operators, `torch.library.triton_op` allows `torch.compile` to peek into the implementation, enabling `torch.compile` to optimize the triton kernel inside it.

For more information please refer to the [triton\_op documentation](https://pytorch.org/docs/2.6/library.html#torch.library.triton_op) and the [Using User-Defined Triton Kernels with torch.compile](https://pytorch.org/tutorials/recipes/torch_compile_user_defined_triton_kernel_tutorial.html) tutorial.

**\[Beta\] torch.compile support for Python 3.13**

`torch.compile` previously only supported Python up to version 3.12. Users can now optimize models with `torch.compile` in Python 3.13.

**\[Beta\] New packaging APIs for AOTInductor**

A new package format, “ [PT2 archive](https://docs.google.com/document/d/1RQ4cmywilnFUT1VE-4oTGxwXdc8vowCSZsrRgo3wFA8/edit?usp=sharing)”, has been introduced. This essentially contains a zipfile of all the files that need to be used by AOTInductor, and allows users to send everything needed to other environments. There is also functionality to package multiple models into one artifact, and to store additional metadata inside of the package.

For more details please see the updated [torch.export AOTInductor Tutorial for Python runtime](https://pytorch.org/tutorials/recipes/torch_export_aoti_python.html).

**\[Beta\] AOTInductor: minifier**

If a user encounters an error while using AOTInductor APIs, AOTInductor Minifier allows creation of a minimal nn.Module that reproduces the error.

For more information please see the [AOTInductor Minifier documentation](https://pytorch.org/docs/2.6/torch.compiler_aot_inductor_minifier.html).

**\[Beta\] AOTInductor: ABI-compatible mode code generation**

AOTInductor-generated model code has dependency on Pytorch cpp libraries. As Pytorch evolves quickly, it’s important to make sure previously AOTInductor compiled models can continue to run on newer Pytorch versions, i.e. AOTInductor is backward compatible.

In order to guarantee application binary interface (ABI) backward compatibility, we have carefully defined a set of stable C interfaces in libtorch and make sure AOTInductor generates code that only refers to the specific set of APIs and nothing else in libtorch. We will keep the set of C APIs stable across Pytorch versions and thus provide backward compatibility guarantees for AOTInductor-compiled models.

**\[Beta\] FP16 support for X86 CPUs (both eager and Inductor modes)**

Float16 datatype is commonly used for reduced memory usage and faster computation in AI inference and training. CPUs like the recently launched [Intel® Xeon® 6 with P-Cores](https://www.intel.com/content/www/us/en/products/details/processors/xeon/xeon6-p-cores.html) support Float16 datatype with native accelerator [AMX](https://www.intel.com/content/www/us/en/products/docs/accelerator-engines/advanced-matrix-extensions/overview.html). Float16 support on X86 CPUs was introduced in PyTorch 2.5 as a prototype feature, and now it has been further improved for both eager mode and Torch.compile + Inductor mode, making it Beta level feature with both functionality and performance verified with a broad scope of workloads.

### PROTOTYPE FEATURES

**\[Prototype\] Improved PyTorch user experience on Intel GPUs**

PyTorch user experience on Intel GPUs is further improved with simplified installation steps, Windows release binary distribution and expanded coverage of supported GPU models including the latest Intel® Arc™ B-Series discrete graphics. Application developers and researchers seeking to fine-tune, inference and develop with PyTorch models on [Intel® Core™ Ultra AI PCs](https://www.intel.com/content/www/us/en/products/docs/processors/core-ultra/ai-pc.html) and [Intel® Arc™ discrete graphics](https://www.intel.com/content/www/us/en/products/details/discrete-gpus/arc.html) will now be able to directly install PyTorch with binary releases for Windows, Linux and Windows Subsystem for Linux 2.

- Simplified Intel GPU software stack setup to enable one-click installation of the torch-xpu PIP wheels to run deep learning workloads in an out of the box fashion, eliminating the complexity of installing and activating Intel GPU development software bundles.
- Windows binary releases for torch core, torchvision and torchaudio have been made available for Intel GPUs, and the supported GPU models have been expanded from Intel® Core™ Ultra Processors with Intel® Arc™ Graphics, [Intel® Core™ Ultra Series 2 with Intel® Arc™ Graphics](https://www.intel.com/content/www/us/en/products/details/processors/core-ultra.html) and [Intel® Arc™ A-Series Graphics](https://www.intel.com/content/www/us/en/products/docs/discrete-gpus/arc/desktop/a-series/overview.html) to the latest GPU hardware [Intel® Arc™ B-Series graphics](https://www.intel.com/content/www/us/en/products/docs/discrete-gpus/arc/desktop/b-series/overview.html).
- Further enhanced coverage of Aten operators on Intel GPUs with SYCL\* kernels for smooth eager mode execution, as well as bug fixes and performance optimizations for torch.compile on Intel GPUs.

For more information regarding Intel GPU support, please refer to [Getting Started Guide](https://pytorch.org/docs/main/notes/get_start_xpu.html).

**\[Prototype\] FlexAttention support on X86 CPU for LLMs**

FlexAttention was initially introduced in PyTorch 2.5 to provide optimized implementations for Attention variants with a flexible API. In PyTorch 2.6, X86 CPU support for FlexAttention was added through TorchInductor CPP backend. This new feature leverages and extends current CPP template abilities to support...

[Read more](https://github.com/pytorch/pytorch/releases/tag/v2.6.0)

Assets3

Loading

![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)54D0n-A, inikishev, akihironitta, davidbuterez, Forbu, Geo99pro, Dahvikiin, CrasCris, RobinKa, ErcinDedeoglu, and 44 more reacted with thumbs up emoji![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)11heindrickdumdum0217, 651961, Enigmatisms, bryanlimy, ShotaDeguchi, binbjz, lin72h, cataluna84, GoodCoder666, xingchensong, and chuckles201 reacted with laugh emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)34Anuvadak, madpeh, jeongseok-meta, jjerphan, azevedoguigo, joshdavham, mihaimoga, akihironitta, mplatzer, Olney1, and 24 more reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)20mplatzer, Olney1, PeterCalifano, Geo99pro, CrasCris, RobinKa, Naeem1144, Di-Is, heindrickdumdum0217, KaSaNaa, and 10 more reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)23painebenjamin, Maurux01, pustam-egr, joshdavham, akihironitta, Olney1, davidbuterez, atalman, CrasCris, RobinKa, and 13 more reacted with rocket emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)5mrverdant13, binbjz, cataluna84, GoodCoder666, and chuckles201 reacted with eyes emoji

87 people reacted

## PyTorch 2.5.1: bug fix release

Oct 29, 2024
29 Oct 17:58


![@kit1980](https://avatars.githubusercontent.com/u/420184?s=40&v=4)[kit1980](https://github.com/kit1980)

[v2.5.1](https://github.com/pytorch/pytorch/tree/v2.5.1)

[`a8d6afb`](https://github.com/pytorch/pytorch/commit/a8d6afb511a69687bbb2b7e88a3cf67917e1697e)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.


GPG key ID: B5690EEEBB952194

Verified
on Nov 7, 2024, 10:42 AM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

Filter

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.5.1: bug fix release](https://github.com/pytorch/pytorch/releases/tag/v2.5.1)

This release is meant to fix the following regressions:

- Wheels from PyPI are unusable out of the box on PRM-based Linux distributions: [#138324](https://github.com/pytorch/pytorch/issues/138324)
- PyPI arm64 distribution logs cpuinfo error on import: [#138333](https://github.com/pytorch/pytorch/issues/138333)
- Crash When Using torch.compile with Math scaled\_dot\_product\_attention in AMP Mode: [#133974](https://github.com/pytorch/pytorch/issues/133974)
- \[MPS\] Internal crash due to the invalid buffer size computation if sliced API is used: [#137800](https://github.com/pytorch/pytorch/issues/137800)
- Several issues related to CuDNN Attention: [#138522](https://github.com/pytorch/pytorch/pull/138522)

Besides the regression fixes, the release includes several documentation updates.

See release tracker [#132400](https://github.com/pytorch/pytorch/issues/132400) for additional information.

Assets3

Loading

![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)46voxlol, rino2000, Denisskas, a-gn, rhiskey, etiennelndr, carlthome, iceychris, leslie-fang-intel, ErcinDedeoglu, and 36 more reacted with thumbs up emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)23mihaimoga, seemethere, Denisskas, QuantumChemist, rhiskey, iceychris, ErcinDedeoglu, binbjz, 651961, wanderingeek, and 13 more reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)24voxlol, Denisskas, QuantumChemist, rsadwick, grib0ed0v, iceychris, syu-tan, binbjz, wanderingeek, Anuvadak, and 14 more reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)19voxlol, Denisskas, QuantumChemist, PeaBrane, iceychris, ErcinDedeoglu, Puiching-Memory, binbjz, wanderingeek, ngdlmk, and 9 more reacted with rocket emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)8Puiching-Memory, Paxsenix0, bryanlimy, binbjz, Joul1285, dhkim0225, sachithdickwella, and JoEarl reacted with eyes emoji

74 people reacted

## PyTorch 2.5.0 Release, SDPA CuDNN backend, Flex Attention

Oct 17, 2024
17 Oct 16:26


![@jainapurva](https://avatars.githubusercontent.com/u/19538305?s=40&v=4)[jainapurva](https://github.com/jainapurva)

[v2.5.0](https://github.com/pytorch/pytorch/tree/v2.5.0)

[`32f585d`](https://github.com/pytorch/pytorch/commit/32f585d9346e316e554c8d9bf7548af9f62141fc)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.


GPG key ID: B5690EEEBB952194

Verified
on Nov 4, 2024, 09:12 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

Filter

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.5.0 Release, SDPA CuDNN backend, Flex Attention](https://github.com/pytorch/pytorch/releases/tag/v2.5.0)

# PyTorch 2.5 Release Notes

- Highlights
- Backwards Incompatible Change
- Deprecations
- New Features
- Improvements
- Bug fixes
- Performance
- Documentation
- Developers
- Security

## Highlights

We are excited to announce the release of PyTorch® 2.5! This release features a new CuDNN backend for SDPA, enabling speedups by default for users of SDPA on H100s or newer GPUs. As well, regional compilation of torch.compile offers a way to reduce the cold start up time for torch.compile by allowing users to compile a repeated nn.Module (e.g. a transformer layer in LLM) without recompilations. Finally, TorchInductor CPP backend offers solid performance speedup with numerous enhancements like FP16 support, CPP wrapper, AOT-Inductor mode, and max-autotune mode.

This release is composed of 4095 commits from 504 contributors since PyTorch 2.4. We want to sincerely thank our dedicated community for your contributions. As always, we encourage you to try these out and report any issues as we improve 2.5. More information about how to get started with the PyTorch 2-series can be found at our [Getting Started](https://pytorch.org/get-started/pytorch-2.0/) page.

As well, please check out our new ecosystem projects releases with [TorchRec](https://github.com/pytorch/torchrec) and [TorchFix](https://github.com/pytorch-labs/torchfix/releases/tag/v0.6.0).

| Beta | Prototype |
| --- | --- |
| CuDNN backend for SDPA | FlexAttention |
| torch.compile regional compilation without recompilations | Compiled Autograd |
| TorchDynamo added support for exception handling & MutableMapping types | Flight Recorder |
| TorchInductor CPU backend optimization | Max-autotune Support on CPU with GEMM Template |
|  | TorchInductor on Windows |
|  | FP16 support on CPU path for both eager mode and TorchInductor CPP backend |
|  | Autoload Device Extension |
|  | Enhanced Intel GPU support |

\*To see a full list of public feature submissions click [here](https://docs.google.com/spreadsheets/d/1TzGkWuUMF1yTe88adz1dt2mzbIsZLd3PBasy588VWgk/edit?gid=949287277#gid=949287277).

### BETA FEATURES

#### \[Beta\] CuDNN backend for SDPA

The cuDNN "Fused Flash Attention" backend was landed for `torch.nn.functional.scaled_dot_product_attention`. On NVIDIA H100 GPUs this can provide up to 75% speed-up over FlashAttentionV2. This speedup is enabled by default for all users of SDPA on H100 or newer GPUs.

#### \[Beta\] _torch.compile_ regional compilation without recompilations

Regional compilation without recompilations, via `torch._dynamo.config.inline_inbuilt_nn_modules` which default to True in 2.5+. This option allows users to compile a repeated nn.Module (e.g. a transformer layer in LLM) without recompilations. Compared to compiling the full model, this option can result in smaller compilation latencies with 1%-5% performance degradation compared to full model compilation.

See the [tutorial](https://pytorch.org/tutorials/recipes/regional_compilation.html) for more information.

#### \[Beta\] TorchInductor CPU backend optimization

This feature advances Inductor’s CPU backend optimization, including CPP backend code generation and FX fusions with customized CPU kernels. The Inductor CPU backend supports vectorization of common data types and all Inductor IR operations, along with the static and symbolic shapes. It is compatible with both Linux and Windows OS and supports the default Python wrapper, the CPP wrapper, and AOT-Inductor mode.

Additionally, it extends the max-autotune mode of the GEMM template (prototyped in 2.5), offering further performance gains. The backend supports various FX fusions, lowering to customized kernels such as oneDNN for Linear/Conv operations and SDPA. The Inductor CPU backend consistently achieves performance speedups across three benchmark suites—TorchBench, Hugging Face, and timms—outperforming eager mode in 97.5% of the 193 models tested.

### PROTOTYPE FEATURES

#### \[Prototype\] FlexAttention

We've introduced a flexible API that enables implementing various attention mechanisms such as Sliding Window, Causal Mask, and PrefixLM with just a few lines of idiomatic PyTorch code. This API leverages torch.compile to generate a fused FlashAttention kernel, which eliminates extra memory allocation and achieves performance comparable to handwritten implementations. Additionally, we automatically generate the backwards pass using PyTorch's autograd machinery. Furthermore, our API can take advantage of sparsity in the attention mask, resulting in significant improvements over standard attention implementations.

For more information and examples, please refer to the [official blog post](https://pytorch.org/blog/flexattention/) and [Attention Gym](https://github.com/pytorch-labs/attention-gym).

#### \[Prototype\] Compiled Autograd

Compiled Autograd is an extension to the PT2 stack allowing the capture of the entire backward pass. Unlike the backward graph traced by AOT dispatcher, Compiled Autograd tracing is deferred until backward execution time, which makes it impervious to forward pass graph breaks, and allows it to record backward hooks into the graph.

Please refer to the [tutorial](https://pytorch.org/tutorials/intermediate/compiled_autograd_tutorial.html) for more information.

#### \[Prototype\] Flight Recorder

Flight recorder is a new debugging tool that helps debug stuck jobs. The tool works by continuously capturing information about collectives as they run. Upon detecting a stuck job, the information can be used to quickly identify misbehaving ranks/machines along with code stack traces.

For more information please refer to the following [tutorial](https://pytorch.org/tutorials/prototype/flight_recorder_tutorial.html).

#### \[Prototype\] Max-autotune Support on CPU with GEMM Template

Max-autotune mode for the Inductor CPU backend in torch.compile profiles multiple implementations of operations at compile time and selects the best-performing one. This is particularly beneficial for GEMM-related operations, using a C++ template-based GEMM implementation as an alternative to the ATen-based approach with oneDNN and MKL libraries. We support FP32, BF16, FP16, and INT8 with epilogue fusions for x86 CPUs. We’ve seen up to 7% geomean speedup on the dynamo benchmark suites and up to 20% boost in next-token latency for LLM inference.

For more information please refer to the [tutorial](https://pytorch.org/tutorials/prototype/max_autotune_on_CPU_tutorial.html).

#### \[Prototype\] TorchInductor CPU on Windows

Inductor CPU backend in torch.compile now works on Windows. We support MSVC (cl), clang (clang-cl) and Intel compiler (icx-cl) for Windows inductor currently.

See the [tutorial](https://pytorch.org/tutorials/prototype/inductor_windows_cpu.html) for more details.

#### \[Prototype\] FP16 support on CPU path for both eager mode and TorchInductor CPP backend

Float16 is a commonly used reduced floating point type for performance improvement in neural network inference/training. Since this release, float16 for both eager and TorchInductor is supported on the CPU path.

#### \[Prototype\] Autoload Device Extension

PyTorch now supports autoloading for out-of-tree device extensions, streamlining integration by eliminating the need for manual imports. This feature, enabled through the torch.backends entrypoint, simplifies usage by ensuring seamless extension loading, while allowing users to disable it via an environment variable if needed.

See the [tutorial](https://pytorch.org/tutorials/prototype/python_extension_autoload.html) for more information.

#### \[Prototype\] Enhanced Intel GPU support

Intel GPUs support enhancement is now available for both Intel® Data Center GPU Max Series and Intel® Client GPUs (Intel® Core™ Ultra processors with built-in Intel® Arc™ graphics and Intel® Arc™ Graphics for dGPU parts), which is to make it easier to accelerate your Machine Learning workflows on Intel GPUs in PyTorch 2.5 release. We also enabled the initial support of PyTorch on Windows for Intel® Client GPUs in this release.

- Expanded PyTorch hardware backend support matrix to include both Intel Data Center and Client GPUs.
- The implementation of SYCL\* kernels to enhance coverage and execution of Aten operators on Intel GPUs to boost performance in PyTorch eager mode.
- Enhanced Intel GPU backend of torch.compile to improve inference and training performance for a wide range of deep learning workloads.

These features are available through PyTorch preview and nightly binary PIP wheels. For more information regarding Intel GPU support, please refer to [documentation](https://pytorch.org/docs/main/notes/get_start_xpu.html).

## Backwards Incompatible changes

### Distributed

- \[c10d\] Remove Option for ProcessGroup and Expose backend Options to reflect the correct code structure ( [#132931](https://github.com/pytorch/pytorch/pull/132931))


  - We released Dispatchable collectives in 2.0 and we will use Backend Option for Backend initialization and the PG options are not needed any more.
  - In 2.4 and before, users can do:

```
# Users can pass in a basic option when creating an instance of ProcessGroup
base_pg_options = ProcessGroup.Options(backend=str(backend))
base_pg_options._timeout = timeout

pg: ProcessGroup = ProcessGroup(
  store, rank, group_size, base_pg_options
)

# Users then need to create a backend option to create the comm backend (e.g., ProcessGroupNCCL)
pg_options = ProcessGroupNCCL.Options()
backend = ProcessGroupNCCL(
  store, rank, group_size, pg_options
)
```

  - But from 2.5 onwards, users don’t need to pass in an option to create an instance of ProcessGroup and user can still set default backend for the pg since users still try to get default backend in the code:

```
# No basic option is passed in when creating a instance of ProcessGroup
pg: ProcessGroup = ProcessGroup(store, rank, group_size)
pg._set_default_backend(...
```

[Read more](https://github.com/pytorch/pytorch/releases/tag/v2.5.0)

Assets3

Loading

![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)76voxlol, duanzhiihao, johnnynunez, bryanlimy, mhyrzt, leonardodepaula, SagatdinovEmil, etiennelndr, mrverdant13, jepjoo, and 66 more reacted with thumbs up emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)35QuantumChemist, jjerphan, Puiching-Memory, bryanlimy, mihaimoga, fcogidi, AYUSHMIT, johnnynunez, mrverdant13, parlance-zz, and 25 more reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)20atalman, cuicaihao, parlance-zz, iceychris, bryanlimy, GraceKafuu, Denisskas, inikishev, GoodCoder666, sa-y-an, and 10 more reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)22Puiching-Memory, bryanlimy, johnnynunez, mrverdant13, parlance-zz, cuicaihao, gau-nernst, iceychris, wangling1820, VictorSantos674, and 12 more reacted with rocket emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)9Paxsenix0, GraceKafuu, Denisskas, fpaupier, GoodCoder666, binbjz, Geo99pro, wanderingeek, and wbigat reacted with eyes emoji

105 people reacted

## PyTorch 2.4.1 Release, bug fix release

Sep 4, 2024
04 Sep 19:59


![@atalman](https://avatars.githubusercontent.com/u/7563158?s=40&v=4)[atalman](https://github.com/atalman)

[v2.4.1](https://github.com/pytorch/pytorch/tree/v2.4.1)

[`ee1b680`](https://github.com/pytorch/pytorch/commit/ee1b6804381c57161c477caa380a840a84167676)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.


GPG key ID: B5690EEEBB952194

Verified
on Nov 4, 2024, 11:42 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

Filter

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.4.1 Release, bug fix release](https://github.com/pytorch/pytorch/releases/tag/v2.4.1)

This release is meant to fix the following issues (regressions / silent correctness):

### Breaking Changes:

- The pytorch/pytorch docker image now installs the PyTorch package through pip and has switch its conda installation from miniconda to [miniforge](https://github.com/conda-forge/miniforge) ( [#134274](https://github.com/pytorch/pytorch/pull/134274))

### Windows:

- Fix performance regression on Windows related to MKL static linking ( [#130619](https://github.com/pytorch/pytorch/issues/130619)) ( [#130697](https://github.com/pytorch/pytorch/pull/130697))
- Fix error during loading on Windows: \[WinError 126\] The specified module could not be found. ( [#131662](https://github.com/pytorch/pytorch/issues/131662)) ( [#130697](https://github.com/pytorch/pytorch/pull/130697))

### MPS:

- Fix tensor.clamp produces wrong values ( [#130226](https://github.com/pytorch/pytorch/pull/130226))
- Fix Incorrect result from batch norm with sliced inputs ( [#133610](https://github.com/pytorch/pytorch/pull/133610))

### ROCM:

- Fix for launching kernel invalid config error when calling embedding with large index ( [#130994](https://github.com/pytorch/pytorch/pull/130994))
- Added a check and a warning when attempting to use hipBLASLt on an unsupported architecture ( [#128753](https://github.com/pytorch/pytorch/pull/128753))
- Fix image corruption with Memory Efficient Attention when running HuggingFace Diffusers Stable Diffusion 3 pipeline ( [#133331](https://github.com/pytorch/pytorch/pull/133331))

### Distributed:

- Fix FutureWarning when using torch.load internally ( [#130663](https://github.com/pytorch/pytorch/pull/130663))
- Fix FutureWarning when using torch.cuda.amp.autocast internally ( [#130660](https://github.com/pytorch/pytorch/pull/130660))

### Torch.compile:

- Fix exception with torch compile when onnxruntime-training and deepspeed packages are installed. ( [#131194](https://github.com/pytorch/pytorch/pull/131194))
- Fix silent incorrectness with torch.library.custom\_op with mutable inputs and torch.compile ( [#133452](https://github.com/pytorch/pytorch/pull/133452))
- Fix SIMD detection on Linux ARM ( [#129075](https://github.com/pytorch/pytorch/pull/129075))
- Do not use C++20 features in cpu\_inducotr code ( [#130816](https://github.com/pytorch/pytorch/pull/130816))

### Packaging:

- Fix for exposing statically linked libstdc++ CXX11 ABI symbols ( [#134494](https://github.com/pytorch/pytorch/pull/134494))
- Fix error while building pytorch from source due to not missing QNNPACK module ( [#131864](https://github.com/pytorch/pytorch/pull/133177))
- Make PyTorch buildable from source on PowerPC ( [#129736](https://github.com/pytorch/pytorch/pull/129736))
- Fix XPU extension building ( [#132847](https://github.com/pytorch/pytorch/pull/132847))

### Other:

- Fix warning when using pickle on a nn.Module that contains tensor attributes ( [#130246](https://github.com/pytorch/pytorch/pull/130246))
- Fix NaNs return in MultiheadAttention when need\_weights=False ( [#130014](https://github.com/pytorch/pytorch/pull/130014))
- Fix nested tensor MHA produces incorrect results ( [#130196](https://github.com/pytorch/pytorch/issues/130196))
- Fix error when using torch.utils.flop\_counter.FlopCounterMode ( [#134467](https://github.com/pytorch/pytorch/pull/134467))

### Tracked Regressions:

- The experimental remote caching feature for Inductor's autotuner (enabled via TORCHINDUCTOR\_AUTOTUNE\_REMOTE\_CACHE) is known to still be broken in this release and actively worked on in main. Following Error is generated: redis.exceptions.DataError: Invalid input of type: 'dict'. Please use nightlies if you need this feature (reported and Fixed by PR: [#134032](https://github.com/pytorch/pytorch/pull/134032))

Release tracker [#132400](https://github.com/pytorch/pytorch/issues/132400) contains all relevant pull requests related to this release as well as links to related issues.

Assets3

Loading

![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)43etiennelndr, Jared-woodruff, D0n-A, moh-salih, Robbin1998s, banyan-god, dvquy13, vilsonrodrigues, VidathChamikara, zhouzaida, and 33 more reacted with thumbs up emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)17yoshoku, 651961, Robbin1998s, Denisskas, ken-morel, Atharvkote, ancestor-mithril, wanderingeek, iceychris, binbjz, and 7 more reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)27hammaad2002, bigcat88, K-H-Ismail, Benetti-Hub, Burhan-Q, QuantumChemist, Alarmod, twoertwein, Heliodex, 651961, and 17 more reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)4InhabitancyCocoon, GnafiY, AmeenAli, and sudoflex reacted with rocket emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)8Paxsenix0, Puiching-Memory, Denisskas, wanderingeek, binbjz, brian316, lunnyliu, and Nullkooland reacted with eyes emoji

77 people reacted

## PyTorch 2.4: Python 3.12, AOTInductor freezing, libuv backend for TCPStore

Jul 24, 2024
24 Jul 18:39


![@vmoens](https://avatars.githubusercontent.com/u/25529882?s=40&v=4)[vmoens](https://github.com/vmoens)

[v2.4.0](https://github.com/pytorch/pytorch/tree/v2.4.0)

[`d990dad`](https://github.com/pytorch/pytorch/commit/d990dada86a8ad94882b5c23e859b88c0c255bda)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.


GPG key ID: B5690EEEBB952194

Verified
on Nov 4, 2024, 06:27 PM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

Filter

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.4: Python 3.12, AOTInductor freezing, libuv backend for TCPStore](https://github.com/pytorch/pytorch/releases/tag/v2.4.0)

# PyTorch 2.4 Release Notes

- Highlights
- Tracked Regressions
- Backward incompatible changes
- Deprecations
- New features
- Improvements
- Bug Fixes
- Performance
- Documentation
- Developers
- Security

## Highlights

We are excited to announce the release of PyTorch® 2.4!

PyTorch 2.4 adds support for the latest version of Python (3.12) for `torch.compile`.

AOTInductor freezing gives developers running AOTInductor more performance based optimizations by allowing the

serialization of MKLDNN weights. As well, a new default TCPStore server backend utilizing `libuv` has been introduced

which should significantly reduce initialization times for users running large-scale jobs.

Finally, a new Python Custom Operator API makes it easier than before to integrate custom kernels

into PyTorch, especially for `torch.compile`.

This release is composed of 3661 commits and 475 contributors since PyTorch 2.3. We want to sincerely thank our

dedicated community for your contributions. As always, we encourage you to try these out and report any issues as we

improve 2.4. More information about how to get started with the PyTorch 2-series can be found at our

[Getting Started](https://pytorch.org/get-started/pytorch-2.0/) page.

|     |     |     |
| --- | --- | --- |
| Beta | Prototype | Performance Improvements |
| Python 3.12 support for torch.compile | FSDP2: DTensor-based per-parameter-sharding FSDP | torch.compile optimizations for AWS Graviton (aarch64-linux) processors |
| AOTInductor Freezing for CPU | torch.distributed.pipelining, simplified pipeline parallelism | BF16 symbolic shape optimization in TorchInductor |
| New Higher-level Python Custom Operator API | Intel GPU is available through source build | Performance optimizations for GenAI projects utilizing CPU devices |
| Switching TCPStore’s default server backend to libuv |  |  |
|  |  |  |

\*To see a full list of public feature submissions click [here](https://docs.google.com/spreadsheets/d/1TzGkWuUMF1yTe88adz1dt2mzbIsZLd3PBasy588VWgk/edit?usp=sharing).

## Tracked Regressions

### Subproc exception with torch.compile and onnxruntime-training

There is a reported issue ( [#131070](https://github.com/pytorch/pytorch/issues/131070)) when using `torch.compile` if `onnxruntime-training` lib is

installed. The issue will be fixed ( [#131194](https://github.com/pytorch/pytorch/pull/131194)) in v2.4.1. It can be solved locally by setting the environment variable

`TORCHINDUCTOR_WORKER_START=fork` before executing the script.

### cu118 wheels will not work with pre-cuda12 drivers

It was also reported ( [#130684](https://github.com/pytorch/pytorch/issues/130684)) that the new version of triton uses cuda features that are not compatible with pre-cuda12 drivers.

In this case, the [workaround](https://github.com/triton-lang/triton/pull/4335#issuecomment-2232505298) is to set

`TRITON_PTXAS_PATH` manually as follows (adapt the code according to the local installation path):

```
TRITON_PTXAS_PATH=/usr/local/lib/python3.10/site-packages/torch/bin/ptxas  python script.py
```

## Backwards Incompatible Change

### Python frontend

#### Default `TreadPool` size to number of physical cores ( [\#125963](https://github.com/pytorch/pytorch/pull/125963))

Changed the default number of threads used for intra-op parallelism from the number of logical cores to the number of

physical cores. This should reduce core oversubscribing when running CPU workload and improve performance.

Previous behavior can be recovered by using torch.set\_num\_threads to set the number of threads to the desired value.

#### Fix `torch.quasirandom.SobolEngine.draw` default dtype handling ( [\#126781](https://github.com/pytorch/pytorch/pull/126781))

The default dtype value has been changed from `torch.float32` to the current default dtype as given by

`torch.get_default_dtype()` to be consistent with other APIs.

#### Forbid subclassing `torch._C._TensorBase` directly ( [\#125558](https://github.com/pytorch/pytorch/pull/125558))

This is an internal subclass that a user used to be able to create an object that is almost a Tensor in Python and was

advertised as such in some tutorials. This is not allowed anymore to improve consistency and all users should

subclass torch.Tensor directly.

### Composability

#### Non-compositional usages of as\_strided + mutation under `torch.compile` will raise an error ( [\#122502](https://github.com/pytorch/pytorch/pull/122502))

The `torch.compile` flow involves functionalizing any mutations inside the region being compiled. Torch.as\_strided is

an existing view op that can be used non-compositionally: meaning when you call x.as\_strided(...), as\_strided will only

consider the underlying storage size of x, and ignore its current size/stride/storage\_offset when creating a new view.

This makes it difficult to safely functionalize mutations on views of as\_strided that are created non-compositionally,

so we ban them rather than risking silent correctness issues under torch.compile.

An example of a non-compositional usage of as\_strided followed by mutation that we will error on is below. You can avoid

this issue by re-writing your usage of as\_strided so that it is compositional (for example: either use a different set

of view ops instead of as\_strided, or call as\_strided directly on the base tensor instead of an existing view of it).

```
@torch.compile
def foo(a):
    e = a.diagonal()
    # as_strided is being called on an existing view (e),
    # making it non-compositional. mutations to f under torch.compile
    # are not allowed, as we cannot easily functionalize them safely
    f = e.as_strided((2,), (1,), 0)
    f.add_(1.0)
    return a
```

#### We now verify schemas of custom ops at registration time ( [\#124520](https://github.com/pytorch/pytorch/pull/124520))

Previously, you could register a custom op through the operator registration APIs, but give it a schema that contained

types unknown to the PyTorch Dispatcher. This behavior came from TorchScript, where “unknown” types were implicitly

treated by the TorchScript interpreter as type variables. However, calling such a custom op through regular pytorch

would result in an error later. As of 2.4, we will raise an error at registration time, when you first register the

custom operator. You can get the old behavior by constructing the schema with allow\_typevars=true.

```
TORCH_LIBRARY(my_ns, m) {
  // this now raises an error at registration time: bar/baz are unknown types
  m.def("my_ns::foo(bar t) -> baz");
  // you can get back the old behavior with the below flag
  m.def(torch::schema("my_ns::foo(bar t) -> baz", /*allow_typevars*/ true));
}

```

### Autograd frontend

#### Delete torch.autograd.function.traceable APIs ( [\#122817](https://github.com/pytorch/pytorch/pull/122817))

The torch.autograd.function.traceable(...) API, which sets the is\_traceable class attribute

on a torch.autograd.Function class was deprecated in 2.3 and is now being deleted.

This API does not do anything and was only meant for internal purposes.

The following raised an warning in 2.3, and now errors because the API has been deleted:

```
@torch.autograd.function.traceable
class Func(torch.autograd.Function):
    ...
```

### Release engineering

- Remove caffe2 db and distributed from build system ( [#125092](https://github.com/pytorch/pytorch/pull/125092))

### Optim

- Remove `SparseAdam` weird allowance of raw Tensor input ( [#127081](https://github.com/pytorch/pytorch/pull/127081)).

### Distributed

#### DeviceMesh

Update get\_group and add get\_all\_groups ( [#128097](https://github.com/pytorch/pytorch/pull/128097))

In 2.3 and before, users can do:

```
mesh_2d = init_device_mesh(
    "cuda", (2, 2), mesh_dim_names=("dp", "tp")
)
mesh_2d.get_group()  # This will return all sub-pgs within the mesh
assert mesh_2d.get_group()[0] == mesh_2d.get_group(0)
assert mesh_2d.get_group()[1] == mesh_2d.get_group(1)
```

But from 2.4 forward, if users call `get_group` without passing in the dim, users will get a `RuntimeError`.

Instead, they should use `get_all_groups`:

```
mesh_2d = init_device_mesh(
    "cuda", (2, 2), mesh_dim_names=("dp", "tp")
)
mesh_2d.get_group()  # This will throw a RuntimeError
assert mesh_2d.get_all_groups()[0] == mesh_2d.get_group(0)
assert mesh_2d.get_all_groups()[1] == mesh_2d.get_group(1)
```

#### Pipelining

Retire torch.distributed.pipeline ( [#127354](https://github.com/pytorch/pytorch/pull/127354))

In 2.3 and before, users can do:

```
import torch.distributed.pipeline # warning saying that this will be removed and users need to migrate to torch.distributed.pipelining
```

But from 2.4 forward, if users write the code above, users will get a `ModuleNotFound` error.

Instead, they should use `torch.distributed.pipelining`:

```
import torch.distributed.pipeline # -> ModuleNotFoundError
import torch.distributed.pipelining
```

### jit

- Fix serialization/deepcopy behavior for tensors that are aliasing but not equal ( [#126126](https://github.com/pytorch/pytorch/pull/126126))

### Fx

Complete revamp of float/promotion sympy handling ( [#126905](https://github.com/pytorch/pytorch/pull/126905))

### ONNX

- Remove caffe2 contrib and experiments ( [#125038](https://github.com/pytorch/pytorch/pull/125038))

## Deprecations

### Python frontend

- User warning when using `torch.load` with default `weights_only=False` value ( [#129239](https://github.com/pytorch/pytorch/pull/129239), [#129396](https://github.com/pytorch/pytorch/pull/129396), [#129509](https://github.com/pytorch/pytorch/pull/129509)).


A warning is now raised if the weights\_only value is not specified during a call to torch.load, encouraging users to


adopt the safest practice when loading weights.
- Deprecate device-specific autocast API ( [#126062](https://github.com/pytorch/pytorch/pull/126062))


All the autocast APIs are unified under torch.amp and it can be used as a drop-in replacement for torch.{device}.amp APIs


(passing a device argument where applicable)..
- Export torch.newaxis=None for Python Array API/Numpy consistency ( [#125026](https://github.com/pytorch/pytorch/pull/125026))

### Composability

- Deprecate calling FakeTensor.data\_ptr in eager-mode. FakeTensors are tensors without a valid data pointer, so in


general their data pointer is not safe to access. This makes it easier for `torch.compile` to provide a nice error


message when tracing custom ops into a graph that are not written in a PT2-friendly way (bec...

[Read more](https://github.com/pytorch/pytorch/releases/tag/v2.4.0)

Assets3

Loading

![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)54tolgacangoz, Borda, redradist, bryanlimy, D0n-A, xsa-dev, akihironitta, etiennelndr, Mickychen00, binbjz, and 44 more reacted with thumbs up emoji![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)1shang-mt reacted with laugh emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)30tolgacangoz, nviraj, redradist, bryanlimy, nairbv, akihironitta, saeedark, Mickychen00, atalman, xuchenhao001, and 20 more reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)20tolgacangoz, redradist, bryanlimy, ashim-mahara, hammaad2002, akashaero, khushi-411, akihironitta, Kakaymi10, Mickychen00, and 10 more reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)19tolgacangoz, debnath-d, redradist, bryanlimy, gau-nernst, akihironitta, jamesETsmith, binbjz, orion160, qcind, and 9 more reacted with rocket emoji![eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)10tolgacangoz, bryanlimy, Paxsenix0, binbjz, andre-brainn, waheedi, Denisskas, james-banks, AndrewDiMola, and GoodCoder666 reacted with eyes emoji

89 people reacted

## PyTorch 2.3.1 Release, bug fix release

Jun 5, 2024
05 Jun 19:16


![@atalman](https://avatars.githubusercontent.com/u/7563158?s=40&v=4)[atalman](https://github.com/atalman)

[v2.3.1](https://github.com/pytorch/pytorch/tree/v2.3.1)

[`63d5e92`](https://github.com/pytorch/pytorch/commit/63d5e9221bedd1546b7d364b5ce4171547db12a9)

This commit was created on GitHub.com and signed with GitHub’s **verified signature**.


GPG key ID: B5690EEEBB952194

Verified
on Nov 7, 2024, 10:42 AM

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits).


Compare

# Choose a tag to compare

Filter

[View all tags](https://github.com/pytorch/pytorch/tags)

[PyTorch 2.3.1 Release, bug fix release](https://github.com/pytorch/pytorch/releases/tag/v2.3.1)

This release is meant to fix the following issues (regressions / silent correctness):

### Torch.compile:

- Remove runtime dependency on JAX/XLA, when importing `torch.__dynamo` ( [#124634](https://github.com/pytorch/pytorch/pull/124634))
- Hide `Plan failed with a cudnnException` warning ( [#125790](https://github.com/pytorch/pytorch/pull/125790))
- Fix CUDA memory leak ( [#124238](https://github.com/pytorch/pytorch/pull/124238)) ( [#120756](https://github.com/pytorch/pytorch/pull/120756))

### Distributed:

- Fix `format_utils executable`, which was causing it to run as a no-op ( [#123407](https://github.com/pytorch/pytorch/pull/123407))
- Fix regression with `device_mesh` in 2.3.0 during initialization causing memory spikes ( [#124780](https://github.com/pytorch/pytorch/pull/124780))
- Fix crash of `FSDP + DTensor` with `ShardingStrategy.SHARD_GRAD_OP` ( [#123617](https://github.com/pytorch/pytorch/pull/123617))
- Fix failure with distributed checkpointing + FSDP if at least 1 forward/backward pass has not been run. ( [#121544](https://github.com/pytorch/pytorch/pull/121544)) ( [#127069](https://github.com/pytorch/pytorch/pull/127069))
- Fix error with distributed checkpointing + FSDP, and with `use_orig_params = False` and activation checkpointing ( [#124698](https://github.com/pytorch/pytorch/pull/124698)) ( [#126935](https://github.com/pytorch/pytorch/pull/126935))
- Fix `set_model_state_dict` errors on compiled module with non-persistent buffer with distributed checkpointing ( [#125336](https://github.com/pytorch/pytorch/pull/125336)) ( [#125337](https://github.com/pytorch/pytorch/pull/125337))

### MPS:

- Fix data corruption when coping large (>4GiB) tensors ( [#124635](https://github.com/pytorch/pytorch/pull/124635))
- Fix `Tensor.abs()` for complex ( [#125662](https://github.com/pytorch/pytorch/pull/125662))

### Packaging:

- Fix UTF-8 encoding on Windows `.pyi` files ( [#124932](https://github.com/pytorch/pytorch/pull/124932))
- Fix `import torch` failure when wheel is installed for a single user on Windows( [#125684](https://github.com/pytorch/pytorch/pull/125684))
- Fix compatibility with torchdata 0.7.1 ( [#122616](https://github.com/pytorch/pytorch/pull/122616))
- Fix aarch64 docker publishing to [https://ghcr.io](https://ghcr.io/) ( [#125617](https://github.com/pytorch/pytorch/pull/125617))
- Fix performance regression an aarch64 linux ( [pytorch/builder#1803](https://github.com/pytorch/builder/pull/1803))

### Other:

- Fix DeepSpeed transformer extension build on ROCm ( [#121030](https://github.com/pytorch/pytorch/pull/121030))
- Fix kernel crash on `tensor.dtype.to_complex()` after ~100 calls in ipython kernel ( [#125154](https://github.com/pytorch/pytorch/pull/125154))

Release tracker [#125425](https://github.com/pytorch/pytorch/issues/125425) contains all relevant pull requests related to this release as well as links to related issues.

Assets3

Loading

![+1](https://github.githubassets.com/assets/1f44d-41cb66fe1e22.png)54rino2000, function2-llx, antoinebrl, arvinsingh, zhanwenchen, hammaad2002, kmaehashi, wanderingeek, ZZHanyu, VermiIIi0n, and 44 more reacted with thumbs up emoji![smile](https://github.githubassets.com/assets/1f604-7528822fb4c5.png)19bow reacted with laugh emoji![tada](https://github.githubassets.com/assets/1f389-36899a2cb781.png)15viktor765, yoshoku, kmaehashi, wanderingeek, qcind, khushi-411, tobygh, andre-brainn, john-pixforce, johnnv1, and 5 more reacted with hooray emoji![heart](https://github.githubassets.com/assets/2764-982dc91ea48a.png)13tobygh, andre-brainn, hammaad2002, 9bow, M0nteCarl0, avdhoeke, tuningManBin, tamimuddin, sachithdickwella, JoelPasapera, and 3 more reacted with heart emoji![rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)14qcind, khushi-411, tobygh, AntonioBerna, andre-brainn, vilsonrodrigues, wanderingeek, N-Friederich, 9bow, sachithdickwella, and 4 more reacted with rocket emoji

70 people reacted

Previous _1_ [2](https://github.com/pytorch/pytorch/releases?page=2) [3](https://github.com/pytorch/pytorch/releases?page=3) [4](https://github.com/pytorch/pytorch/releases?page=4) [5](https://github.com/pytorch/pytorch/releases?page=5) [6](https://github.com/pytorch/pytorch/releases?page=6) [7](https://github.com/pytorch/pytorch/releases?page=7) [Next](https://github.com/pytorch/pytorch/releases?page=2)

Previous [Next](https://github.com/pytorch/pytorch/releases?page=2)

## Footer

[GitHub Homepage](https://github.com/)
© 2025 GitHub, Inc.


